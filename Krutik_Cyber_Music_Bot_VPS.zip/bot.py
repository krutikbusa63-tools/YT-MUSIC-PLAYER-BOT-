#!/usr/bin/env python3
# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC PREMIUM EDITION 🌺
#   Main Entrypoint with Self-Healing & Venv Auto-Bootstrap
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import os
import sys
import time
from pathlib import Path

# ── 1. Ensure Virtual Environment Interpreter (/app/applet/.venv/bin/python) ──
PROJECT_ROOT = Path(__file__).resolve().parent
VENV_PYTHON = PROJECT_ROOT / ".venv" / "bin" / "python"

if VENV_PYTHON.exists():
    try:
        if Path(sys.prefix).resolve() != (PROJECT_ROOT / ".venv").resolve():
            os.execv(str(VENV_PYTHON), [str(VENV_PYTHON), *sys.argv])
    except Exception:
        pass

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import asyncio
from KrutikMusic.core.self_healing import (
    acquire_single_instance_lock,
    record_restart_event,
    release_single_instance_lock,
    verify_and_heal_dependencies,
    verify_environment_dirs,
)


def main() -> None:
    verify_environment_dirs()
    acquire_single_instance_lock()

    dep_report = verify_and_heal_dependencies(auto_install=True)
    if not dep_report.get("ok"):
        missing = ", ".join(dep_report.get("failed_critical", []))
        print(f"[Self-Healing Engine] ❌ Critical dependencies still missing: {missing}")

    backoff_s = record_restart_event("bot.py startup")
    if backoff_s > 0:
        print(
            f"[Self-Healing Engine] ⏳ Applying controlled startup backoff ({backoff_s:.1f}s) "
            f"to prevent rapid restart loops..."
        )
        time.sleep(backoff_s)

    from KrutikMusic.__main__ import init

    try:
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        loop.run_until_complete(init())
    except KeyboardInterrupt:
        print("[Self-Healing Engine] Bot stopped via KeyboardInterrupt.")
    except Exception as exc:
        record_restart_event(f"unhandled_exception: {type(exc).__name__}: {exc}")
        print(f"[Self-Healing Engine] Bot loop exited with error: {type(exc).__name__}: {exc}")
        raise
    finally:
        release_single_instance_lock()


if __name__ == "__main__":
    main()
