# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import contextlib
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional, Union

import aiofiles
import aiohttp
from aiohttp import TCPConnector
from yt_dlp import YoutubeDL

from KrutikMusic.core.dir import DOWNLOAD_DIR as _DOWNLOAD_DIR, CACHE_DIR
from KrutikMusic.utils.cookie_handler import COOKIE_PATH, get_valid_cookie_path
from KrutikMusic.utils.tuning import CHUNK_SIZE, SEM
from config import API_KEY, API_URL

logger = logging.getLogger("KrutikMusic.downloader")

USE_API: bool = bool(API_URL and API_KEY)

_COOKIES_FILE = str(COOKIE_PATH)

_inflight: Dict[str, asyncio.Future] = {}
_inflight_lock = asyncio.Lock()

_session: Optional[aiohttp.ClientSession] = None
_session_lock = asyncio.Lock()


class YouTubeAuthError(Exception):
    """Raised when YouTube rejects authentication or requires bot verification."""


class YouTubeUnavailableError(Exception):
    """Raised when a YouTube video is private, deleted, or unavailable."""


def is_youtube_auth_error(err: Union[str, Exception]) -> bool:
    msg = str(err).lower()
    return any(
        k in msg
        for k in (
            "sign in to confirm",
            "confirm you’re not a bot",
            "confirm you're not a bot",
            "use --cookies-from-browser or --cookies",
            "cookies are no longer valid",
        )
    )


def is_youtube_unavailable_error(err: Union[str, Exception]) -> bool:
    msg = str(err).lower()
    return any(
        k in msg
        for k in (
            "video unavailable",
            "private video",
            "this video has been removed",
            "this video is no longer available",
            "incomplete youtube id",
        )
    )


def extract_video_id(link: str) -> str:
    if "v=" in link:
        return link.split("v=")[-1].split("&")[0]
    return link.split("/")[-1].split("?")[0]


def _cookiefile_path() -> Optional[str]:
    return get_valid_cookie_path()


def file_exists(video_id: str, video: bool = False) -> Optional[str]:
    exts = ("mp4",) if video else ("mp3", "m4a", "webm", "mp4")
    for ext in exts:
        path = f"{_DOWNLOAD_DIR}/{video_id}.{ext}"
        if os.path.exists(path) and os.path.getsize(path) > 10240:
            return path
    return None


def _safe_filename(name: str) -> str:
    return re.sub(r'[\\/*?:"<>|]+', "_", (name or "").strip())[:200]


def _ytdlp_base_opts() -> Dict[str, Any]:
    opts: Dict[str, Any] = {
        "outtmpl": f"{_DOWNLOAD_DIR}/%(id)s.%(ext)s",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "overwrites": True,
        "continuedl": True,
        "noprogress": True,
        "geo_bypass": True,
        "force_ipv4": True,
        "concurrent_fragment_downloads": 16,
        "http_chunk_size": 1 << 20,
        "socket_timeout": 30,
        "retries": 3,
        "fragment_retries": 3,
        "cachedir": str(Path(CACHE_DIR).resolve()),
        "js_runtimes": {"node": {}},
        "remote_components": ["ejs:github"],
    }
    cookiefile = _cookiefile_path()
    if cookiefile:
        opts["cookiefile"] = cookiefile
    return opts


async def _get_session() -> aiohttp.ClientSession:
    global _session
    if _session and not _session.closed:
        return _session
    async with _session_lock:
        if _session and not _session.closed:
            return _session
        timeout = aiohttp.ClientTimeout(total=600, sock_connect=20, sock_read=60)
        connector = TCPConnector(limit=64, ttl_dns_cache=300, enable_cleanup_closed=True)
        _session = aiohttp.ClientSession(timeout=timeout, connector=connector)
        return _session


async def close_session() -> None:
    """Close the global aiohttp session."""
    global _session
    async with _session_lock:
        if _session and not _session.closed:
            await _session.close()
        _session = None


async def api_download_song(link: str) -> Optional[str]:
    if not USE_API:
        return None
    vid = extract_video_id(link)
    poll_url = f"{API_URL}/song/{vid}?api={API_KEY}"
    try:
        session = await _get_session()
        while True:
            async with session.get(poll_url) as r:
                if r.status != 200:
                    return None
                data = await r.json()
                s = str(data.get("status", "")).lower()
                if s == "downloading":
                    await asyncio.sleep(1.5)
                    continue
                if s != "done":
                    return None
                dl = data.get("link")
                fmt = str(data.get("format", "mp3")).lower()
                out_path = f"{_DOWNLOAD_DIR}/{vid}.{fmt}"
                async with session.get(dl) as fr:
                    if fr.status != 200:
                        return None
                    async with aiofiles.open(out_path, "wb") as f:
                        async for chunk in fr.content.iter_chunked(CHUNK_SIZE):
                            if not chunk:
                                break
                            await f.write(chunk)
                return out_path
    except Exception:
        return None


def _download_ytdlp(
    link: str,
    opts: Dict[str, Any],
    fallback_query: Optional[str] = None,
    is_video: bool = False,
) -> Optional[str]:
    vid = extract_video_id(link)
    cached = file_exists(vid, video=is_video)
    if cached:
        return cached
    try:
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(link, download=True)
            if isinstance(info, dict):
                ext = info.get("ext") or ("mp4" if is_video else "webm")
                vid = info.get("id") or vid
                path = f"{_DOWNLOAD_DIR}/{vid}.{ext}"
                if os.path.exists(path) and os.path.getsize(path) > 10240:
                    return path
            found = file_exists(vid, video=is_video)
            if found:
                return found
    except Exception as e:
        if is_youtube_auth_error(e):
            logger.warning(f"🔐 YouTube authentication error for {vid}: cookies rejected or bot check triggered.")
        elif is_youtube_unavailable_error(e):
            logger.warning(f"⚠️ YouTube track unavailable for {vid}: {e}")
        else:
            logger.warning(f"⚠️ yt-dlp primary extraction error for {vid}: {e}")

    if fallback_query and vid and not is_video:
        try:
            fb_opts = dict(opts)
            fb_opts.pop("cookiefile", None)
            fb_opts.pop("remote_components", None)
            fb_opts["outtmpl"] = f"{_DOWNLOAD_DIR}/{vid}.%(ext)s"
            fb_opts["format"] = "bestaudio[ext=m4a]/bestaudio/best"
            with YoutubeDL(fb_opts) as ydl:
                info = ydl.extract_info(f"scsearch1:{fallback_query}", download=True)
                entries = info.get("entries") if isinstance(info, dict) else None
                if entries:
                    ext = entries[0].get("ext") or "m4a"
                    path = f"{_DOWNLOAD_DIR}/{vid}.{ext}"
                    if os.path.exists(path) and os.path.getsize(path) > 10240:
                        return path
            return file_exists(vid, video=False)
        except Exception as fb_err:
            logger.warning(f"⚠️ Fallback extraction failed for {vid}: {fb_err}")
            return None
    return None


async def _with_sem(coro):
    async with SEM:
        return await coro


async def _dedup(key: str, runner):
    async with _inflight_lock:
        fut = _inflight.get(key)
        if fut:
            return await fut
        fut = asyncio.get_running_loop().create_future()
        _inflight[key] = fut
    try:
        res = await runner()
        fut.set_result(res)
        return res
    except Exception:
        fut.set_result(None)
        return None
    finally:
        async with _inflight_lock:
            _inflight.pop(key, None)


async def yt_dlp_download(
    link: str, type: str, format_id: str = None, title: str = None
) -> Optional[str]:
    loop = asyncio.get_running_loop()

    if type == "audio":
        key = f"a:{link}"

        async def run():
            opts = _ytdlp_base_opts()
            opts.update({"format": "bestaudio/best"})
            return await _with_sem(
                loop.run_in_executor(None, _download_ytdlp, link, opts, title, False)
            )

        return await _dedup(key, run)

    if type == "video":
        key = f"v:{link}"

        async def run():
            opts = _ytdlp_base_opts()
            opts.update({"format": "best[height<=?720][width<=?1280][vcodec!=none][acodec!=none]/18/best[height<=?720]"})
            return await _with_sem(
                loop.run_in_executor(None, _download_ytdlp, link, opts, title, True)
            )

        return await _dedup(key, run)

    if type == "song_video" and format_id and title:
        safe_title = _safe_filename(title)
        key = f"sv:{link}:{format_id}:{safe_title}"

        async def run():
            opts = _ytdlp_base_opts()
            opts.update(
                {
                    "format": f"{format_id}+140/best",
                    "outtmpl": f"{_DOWNLOAD_DIR}/{safe_title}.mp4",
                    "prefer_ffmpeg": True,
                    "merge_output_format": "mp4",
                }
            )
            await _with_sem(
                loop.run_in_executor(None, lambda: YoutubeDL(opts).download([link]))
            )
            return f"{_DOWNLOAD_DIR}/{safe_title}.mp4"

        return await _dedup(key, run)

    if type == "song_audio" and format_id and title:
        safe_title = _safe_filename(title)
        key = f"sa:{link}:{format_id}:{safe_title}"

        async def run():
            opts = _ytdlp_base_opts()
            opts.update(
                {
                    "format": format_id,
                    "outtmpl": f"{_DOWNLOAD_DIR}/{safe_title}.%(ext)s",
                    "prefer_ffmpeg": True,
                    "postprocessors": [
                        {
                            "key": "FFmpegExtractAudio",
                            "preferredcodec": "mp3",
                            "preferredquality": "192",
                        }
                    ],
                }
            )
            await _with_sem(
                loop.run_in_executor(None, lambda: YoutubeDL(opts).download([link]))
            )
            return f"{_DOWNLOAD_DIR}/{safe_title}.mp3"

        return await _dedup(key, run)

    return None


async def download_audio_concurrent(link: str, title: Optional[str] = None) -> Optional[str]:
    vid = extract_video_id(link)
    cached = file_exists(vid)
    if cached:
        return cached

    if not USE_API:
        return await yt_dlp_download(link, type="audio", title=title)

    key = f"rac:{link}"

    async def run():
        yt_task = asyncio.create_task(yt_dlp_download(link, type="audio", title=title))
        api_task = asyncio.create_task(api_download_song(link))
        done, pending = await asyncio.wait(
            {yt_task, api_task}, return_when=asyncio.FIRST_COMPLETED
        )
        for t in done:
            with contextlib.suppress(Exception):
                res = t.result()
                if res:
                    for p in pending:
                        p.cancel()
                        with contextlib.suppress(Exception, asyncio.CancelledError):
                            await p
                    return res
        for t in pending:
            with contextlib.suppress(Exception, asyncio.CancelledError):
                res = await t
                if res:
                    return res
        return None

    return await _dedup(key, lambda: _with_sem(run()))

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
