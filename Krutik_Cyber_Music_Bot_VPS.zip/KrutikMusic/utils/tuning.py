# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import os
import asyncio

CPU = os.cpu_count() or 2

# Optimized concurrency for 10–12+ simultaneous group voice chats
MAX_CONCURRENT = int(os.getenv("MAX_CONCURRENT", str(min(24, max(12, CPU * 4)))))

# 512 KB chunks — balanced for fast network without high memory allocation
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", str(512 * 1024)))

# yt-dlp timeout: allows Node EJS challenge solving while failing fast on dead links
YTDLP_TIMEOUT = int(os.getenv("YTDLP_TIMEOUT", "35"))

# Metadata cache: 15 min TTL with 1024 entries for multi-group efficiency
YOUTUBE_META_TTL = int(os.getenv("YOUTUBE_META_TTL", "900"))
YOUTUBE_META_MAX = int(os.getenv("YOUTUBE_META_MAX", "1024"))

SEM = asyncio.Semaphore(MAX_CONCURRENT)

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
