# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

from KrutikMusic import app
from KrutikMusic.utils.database import get_cmode


async def get_channeplayCB(_, command, CallbackQuery):
    if command == "c":
        chat_id = await get_cmode(CallbackQuery.message.chat.id)
        if chat_id is None:
            try:
                return await CallbackQuery.answer(_["setting_7"], show_alert=True)
            except:
                return
        try:
            channel = (await app.get_chat(chat_id)).title
        except:
            try:
                return await CallbackQuery.answer(_["cplay_4"], show_alert=True)
            except:
                return
    else:
        chat_id = CallbackQuery.message.chat.id
        channel = None
    return chat_id, channel

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
