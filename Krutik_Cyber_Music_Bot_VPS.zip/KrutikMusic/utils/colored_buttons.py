# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

"""
⚠️ CRITICAL: Telegram colored buttons require 2 things:
   1. Telegram client updated AFTER February 9, 2026
   2. Bot API HTTP calls (Kurigram/Pyrogram don't support 'style' field)

This module bypasses Kurigram and sends buttons directly via Telegram Bot API HTTP.

Supported Styles:
  • "primary" - Blue (main actions)
  • "success" - Green (positive actions like confirm)
  • "danger"  - Red (destructive actions like delete)
  • None - Default button color
"""

import asyncio
import json
import logging
import os
import re
from typing import Dict, List, Optional, Set, Tuple, Union

import aiohttp
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

import config

logger = logging.getLogger(__name__)

# Global aiohttp session
_session: Optional[aiohttp.ClientSession] = None

# Track whether (chat_id, message_id) is a media/caption message vs a plain-text message
# so edit calls automatically use editMessageCaption for media and editMessageText for text.
_media_messages: Set[Tuple[int, int]] = set()
_text_messages: Set[Tuple[int, int]] = set()
_MAX_TRACKED_MESSAGES = 4096


def _record_message_kind(chat_id: Union[int, str], message_id: Optional[int], is_media: bool) -> None:
    if not message_id:
        return
    try:
        key = (int(chat_id), int(message_id))
    except (ValueError, TypeError):
        return
    if len(_media_messages) > _MAX_TRACKED_MESSAGES:
        _media_messages.clear()
    if len(_text_messages) > _MAX_TRACKED_MESSAGES:
        _text_messages.clear()
    if is_media:
        _media_messages.add(key)
        _text_messages.discard(key)
    else:
        _text_messages.add(key)
        _media_messages.discard(key)


def _is_known_media_message(chat_id: Union[int, str], message_id: int) -> bool:
    try:
        return (int(chat_id), int(message_id)) in _media_messages
    except (ValueError, TypeError):
        return False


def _is_known_text_message(chat_id: Union[int, str], message_id: int) -> bool:
    try:
        return (int(chat_id), int(message_id)) in _text_messages
    except (ValueError, TypeError):
        return False


# ═══════════════════════════════════════════════════════════
#  CORE FUNCTIONS
# ═══════════════════════════════════════════════════════════

async def _get_session() -> aiohttp.ClientSession:
    """Get or create aiohttp session."""
    global _session

    if _session is None or _session.closed:
        timeout = aiohttp.ClientTimeout(total=30, connect=10)
        connector = aiohttp.TCPConnector(limit=64, ttl_dns_cache=300, enable_cleanup_closed=True)
        _session = aiohttp.ClientSession(timeout=timeout, connector=connector)

    return _session


async def close_session() -> None:
    """Close the global aiohttp session."""
    global _session
    if _session and not _session.closed:
        await _session.close()
    _session = None


VALID_TELEGRAM_HTML_TAGS = {
    "b", "strong", "i", "em", "u", "ins", "s", "strike", "del",
    "span", "tg-spoiler", "a", "code", "pre", "blockquote", "tg-emoji"
}


def sanitize_telegram_html(text: Optional[str]) -> Optional[str]:
    """Sanitizes text for Telegram HTML mode, escaping unsupported pseudo-tags like <ᴜꜱᴇʀ>."""
    if not text or "<" not in text:
        return text

    def _repl(m):
        full = m.group(0)
        tag = m.group(2).lower()
        if tag in VALID_TELEGRAM_HTML_TAGS:
            return full
        return full.replace("<", "&lt;").replace(">", "&gt;")

    return re.sub(r"<(/?)(\S+?)(?:>|\s[^>]*>)", _repl, text)


async def _bot_api_call(method: str, payload: dict, quiet_mismatch: bool = False) -> Optional[dict]:
    """Make HTTP POST to Telegram Bot API."""
    if not config.BOT_TOKEN:
        logger.warning("⚠️ BOT_TOKEN not set! Colored buttons will NOT work.")
        return None

    api_base = (config.LOCAL_BOT_API_URL or "https://api.telegram.org").rstrip("/")
    url = f"{api_base}/bot{config.BOT_TOKEN}/{method}"
    session = await _get_session()

    try:
        async with session.post(url, json=payload) as resp:
            data = await resp.json()

            if data.get("ok"):
                result = data.get("result")
                if isinstance(result, dict):
                    return result
                return {"ok": True}

            error = data.get("description", "Unknown error")
            low_err = error.lower()

            # Treat "message is not modified" as a successful no-op
            if "message is not modified" in low_err:
                return {"ok": True, "not_modified": True, "message_id": payload.get("message_id")}

            # Automatic fallback for invalid HTML entities / unsupported start tags
            if ("can't parse entities" in low_err or "unsupported start tag" in low_err) and payload.get("parse_mode"):
                fb_payload = dict(payload)
                fb_payload.pop("parse_mode", None)
                logger.warning(f"⚠️ HTML parse error in {method} ({error}); retrying without parse_mode...")
                return await _bot_api_call(method, fb_payload, quiet_mismatch=quiet_mismatch)

            # Detect text vs caption mismatch and cache the message kind
            if method == "editMessageText" and "there is no text in the message to edit" in low_err:
                _record_message_kind(payload.get("chat_id"), payload.get("message_id"), is_media=True)
                if quiet_mismatch:
                    logger.debug(
                        f"Message {payload.get('message_id')} in {payload.get('chat_id')} is media; switching to editMessageCaption."
                    )
                    return None

            if method == "editMessageCaption" and (
                "there is no caption in the message to edit" in low_err
                or "message has no media" in low_err
            ):
                _record_message_kind(payload.get("chat_id"), payload.get("message_id"), is_media=False)
                if quiet_mismatch:
                    logger.debug(
                        f"Message {payload.get('message_id')} in {payload.get('chat_id')} is text; switching to editMessageText."
                    )
                    return None

            logger.warning(f"❌ Bot API {method} failed: {error}")
            return None

    except asyncio.TimeoutError:
        logger.error(f"⏱️ Bot API {method} timeout")
        return None
    except Exception as e:
        logger.error(f"💥 Bot API {method} exception: {e}")
        return None


def _build_inline_keyboard(buttons: List[List[Dict]]) -> List[List[Dict]]:
    """Convert styled button dicts to Bot API inline_keyboard format."""
    keyboard = []
    for row in buttons:
        button_row = []
        for btn in row:
            api_btn = {"text": btn["text"]}

            if "callback_data" in btn:
                api_btn["callback_data"] = btn["callback_data"]
            if "url" in btn:
                api_btn["url"] = btn["url"]
            if "style" in btn:
                api_btn["style"] = btn["style"]

            button_row.append(api_btn)
        keyboard.append(button_row)

    return keyboard


# ═══════════════════════════════════════════════════════════
#  PUBLIC API - BUTTON CREATION
# ═══════════════════════════════════════════════════════════

def styled_button(
    text: str,
    callback_data: str = None,
    url: str = None,
    style: str = None,
) -> Dict[str, str]:
    """Create a colored button dictionary."""
    btn = {"text": text}

    if callback_data:
        btn["callback_data"] = callback_data
    if url:
        btn["url"] = url
    if style and style in ("primary", "success", "danger"):
        btn["style"] = style

    return btn


def buttons_to_inline_markup(buttons: List[List[Dict]]) -> InlineKeyboardMarkup:
    """Convert styled buttons to Kurigram InlineKeyboardMarkup (NO COLORS)."""
    keyboard = []
    for row in buttons:
        kb_row = []
        for btn in row:
            kwargs = {"text": btn["text"]}
            if "callback_data" in btn:
                kwargs["callback_data"] = btn["callback_data"]
            if "url" in btn:
                kwargs["url"] = btn["url"]
            kb_row.append(InlineKeyboardButton(**kwargs))
        keyboard.append(kb_row)

    return InlineKeyboardMarkup(keyboard)


# ═══════════════════════════════════════════════════════════
#  PUBLIC API - SEND/EDIT MESSAGES WITH COLORED BUTTONS
# ═══════════════════════════════════════════════════════════

async def send_message_colored(
    chat_id: Union[int, str],
    text: str,
    reply_markup: List[List[Dict]],
    parse_mode: str = "HTML",
    disable_web_page_preview: bool = False,
) -> Optional[Dict]:
    """Send message with COLORED buttons via Bot API HTTP."""
    if parse_mode == "HTML" and text:
        text = sanitize_telegram_html(text)

    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode,
        "disable_web_page_preview": disable_web_page_preview,
    }
    if reply_markup:
        payload["reply_markup"] = {
            "inline_keyboard": _build_inline_keyboard(reply_markup)
        }

    res = await _bot_api_call("sendMessage", payload)
    if res and res.get("message_id"):
        _record_message_kind(chat_id, res["message_id"], is_media=False)
    return res


async def send_photo_colored(
    chat_id: Union[int, str],
    photo: str,
    caption: str = None,
    reply_markup: List[List[Dict]] = None,
    parse_mode: str = "HTML",
) -> Optional[Dict]:
    """Send photo with COLORED buttons via Bot API HTTP."""
    photo_str = str(photo)
    is_url = photo_str.startswith("http://") or photo_str.startswith("https://")
    is_local_file = not is_url and ("/" in photo_str or "\\" in photo_str or os.path.exists(photo_str))

    if is_local_file:
        res = await _send_photo_with_file(chat_id, photo_str, caption, reply_markup, parse_mode)
    else:
        payload = {
            "chat_id": chat_id,
            "photo": photo_str,
            "parse_mode": parse_mode,
        }
        if caption:
            payload["caption"] = caption
        if reply_markup:
            payload["reply_markup"] = {
                "inline_keyboard": _build_inline_keyboard(reply_markup)
            }
        res = await _bot_api_call("sendPhoto", payload)

    if res and res.get("message_id"):
        _record_message_kind(chat_id, res["message_id"], is_media=True)
    return res


async def _send_photo_with_file(
    chat_id: Union[int, str],
    file_path: str,
    caption: str = None,
    reply_markup: List[List[Dict]] = None,
    parse_mode: str = "HTML",
) -> Optional[Dict]:
    """Send photo by uploading local file with multipart/form-data."""
    if not os.path.exists(file_path):
        logger.error(f"❌ Photo file not found: {file_path}")
        return None

    if not config.BOT_TOKEN:
        logger.error("❌ BOT_TOKEN not set!")
        return None

    api_base = (config.LOCAL_BOT_API_URL or "https://api.telegram.org").rstrip("/")
    url = f"{api_base}/bot{config.BOT_TOKEN}/sendPhoto"
    session = await _get_session()

    try:
        with open(file_path, "rb") as fh:
            file_bytes = fh.read()
    except Exception as e:
        logger.error(f"❌ Failed reading photo file {file_path}: {e}")
        return None

    try:
        form = aiohttp.FormData()
        form.add_field("chat_id", str(chat_id))
        form.add_field(
            "photo",
            file_bytes,
            filename=os.path.basename(file_path),
            content_type="application/octet-stream",
        )

        if caption:
            form.add_field("caption", caption)

        if parse_mode:
            form.add_field("parse_mode", parse_mode)

        if reply_markup:
            reply_markup_json = json.dumps({
                "inline_keyboard": _build_inline_keyboard(reply_markup)
            })
            form.add_field("reply_markup", reply_markup_json)

        async with session.post(url, data=form) as resp:
            data = await resp.json()

            if data.get("ok"):
                result = data.get("result")
                if isinstance(result, dict) and result.get("message_id"):
                    _record_message_kind(chat_id, result["message_id"], is_media=True)
                return result
            else:
                error = data.get("description", "Unknown error")
                if "can't parse entities" in error and parse_mode:
                    logger.warning("⚠️ HTML parse error, retrying without parse_mode")
                    return await _send_photo_with_file(chat_id, file_path, caption, reply_markup, parse_mode=None)

                logger.warning(f"❌ Bot API sendPhoto (file upload) failed: {error}")
                return None

    except asyncio.TimeoutError:
        logger.error("⏱️ Bot API sendPhoto timeout")
        return None
    except Exception as e:
        logger.error(f"💥 Bot API sendPhoto exception: {e}")
        return None


async def edit_message_caption_colored(
    chat_id: Union[int, str],
    message_id: int,
    caption: str = None,
    reply_markup: List[List[Dict]] = None,
    parse_mode: str = "HTML",
    quiet_mismatch: bool = True,
) -> Optional[Dict]:
    """Edit message caption + buttons with COLORS via Bot API HTTP."""
    if parse_mode == "HTML" and caption:
        caption = sanitize_telegram_html(caption)

    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "parse_mode": parse_mode,
    }

    if caption is not None:
        payload["caption"] = caption

    if reply_markup:
        payload["reply_markup"] = {
            "inline_keyboard": _build_inline_keyboard(reply_markup)
        }

    res = await _bot_api_call("editMessageCaption", payload, quiet_mismatch=quiet_mismatch)
    if res:
        _record_message_kind(chat_id, message_id, is_media=True)
    return res


async def edit_message_text_colored(
    chat_id: Union[int, str],
    message_id: int,
    text: str,
    reply_markup: List[List[Dict]] = None,
    parse_mode: str = "HTML",
    disable_web_page_preview: bool = False,
    quiet_mismatch: bool = True,
) -> Optional[Dict]:
    """Edit message text (or media caption if message has media) + buttons with COLORS."""
    if parse_mode == "HTML" and text:
        text = sanitize_telegram_html(text)

    # If we already know this message is a photo/video/media message, use editMessageCaption directly
    if _is_known_media_message(chat_id, message_id):
        res = await edit_message_caption_colored(
            chat_id=chat_id,
            message_id=message_id,
            caption=text,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
            quiet_mismatch=quiet_mismatch,
        )
        if res:
            return res

    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "parse_mode": parse_mode,
        "disable_web_page_preview": disable_web_page_preview,
    }

    if reply_markup:
        payload["reply_markup"] = {
            "inline_keyboard": _build_inline_keyboard(reply_markup)
        }

    res = await _bot_api_call("editMessageText", payload, quiet_mismatch=quiet_mismatch)
    if res:
        _record_message_kind(chat_id, message_id, is_media=False)
        return res

    # If _bot_api_call detected "there is no text in the message to edit", it marked it as media
    if _is_known_media_message(chat_id, message_id):
        return await edit_message_caption_colored(
            chat_id=chat_id,
            message_id=message_id,
            caption=text,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
            quiet_mismatch=quiet_mismatch,
        )

    return None


async def edit_reply_markup_colored(
    chat_id: Union[int, str],
    message_id: int,
    reply_markup: List[List[Dict]],
) -> Optional[Dict]:
    """Edit ONLY buttons (keeps colors persistent) via Bot API HTTP."""
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "reply_markup": {
            "inline_keyboard": _build_inline_keyboard(reply_markup)
        },
    }

    return await _bot_api_call("editMessageReplyMarkup", payload)


async def edit_message_media_colored(
    chat_id: Union[int, str],
    message_id: int,
    media: Dict,
    reply_markup: List[List[Dict]] = None,
) -> Optional[Dict]:
    """Edit message media + buttons with COLORS via Bot API HTTP."""
    media = {**media}
    media.setdefault("parse_mode", "HTML")
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "media": media,
    }

    if reply_markup:
        payload["reply_markup"] = {
            "inline_keyboard": _build_inline_keyboard(reply_markup)
        }

    res = await _bot_api_call("editMessageMedia", payload)
    if res:
        _record_message_kind(chat_id, message_id, is_media=True)
    return res


# ═══════════════════════════════════════════════════════════
#  SMART WRAPPERS — Bot API first (colors), Pyrogram fallback
# ═══════════════════════════════════════════════════════════

async def smart_send_message(
    chat_id: Union[int, str],
    text: str,
    reply_markup: Optional[List[List[Dict]]] = None,
    parse_mode: str = "HTML",
    disable_web_page_preview: bool = False,
):
    """Send a message with colored buttons. Falls back to Pyrogram on failure."""
    from KrutikMusic import app
    from pyrogram import enums

    try:
        data = await send_message_colored(
            chat_id,
            text,
            reply_markup=reply_markup or [],
            parse_mode=parse_mode,
            disable_web_page_preview=disable_web_page_preview,
        )
        if data and data.get("message_id"):
            try:
                return await app.get_messages(chat_id, data["message_id"])
            except Exception:
                return data
    except Exception as e:
        logger.debug(f"smart_send_message Bot API path failed: {e}")

    try:
        sent = await app.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
            disable_web_page_preview=disable_web_page_preview,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
        if sent and getattr(sent, "id", None):
            _record_message_kind(chat_id, sent.id, is_media=False)
        return sent
    except Exception as e:
        logger.warning(f"smart_send_message: Pyrogram fallback failed: {e}")
        return None


async def smart_send_photo(
    chat_id: Union[int, str],
    photo: str,
    caption: Optional[str] = None,
    reply_markup: Optional[List[List[Dict]]] = None,
    parse_mode: str = "HTML",
):
    """Send a photo with colored buttons. Falls back to Pyrogram on failure."""
    from KrutikMusic import app
    from pyrogram import enums

    try:
        data = await send_photo_colored(
            chat_id=chat_id,
            photo=photo,
            caption=caption,
            reply_markup=reply_markup or [],
            parse_mode=parse_mode,
        )
        if data and data.get("message_id"):
            try:
                return await app.get_messages(chat_id, data["message_id"])
            except Exception:
                return data
    except Exception as e:
        logger.debug(f"smart_send_photo Bot API path failed: {e}")

    try:
        sent = await app.send_photo(
            chat_id=chat_id,
            photo=photo,
            caption=caption,
            parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
        if sent and getattr(sent, "id", None):
            _record_message_kind(chat_id, sent.id, is_media=True)
        return sent
    except Exception as e:
        logger.warning(f"smart_send_photo: Pyrogram fallback failed: {e}")
        return None


def _camel_to_snake(name: str) -> str:
    """Convert camelCase Bot API method to snake_case Pyrogram method."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


async def smart_send_media(
    chat_id: Union[int, str],
    method: str,
    media_field: str,
    media_value: str,
    caption: Optional[str] = None,
    reply_markup: Optional[List[List[Dict]]] = None,
    parse_mode: str = "HTML",
    reply_to_message_id: Optional[int] = None,
):
    """Send any media (URL or file_id) with colored buttons via Bot API."""
    from KrutikMusic import app
    from pyrogram import enums

    payload = {"chat_id": chat_id, "parse_mode": parse_mode}
    payload[media_field] = media_value

    if caption:
        payload["caption"] = caption
    if reply_to_message_id:
        payload["reply_to_message_id"] = reply_to_message_id
    if reply_markup:
        payload["reply_markup"] = {"inline_keyboard": _build_inline_keyboard(reply_markup)}

    try:
        data = await _bot_api_call(method, payload)
        if data and data.get("message_id"):
            _record_message_kind(chat_id, data["message_id"], is_media=True)
            try:
                return await app.get_messages(chat_id, data["message_id"])
            except Exception:
                return data
    except Exception as e:
        logger.debug(f"smart_send_media {method} Bot API path failed: {e}")

    try:
        send_fn = getattr(app, _camel_to_snake(method))
        kwargs = {
            "chat_id": chat_id,
            "caption": caption,
            "parse_mode": enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
        }
        kwargs[media_field] = media_value
        if reply_to_message_id:
            kwargs["reply_to_message_id"] = reply_to_message_id
        if reply_markup:
            kwargs["reply_markup"] = buttons_to_inline_markup(reply_markup)
        sent = await send_fn(**kwargs)
        if sent and getattr(sent, "id", None):
            _record_message_kind(chat_id, sent.id, is_media=True)
        return sent
    except Exception as e:
        logger.warning(f"smart_send_media {method}: Pyrogram fallback failed: {e}")
        return None


async def smart_edit_message_text(
    chat_id: Union[int, str],
    message_id: int,
    text: str,
    reply_markup: Optional[List[List[Dict]]] = None,
    parse_mode: str = "HTML",
    disable_web_page_preview: bool = False,
):
    """Edit a message (text OR media caption) with colored buttons preserved.

    Uses the tracked message kind (_media_messages / _text_messages) to call
    editMessageCaption directly for media messages and editMessageText for text
    messages, avoiding 'Bad Request: there is no text in the message to edit'.
    """
    from KrutikMusic import app
    from pyrogram import enums

    is_media = _is_known_media_message(chat_id, message_id)

    if is_media:
        # Media message: try editMessageCaption first
        try:
            data = await edit_message_caption_colored(
                chat_id=chat_id,
                message_id=message_id,
                caption=text,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
                quiet_mismatch=True,
            )
            if data:
                return data
        except Exception as e:
            logger.debug(f"smart_edit_message_text (media): editMessageCaption failed: {e}")

        # Fallback to editMessageText if it turned out to be text
        try:
            data = await edit_message_text_colored(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
                disable_web_page_preview=disable_web_page_preview,
                quiet_mismatch=True,
            )
            if data:
                return data
        except Exception as e:
            logger.debug(f"smart_edit_message_text (media): editMessageText fallback failed: {e}")
    else:
        # Text or unknown message: edit_message_text_colored automatically falls back
        # to edit_message_caption_colored if "there is no text in the message to edit"
        try:
            data = await edit_message_text_colored(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
                disable_web_page_preview=disable_web_page_preview,
                quiet_mismatch=True,
            )
            if data:
                return data
        except Exception as e:
            logger.debug(f"smart_edit_message_text: edit_message_text_colored failed: {e}")

        if not _is_known_text_message(chat_id, message_id):
            try:
                data = await edit_message_caption_colored(
                    chat_id=chat_id,
                    message_id=message_id,
                    caption=text,
                    reply_markup=reply_markup,
                    parse_mode=parse_mode,
                    quiet_mismatch=True,
                )
                if data:
                    return data
            except Exception as e:
                logger.debug(f"smart_edit_message_text: editMessageCaption fallback failed: {e}")

    # Pyrogram fallback (if Bot API HTTP is unreachable)
    if _is_known_media_message(chat_id, message_id):
        try:
            return await app.edit_message_caption(
                chat_id=chat_id,
                message_id=message_id,
                caption=text,
                parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
                reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
            )
        except Exception:
            pass

    try:
        return await app.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
            disable_web_page_preview=disable_web_page_preview,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
    except Exception:
        pass

    try:
        return await app.edit_message_caption(
            chat_id=chat_id,
            message_id=message_id,
            caption=text,
            parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
    except Exception as e:
        logger.warning(f"smart_edit_message_text: all paths failed: {e}")
        return None


async def smart_edit_reply_markup(
    chat_id: Union[int, str],
    message_id: int,
    reply_markup: List[List[Dict]],
):
    """Edit ONLY the buttons of a message with colors preserved."""
    from KrutikMusic import app

    try:
        data = await edit_reply_markup_colored(
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=reply_markup,
        )
        if data:
            return data
    except Exception as e:
        logger.debug(f"smart_edit_reply_markup Bot API path failed: {e}")

    try:
        return await app.edit_message_reply_markup(
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
    except Exception as e:
        logger.warning(f"smart_edit_reply_markup both paths failed: {e}")
        return None


async def smart_edit_message_caption(
    chat_id: Union[int, str],
    message_id: int,
    caption: str,
    reply_markup: Optional[List[List[Dict]]] = None,
    parse_mode: str = "HTML",
):
    """Edit caption OR text message with colored buttons preserved."""
    from KrutikMusic import app
    from pyrogram import enums

    if _is_known_text_message(chat_id, message_id):
        try:
            data = await edit_message_text_colored(
                chat_id=chat_id,
                message_id=message_id,
                text=caption,
                reply_markup=reply_markup,
                parse_mode=parse_mode,
                quiet_mismatch=True,
            )
            if data:
                return data
        except Exception:
            pass

    try:
        data = await edit_message_caption_colored(
            chat_id=chat_id,
            message_id=message_id,
            caption=caption,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
            quiet_mismatch=True,
        )
        if data:
            return data
    except Exception as e:
        logger.debug(f"smart_edit_message_caption: editMessageCaption failed: {e}")

    try:
        data = await edit_message_text_colored(
            chat_id=chat_id,
            message_id=message_id,
            text=caption,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
            quiet_mismatch=True,
        )
        if data:
            return data
    except Exception as e:
        logger.debug(f"smart_edit_message_caption: editMessageText fallback failed: {e}")

    try:
        return await app.edit_message_caption(
            chat_id=chat_id,
            message_id=message_id,
            caption=caption,
            parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
    except Exception:
        pass

    try:
        return await app.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=caption,
            parse_mode=enums.ParseMode.HTML if parse_mode == "HTML" else enums.ParseMode.MARKDOWN,
            reply_markup=buttons_to_inline_markup(reply_markup) if reply_markup else None,
        )
    except Exception as e:
        logger.warning(f"smart_edit_message_caption: all paths failed: {e}")
        return None

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
