# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

from pyrogram.enums import ParseMode

from KrutikMusic import app
from KrutikMusic.utils.database import is_on_off
from config import LOGGER_ID


async def play_logs(message, streamtype, query: str = None):
    if await is_on_off(2):
        if query is None:
            try:
                query = message.text.split(None, 1)[1]
            except Exception:
                query = "—"

        logger_text = f"""
<b>{app.mention} ᴘʟᴀʏ ʟᴏɢ</b>

<b>ᴄʜᴀᴛ ɪᴅ :</b> <code>{message.chat.id}</code>
<b>ᴄʜᴀᴛ ɴᴀᴍᴇ :</b> {message.chat.title}
<b>ᴄʜᴀᴛ ᴜsᴇʀɴᴀᴍᴇ :</b> @{message.chat.username}

<b>ᴜsᴇʀ ɪᴅ :</b> <code>{message.from_user.id}</code>
<b>ɴᴀᴍᴇ :</b> {message.from_user.mention}
<b>ᴜsᴇʀɴᴀᴍᴇ :</b> @{message.from_user.username}

<b>ǫᴜᴇʀʏ :</b> {query}
<b>sᴛʀᴇᴀᴍᴛʏᴘᴇ :</b> {streamtype}"""
        if message.chat.id != LOGGER_ID:
            sent = False
            if getattr(app, "logger_accessible", False) or not getattr(app, "logger_via_assistant", False):
                try:
                    await app.send_message(
                        chat_id=LOGGER_ID,
                        text=logger_text,
                        parse_mode=ParseMode.HTML,
                        disable_web_page_preview=True,
                    )
                    app.logger_accessible = True
                    sent = True
                except Exception:
                    pass
            if not sent:
                try:
                    from KrutikMusic import userbot
                    for idx in range(1, 6):
                        ub = userbot.get_client(idx) if hasattr(userbot, "get_client") else None
                        if ub and getattr(ub, "logger_accessible", False):
                            await ub.send_message(
                                chat_id=LOGGER_ID,
                                text=logger_text,
                                parse_mode=ParseMode.HTML,
                                disable_web_page_preview=True,
                            )
                            app.logger_via_assistant = True
                            break
                except Exception:
                    pass
        return

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
