# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import logging
import os
from random import randint
from typing import Union

import config
from KrutikMusic import Carbon, YouTube, app
from KrutikMusic.core.call import KRUTIK
from KrutikMusic.misc import db
from KrutikMusic.utils.stream.autoplay import is_autoplay_on
from KrutikMusic.utils.database import add_active_video_chat, is_active_chat
from KrutikMusic.utils.exceptions import AssistantErr
from KrutikMusic.utils.inline import aq_markup, close_markup
from KrutikMusic.utils.colored_buttons import (
    buttons_to_inline_markup,
    smart_send_photo,
    smart_send_message,
)
from KrutikMusic.utils.pastebin import KRUTIKBIN
from KrutikMusic.utils.stream.queue import put_queue, put_queue_index
from KrutikMusic.utils.thumbnails import get_thumb
from KrutikMusic.utils.errors import capture_internal_err

logger = logging.getLogger(__name__)


def _store_mystic(chat_id, run, markup_type, caption=None):
    """Safely store mystic message reference — guards against race conditions."""
    try:
        playlist = db.get(chat_id)
        if not playlist or not isinstance(playlist, list) or len(playlist) == 0:
            # Queue was cleared while photo was being sent — store for later
            if chat_id not in db or not isinstance(db.get(chat_id), list):
                db[chat_id] = [{}]
            if len(db[chat_id]) == 0:
                db[chat_id].append({})
        db[chat_id][0]["mystic"] = run
        db[chat_id][0]["markup"] = markup_type
        if caption:
            db[chat_id][0]["base_caption"] = caption
    except Exception:
        pass


async def _send_or_fallback_photo(_, original_chat_id, img, caption, colored_buttons, db_ref, chat_id, markup_type):
    """Send photo with colored buttons (Bot API first, Pyrogram fallback)."""
    try:
        run = await smart_send_photo(
            chat_id=original_chat_id,
            photo=img,
            caption=caption,
            reply_markup=colored_buttons,
        )
        _store_mystic(chat_id, run, markup_type, caption)
    except Exception:
        pass


async def _send_or_fallback_message(chat_id, text, colored_buttons):
    """Send message with colored buttons (Bot API first, Pyrogram fallback)."""
    return await smart_send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=colored_buttons,
    )


@capture_internal_err
async def stream(
    _,
    mystic,
    user_id,
    result,
    chat_id,
    user_name,
    original_chat_id,
    video: Union[bool, str] = None,
    streamtype: Union[bool, str] = None,
    spotify: Union[bool, str] = None,
    forceplay: Union[bool, str] = None,
) -> None:
    if not result:
        return

    forceplay = bool(forceplay)
    is_video = bool(video)

    if forceplay:
        await KRUTIK.force_stop_stream(chat_id)

    if streamtype == "playlist":
        msg = f"{_['play_19']}\n\n"
        count = 0
        position = 0

        # ── LIGHTNING-FAST: fetch all playlist details in parallel ──────────────
        limited = list(result)[:config.PLAYLIST_FETCH_LIMIT]

        async def _fetch_details(search):
            try:
                return await YouTube.details(search, videoid=search)
            except Exception:
                return None

        details_list = await asyncio.gather(*[_fetch_details(s) for s in limited])
        # ────────────────────────────────────────────────────────────────────────

        for details in details_list:
            if details is None:
                continue
            title, duration_min, duration_sec, thumbnail, vidid = details

            if str(duration_min) == "None":
                continue
            if duration_sec and duration_sec > config.DURATION_LIMIT:
                continue

            if await is_active_chat(chat_id):
                await put_queue(
                    chat_id,
                    original_chat_id,
                    f"vid_{vidid}",
                    title,
                    duration_min,
                    user_name,
                    vidid,
                    user_id,
                    "video" if is_video else "audio",
                )
                position = len(db.get(chat_id)) - 1
                count += 1
                msg += f"{count}. {title[:70]}\n"
                msg += f"{_['play_20']} {position}\n\n"
            else:
                if not forceplay:
                    db[chat_id] = []
                thumb_task = asyncio.create_task(get_thumb(vidid))

                from KrutikMusic.utils.downloader import YouTubeAuthError, YouTubeUnavailableError
                file_path = None
                direct = False
                try:
                    file_path, direct = await YouTube.download(
                        vidid, mystic, video=is_video, videoid=vidid, title=title
                    )
                except YouTubeAuthError as e:
                    logger.error(f"🔐 YouTube authentication failure for {vidid}: {e}")
                    thumb_task.cancel()
                    raise AssistantErr(_["play_14"])
                except YouTubeUnavailableError as e:
                    logger.warning(f"⚠️ YouTube track unavailable ({vidid}): {e}")
                    thumb_task.cancel()
                    raise AssistantErr(_["play_14"])
                except Exception as e:
                    logger.error(f"❌ YouTube extraction error for {vidid}: {e}")
                    thumb_task.cancel()
                    raise AssistantErr(_["play_14"])

                if not file_path:
                    thumb_task.cancel()
                    raise AssistantErr(_["play_14"])

                try:
                    await KRUTIK.join_call(
                        chat_id,
                        original_chat_id,
                        file_path,
                        video=is_video,
                        image=thumbnail,
                        videoid=vidid,
                    )
                except Exception:
                    thumb_task.cancel()
                    if not await is_active_chat(chat_id):
                        db.pop(chat_id, None)
                    raise

                if not await is_active_chat(chat_id):
                    thumb_task.cancel()
                    raise AssistantErr(_["call_6"])
                await put_queue(
                    chat_id,
                    original_chat_id,
                    file_path if direct else f"vid_{vidid}",
                    title,
                    duration_min,
                    user_name,
                    vidid,
                    user_id,
                    "video" if is_video else "audio",
                    forceplay=forceplay,
                )
                try:
                    img = await thumb_task
                except Exception:
                    img = await get_thumb(vidid)
                ap_status = await is_autoplay_on(chat_id)
                from KrutikMusic.utils.inline.play import colored_stream_markup
                colored_buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                caption = _["stream_1"].format(
                    f"https://t.me/{app.username}?start=info_{vidid}",
                    title[:23],
                    duration_min,
                    user_name,
                )
                await _send_or_fallback_photo(_, original_chat_id, img, caption, colored_buttons, None, chat_id, "stream")

        if count == 0:
            return
        link = await KRUTIKBIN(msg)
        lines = msg.count("\n")
        car = os.linesep.join(msg.split(os.linesep)[:17]) if lines >= 17 else msg
        try:
            carbon = await Carbon.generate(car, randint(100, 10000000))
            playlist_photo = carbon
        except Exception:
            playlist_photo = config.PLAYLIST_IMG_URL
        upl = close_markup(_)
        final_position = len(db.get(chat_id) or []) - 1
        if final_position < 0:
            final_position = 0
        return await _send_or_fallback_photo(
            _,
            original_chat_id,
            playlist_photo,
            _["play_21"].format(final_position, link),
            upl,
            None,
            chat_id,
            "close",
        )

    elif streamtype == "youtube":
        link = result["link"]
        vidid = result["vidid"]
        title = (result["title"]).title()
        duration_min = result["duration_min"]
        thumbnail = result["thumb"]

        thumb_task = asyncio.create_task(get_thumb(vidid))

        from KrutikMusic.utils.downloader import YouTubeAuthError, YouTubeUnavailableError
        file_path = None
        direct = False
        try:
            file_path, direct = await YouTube.download(
                vidid, mystic, video=is_video, videoid=vidid, title=title
            )
            if file_path:
                logger.info(
                    f"✅ YouTube {'VIDEO' if is_video else 'AUDIO'} extraction success for {vidid} ({title[:30]} | video={is_video})"
                )
            else:
                logger.warning(
                    f"⚠️ YouTube {'VIDEO' if is_video else 'AUDIO'} extraction returned None for {vidid} ({title[:30]} | video={is_video})"
                )
        except YouTubeAuthError as e:
            logger.error(f"🔐 YouTube authentication error for {vidid} (skipping retries): {e}")
            thumb_task.cancel()
            raise AssistantErr(_["play_14"])
        except YouTubeUnavailableError as e:
            logger.warning(f"⚠️ YouTube track unavailable for {vidid} (skipping retries): {e}")
            thumb_task.cancel()
            raise AssistantErr(_["play_14"])
        except Exception as e:
            logger.error(f"❌ YouTube download error for {vidid}: {type(e).__name__}: {e}")
            thumb_task.cancel()
            raise AssistantErr(_["play_14"])

        if not file_path:
            thumb_task.cancel()
            raise AssistantErr(_["play_14"])

        target_mode = "video" if is_video else "audio"
        current_queue = db.get(chat_id)
        is_mode_switch_same_track = (
            await is_active_chat(chat_id)
            and isinstance(current_queue, list)
            and len(current_queue) == 1
            and current_queue[0].get("vidid") == vidid
            and current_queue[0].get("streamtype") != target_mode
        )
        if is_mode_switch_same_track:
            logger.info(
                f"🔄 Switching active stream mode in {chat_id} for {vidid} from "
                f"{current_queue[0].get('streamtype')} to {target_mode} (video={is_video})"
            )

        if await is_active_chat(chat_id) and current_queue and not is_mode_switch_same_track:
            thumb_task.cancel()
            await put_queue(
                chat_id,
                original_chat_id,
                file_path if direct else f"vid_{vidid}",
                title,
                duration_min,
                user_name,
                vidid,
                user_id,
                target_mode,
            )
            position = len(db.get(chat_id)) - 1
            logger.info(
                f"📥 Queued {target_mode.upper()} track in {chat_id} at position #{position}: {vidid} ({title[:30]} | video={is_video})"
            )
            button = aq_markup(_, chat_id)
            await _send_or_fallback_message(
                original_chat_id,
                _["queue_4"].format(position, title[:27], duration_min, user_name),
                button,
            )
        else:
            if not forceplay or is_mode_switch_same_track:
                db[chat_id] = []
            try:
                await KRUTIK.join_call(
                    chat_id,
                    original_chat_id,
                    file_path,
                    video=is_video,
                    image=thumbnail,
                    videoid=vidid,
                )
            except Exception:
                thumb_task.cancel()
                if not await is_active_chat(chat_id):
                    db.pop(chat_id, None)
                raise

            if not await is_active_chat(chat_id):
                thumb_task.cancel()
                raise AssistantErr(_["call_6"])
            await put_queue(
                chat_id,
                original_chat_id,
                file_path if direct else f"vid_{vidid}",
                title,
                duration_min,
                user_name,
                vidid,
                user_id,
                target_mode,
                forceplay=forceplay,
            )
            try:
                img = await thumb_task
            except Exception:
                img = await get_thumb(vidid)
            ap_status = await is_autoplay_on(chat_id)
            from KrutikMusic.utils.inline.play import colored_stream_markup
            colored_buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            caption = _["stream_1"].format(
                f"https://t.me/{app.username}?start=info_{vidid}",
                title[:23],
                duration_min,
                user_name,
            )
            await _send_or_fallback_photo(_, original_chat_id, img, caption, colored_buttons, None, chat_id, "stream")

    elif streamtype == "soundcloud":
        file_path = result["filepath"]
        title = result["title"]
        duration_min = result["duration_min"]
        if not file_path:
            raise AssistantErr(_["play_14"])

        if await is_active_chat(chat_id):
            await put_queue(
                chat_id,
                original_chat_id,
                file_path,
                title,
                duration_min,
                user_name,
                streamtype,
                user_id,
                "audio",
            )
            position = len(db.get(chat_id)) - 1
            button = aq_markup(_, chat_id)
            await _send_or_fallback_message(
                original_chat_id,
                _["queue_4"].format(position, title[:27], duration_min, user_name),
                button,
            )
        else:
            if not forceplay:
                db[chat_id] = []
            await KRUTIK.join_call(chat_id, original_chat_id, file_path, video=False)
            if not await is_active_chat(chat_id):
                raise AssistantErr(_["call_6"])
            await put_queue(
                chat_id,
                original_chat_id,
                file_path,
                title,
                duration_min,
                user_name,
                streamtype,
                user_id,
                "audio",
                forceplay=forceplay,
            )
            ap_status = await is_autoplay_on(chat_id)
            from KrutikMusic.utils.inline.play import colored_stream_markup
            colored_buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            caption = _["stream_1"].format(
                config.SUPPORT_CHAT, title[:23], duration_min, user_name
            )
            await _send_or_fallback_photo(
                _,
                original_chat_id,
                config.SOUNCLOUD_IMG_URL,
                caption,
                colored_buttons,
                None,
                chat_id,
                "tg",
            )

    elif streamtype == "telegram":
        file_path = result["path"]
        link = result["link"]
        title = (result["title"]).title()
        duration_min = result["dur"]
        if not file_path:
            raise AssistantErr(_["play_14"])

        if await is_active_chat(chat_id):
            await put_queue(
                chat_id,
                original_chat_id,
                file_path,
                title,
                duration_min,
                user_name,
                streamtype,
                user_id,
                "video" if is_video else "audio",
            )
            position = len(db.get(chat_id)) - 1
            button = aq_markup(_, chat_id)
            await _send_or_fallback_message(
                original_chat_id,
                _["queue_4"].format(position, title[:27], duration_min, user_name),
                button,
            )
        else:
            if not forceplay:
                db[chat_id] = []
            await KRUTIK.join_call(chat_id, original_chat_id, file_path, video=is_video)
            if not await is_active_chat(chat_id):
                raise AssistantErr(_["call_6"])
            await put_queue(
                chat_id,
                original_chat_id,
                file_path,
                title,
                duration_min,
                user_name,
                streamtype,
                user_id,
                "video" if is_video else "audio",
                forceplay=forceplay,
            )
            if is_video:
                await add_active_video_chat(chat_id)
            ap_status = await is_autoplay_on(chat_id)
            from KrutikMusic.utils.inline.play import colored_stream_markup
            colored_buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            caption = _["stream_1"].format(link, title[:23], duration_min, user_name)
            await _send_or_fallback_photo(
                _,
                original_chat_id,
                config.TELEGRAM_VIDEO_URL if is_video else config.TELEGRAM_AUDIO_URL,
                caption,
                colored_buttons,
                None,
                chat_id,
                "tg",
            )

    elif streamtype == "live":
        link = result["link"]
        vidid = result["vidid"]
        title = (result["title"]).title()
        thumbnail = result["thumb"]
        duration_min = "Live Track"

        if await is_active_chat(chat_id):
            await put_queue(
                chat_id,
                original_chat_id,
                f"live_{vidid}",
                title,
                duration_min,
                user_name,
                vidid,
                user_id,
                "video" if is_video else "audio",
            )
            position = len(db.get(chat_id)) - 1
            button = aq_markup(_, chat_id)
            await _send_or_fallback_message(
                original_chat_id,
                _["queue_4"].format(position, title[:27], duration_min, user_name),
                button,
            )
        else:
            if not forceplay:
                db[chat_id] = []
            thumb_task = asyncio.create_task(get_thumb(vidid))
            n, file_path = await YouTube.video(link)
            if n == 0:
                thumb_task.cancel()
                raise AssistantErr(_["str_3"])
            if not file_path:
                thumb_task.cancel()
                raise AssistantErr(_["play_14"])

            await KRUTIK.join_call(
                chat_id,
                original_chat_id,
                file_path,
                video=is_video,
                image=thumbnail or None,
            )
            await put_queue(
                chat_id,
                original_chat_id,
                f"live_{vidid}",
                title,
                duration_min,
                user_name,
                vidid,
                user_id,
                "video" if is_video else "audio",
                forceplay=forceplay,
            )
            try:
                img = await thumb_task
            except Exception:
                img = await get_thumb(vidid)
            ap_status = await is_autoplay_on(chat_id)
            from KrutikMusic.utils.inline.play import colored_stream_markup
            colored_buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            caption = _["stream_1"].format(
                f"https://t.me/{app.username}?start=info_{vidid}",
                title[:23],
                duration_min,
                user_name,
            )
            await _send_or_fallback_photo(_, original_chat_id, img, caption, colored_buttons, None, chat_id, "tg")

    elif streamtype == "index":
        link = result
        title = "ɪɴᴅᴇx ᴏʀ ᴍ3ᴜ8 ʟɪɴᴋ"
        duration_min = "00:00"

        if await is_active_chat(chat_id):
            await put_queue_index(
                chat_id,
                original_chat_id,
                "index_url",
                title,
                duration_min,
                user_name,
                link,
                "video" if is_video else "audio",
            )
            position = len(db.get(chat_id)) - 1
            button = aq_markup(_, chat_id)
            await _send_or_fallback_message(
                original_chat_id,
                _["queue_4"].format(position, title[:27], duration_min, user_name),
                button,
            )
        else:
            if not forceplay:
                db[chat_id] = []
            await KRUTIK.join_call(
                chat_id,
                original_chat_id,
                link,
                video=is_video,
            )
            await put_queue_index(
                chat_id,
                original_chat_id,
                "index_url",
                title,
                duration_min,
                user_name,
                link,
                "video" if is_video else "audio",
                forceplay=forceplay,
            )
            ap_status = await is_autoplay_on(chat_id)
            from KrutikMusic.utils.inline.play import colored_stream_markup
            colored_buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            caption = _["stream_2"].format(user_name)
            await _send_or_fallback_photo(
                _,
                original_chat_id,
                config.STREAM_IMG_URL,
                caption,
                colored_buttons,
                None,
                chat_id,
                "tg",
            )
            await mystic.delete()

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
