# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

from typing import Union

class AssistantErr(Exception):
    def __init__(self, errr: str):
        super().__init__(errr)

IGNORED_ERROR_KEYWORDS = [
    "Nᴏ ᴀᴄᴛɪᴠᴇ ᴠɪᴅᴇᴏᴄʜᴀᴛ ғᴏᴜɴᴅ",
    "لم يتم العثور على مكالمة فيديو نشطة",
    "Активный видеочат не найден",
    "Aktif video sohbet bulunamadı",
    "कोई सक्रिय वीडियोचैट नहीं मिला।",
    "No active group call",
    "not found",
    "GROUPCALL_INVALID",
    "CHAT_NOT_MODIFIED",
    "MESSAGE_NOT_MODIFIED",
    "Query is too old",
    "Peer id invalid",
    "USER_NOT_PARTICIPANT",
    "CHANNEL_PRIVATE",
]

IGNORED_EXCEPTION_CLASSES = (
    
)

def is_ignored_error(err: Union[Exception, BaseException]) -> bool:
    if isinstance(err, IGNORED_EXCEPTION_CLASSES):
        return True

    err_str = str(err).lower()
    return any(keyword.lower() in err_str for keyword in IGNORED_ERROR_KEYWORDS)

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
