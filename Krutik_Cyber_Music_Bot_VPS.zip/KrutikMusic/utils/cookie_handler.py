# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import http.cookiejar
import logging
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from urllib.parse import urlsplit

import requests

from config import COOKIE_URL
from KrutikMusic.utils.database import get_setting
from KrutikMusic.utils.errors import capture_internal_err

logger = logging.getLogger("KrutikMusic.cookies")

COOKIE_PATH = Path("KrutikMusic/assets/cookies.txt").resolve()

_YT_AUTH_COOKIE_NAMES = {
    "SID",
    "HSID",
    "SSID",
    "APISID",
    "SAPISID",
    "LOGIN_INFO",
    "__Secure-1PSID",
    "__Secure-3PSID",
    "__Secure-1PAPISID",
    "__Secure-3PAPISID",
}


def _extract_paste_id(url: str) -> str:
    path = urlsplit(url).path.rstrip("/")
    parts = [p for p in path.split("/") if p]
    return parts[-1] if parts else ""


def resolve_raw_cookie_url(url: str) -> str:
    url = (url or "").strip()
    low = url.lower()

    if "pastebin.com/" in low and "/raw/" not in low:
        paste_id = _extract_paste_id(url)
        return f"https://pastebin.com/raw/{paste_id}" if paste_id else url

    if "batbin.me/" in low and "/raw/" not in low:
        paste_id = _extract_paste_id(url)
        return f"https://batbin.me/raw/{paste_id}" if paste_id else url

    return url


def normalize_and_validate_cookies(raw_text: str) -> Tuple[str, Dict[str, Union[int, bool]]]:
    """Validate Netscape cookie text and normalize expired client-side timestamps.

    MozillaCookieJar (used internally by yt-dlp) silently drops any cookie whose
    Netscape 'expires' column is < time.time(). Normalizing past non-zero expiry
    timestamps ensures yt-dlp actually sends the session cookies to YouTube.
    Never logs cookie values or secret tokens.
    """
    text = (raw_text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        raise ValueError("Cookie content is empty.")

    lines = text.split("\n")
    has_header = any(
        l.strip().startswith("# Netscape HTTP Cookie File")
        or l.strip().startswith("# HTTP Cookie File")
        for l in lines[:5]
    )
    if not has_header:
        raise ValueError("⚠️ ɪɴᴠᴀʟɪᴅ ᴄᴏᴏᴋɪᴇ ꜰᴏʀᴍᴀᴛ. ɴᴇᴇᴅs ɴᴇᴛsᴄᴀᴘᴇ ꜰᴏʀᴍᴀᴛ.")

    now = int(time.time())
    min_valid_exp = now + 86400 * 30
    target_exp = str(now + 86400 * 365)

    normalized_lines: List[str] = ["# Netscape HTTP Cookie File", "# https://curl.haxx.se/rfc/cookie_spec.html", "# This is a generated file! Do not edit.", ""]
    total_cookies = 0
    yt_cookies = 0
    auth_cookies_present = set()
    refreshed_timestamps = 0

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#") and not stripped.startswith("#HttpOnly_"):
            continue
        if "\t" not in line:
            continue
        parts = line.split("\t")
        if len(parts) < 7:
            continue

        domain, domain_flag, path, secure, expires, name, value = (
            parts[0].strip(),
            parts[1].strip().upper(),
            parts[2].strip() or "/",
            parts[3].strip().upper(),
            parts[4].strip(),
            parts[5].strip(),
            parts[6].strip(),
        )

        # Ensure domain_specified flag matches leading dot for strict MozillaCookieJar
        check_domain = domain[len("#HttpOnly_"):] if domain.startswith("#HttpOnly_") else domain
        domain_flag = "TRUE" if check_domain.startswith(".") else "FALSE"
        secure = "TRUE" if secure == "TRUE" else "FALSE"

        try:
            exp_int = int(expires)
            if 0 < exp_int < min_valid_exp:
                expires = target_exp
                refreshed_timestamps += 1
        except ValueError:
            expires = target_exp
            refreshed_timestamps += 1

        normalized_lines.append(
            "\t".join([domain, domain_flag, path, secure, expires, name, value])
        )
        total_cookies += 1

        if "youtube.com" in check_domain or "google.com" in check_domain:
            yt_cookies += 1
            if name in _YT_AUTH_COOKIE_NAMES and value:
                auth_cookies_present.add(name)

    if total_cookies == 0:
        raise ValueError("⚠️ No valid Netscape cookie entries found.")

    stats = {
        "total_cookies": total_cookies,
        "yt_cookies": yt_cookies,
        "auth_cookie_count": len(auth_cookies_present),
        "has_auth": len(auth_cookies_present) >= 2,
        "refreshed_timestamps": refreshed_timestamps,
    }
    return "\n".join(normalized_lines) + "\n", stats


def ensure_valid_cookie_file() -> Optional[str]:
    """Ensure COOKIE_PATH exists, is normalized, and loads cleanly in MozillaCookieJar."""
    try:
        if not COOKIE_PATH.exists() or COOKIE_PATH.stat().st_size < 50:
            return None
        raw = COOKIE_PATH.read_text(encoding="utf-8", errors="ignore")
        normalized, stats = normalize_and_validate_cookies(raw)
        if stats["refreshed_timestamps"] > 0 or normalized != raw:
            COOKIE_PATH.write_text(normalized, encoding="utf-8")

        cj = http.cookiejar.MozillaCookieJar(str(COOKIE_PATH))
        cj.load(ignore_discard=True, ignore_expires=False)
        if len(cj) == 0:
            return None
        return str(COOKIE_PATH)
    except Exception as e:
        logger.warning(f"⚠️ Cookie file validation failed: {e}")
        return None


def get_valid_cookie_path() -> Optional[str]:
    """Return absolute path to verified Netscape cookie file, or None if unavailable."""
    try:
        if COOKIE_PATH.exists() and COOKIE_PATH.stat().st_size > 100:
            return str(COOKIE_PATH)
    except Exception:
        pass
    return None


# Normalize any existing cookies.txt on import so yt-dlp never sees expired timestamps
ensure_valid_cookie_file()


@capture_internal_err
async def fetch_and_store_cookies():
    url = await get_setting("COOKIE_URL", COOKIE_URL)
    if not url:
        existing = ensure_valid_cookie_file()
        if existing:
            return existing
        raise EnvironmentError("⚠️ ᴄᴏᴏᴋɪᴇ_ᴜʀʟ ɴᴏᴛ sᴇᴛ ɪɴ ᴇɴᴠ ᴏʀ ᴅʙ.")

    raw_url = resolve_raw_cookie_url(url)

    try:
        response = await asyncio.to_thread(
            requests.get,
            raw_url,
            timeout=15,
            headers={"User-Agent": "krutik-cookie-fetcher/1.0"},
        )
        response.raise_for_status()
    except Exception as e:
        existing = ensure_valid_cookie_file()
        if existing:
            logger.info("Using existing validated local cookies.txt after remote fetch error.")
            return existing
        raise ConnectionError(f"⚠️ ᴄᴀɴ'ᴛ ꜰᴇᴛᴄʜ ᴄᴏᴏᴋɪᴇs:\n{e}")

    cookies_raw = (response.text or "").strip()
    if len(cookies_raw) < 100:
        raise ValueError("⚠️ ᴄᴏᴏᴋɪᴇ ᴄᴏɴᴛᴇɴᴛ ᴛᴏᴏ sʜᴏʀᴛ. ᴘᴏssɪʙʟʏ ɪɴᴠᴀʟɪᴅ.")

    normalized_cookies, stats = normalize_and_validate_cookies(cookies_raw)

    COOKIE_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        COOKIE_PATH.write_text(normalized_cookies, encoding="utf-8")
    except Exception as e:
        raise IOError(f"⚠️ ғᴀɪʟᴇᴅ ᴛᴏ sᴀᴠᴇ ᴄᴏᴏᴋɪᴇs: {e}")

    verified_path = ensure_valid_cookie_file()
    if not verified_path:
        raise ValueError("⚠️ Cookie file failed MozillaCookieJar verification after write.")

    logger.info(
        f"Cookies validated: total={stats['total_cookies']}, "
        f"youtube_google={stats['yt_cookies']}, "
        f"auth_keys={stats['auth_cookie_count']}, "
        f"has_auth={stats['has_auth']}"
    )
    return verified_path

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
