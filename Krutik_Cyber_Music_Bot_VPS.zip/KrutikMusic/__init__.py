# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

# ── Pyrogram / PyTgCalls Compatibility Layer ────────────────
import sys
from pathlib import Path

_VENV_SITE = Path(__file__).resolve().parents[1] / ".venv" / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages"
if _VENV_SITE.exists() and str(_VENV_SITE) not in sys.path:
    sys.path.insert(0, str(_VENV_SITE))

import pyrogram.errors

if not hasattr(pyrogram.errors, "GroupcallForbidden"):
    _found = False
    for _sub in ("bad_request_400", "forbidden_403"):
        try:
            import importlib
            _mod = importlib.import_module(f"pyrogram.errors.exceptions.{_sub}")
            if hasattr(_mod, "GroupcallForbidden"):
                setattr(pyrogram.errors, "GroupcallForbidden", getattr(_mod, "GroupcallForbidden"))
                _found = True
                break
        except Exception:
            pass
    if not _found:
        class GroupcallForbidden(pyrogram.errors.RPCError):
            """The group call is forbidden."""
            ID = "GROUPCALL_FORBIDDEN"
        setattr(pyrogram.errors, "GroupcallForbidden", GroupcallForbidden)

# ── Pyrogram Types / Errors Patch ───────────────────────────
import pyrogram.types
if not hasattr(pyrogram.types, "ChatAdministratorRights"):
    if hasattr(pyrogram.types, "ChatPrivileges"):
        pyrogram.types.ChatAdministratorRights = pyrogram.types.ChatPrivileges
    else:
        # Fallback dummy class if both missing (unlikely but safe)
        class ChatAdministratorRights:
            def __init__(self, **kwargs): pass
        pyrogram.types.ChatAdministratorRights = ChatAdministratorRights

if not hasattr(pyrogram.errors, "TopicClosed"):
    try:
        from pyrogram.errors.exceptions.bad_request_400 import TopicClosed
        pyrogram.errors.TopicClosed = TopicClosed
    except ImportError:
        class TopicClosed(pyrogram.errors.RPCError):
            ID = "TOPIC_CLOSED"
        pyrogram.errors.TopicClosed = TopicClosed

# ── Kurigram mention fix ──────────────────────────────────────
# Kurigram ka User.mention bina quotes ka anchor banata hai:
#     <a href=tg://user?id=123>Name</a>
# Telegram Bot API usse parse nahi kar pata ("Unexpected end of name
# token") → Bot API path fail → buttons colorless fallback me jaate
# hain. Isliye mention ko QUOTED anchor ke saath override karte hain.
try:
    from pyrogram.types import User as _KurigramUser

    def _quoted_mention(self):
        name = self.first_name or "Deleted Account"
        return f'<a href="tg://user?id={self.id}">{name}</a>'

    _KurigramUser.mention = property(_quoted_mention)
except Exception:
    pass

from KrutikMusic.core.bot import KRUTIK
from KrutikMusic.core.dir import dirr
from KrutikMusic.core.git import git
from KrutikMusic.core.userbot import Userbot
from KrutikMusic.misc import dbb, heroku

from .logging import LOGGER

dirr()
git()
dbb()
heroku()

app = KRUTIK()
userbot = Userbot()

from .platforms import *

Apple = AppleAPI()
Carbon = CarbonAPI()
SoundCloud = SoundAPI()
Spotify = SpotifyAPI()
Resso = RessoAPI()
Telegram = TeleAPI()
YouTube = YouTubeAPI()

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
