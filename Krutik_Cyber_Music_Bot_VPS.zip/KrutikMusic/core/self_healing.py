# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC PREMIUM EDITION 🌺
#   Self-Healing Engine, Dependency Optimizer & Watchdog
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import importlib
import importlib.metadata
import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[2]
VENV_PYTHON = PROJECT_ROOT / ".venv" / "bin" / "python"
REQUIREMENTS_FILE = PROJECT_ROOT / "requirements.txt"
CACHE_DIR = PROJECT_ROOT / "cache"
PID_LOCK_FILE = CACHE_DIR / "krutik_bot.pid"
HEARTBEAT_FILE = CACHE_DIR / "heartbeat.json"
RESTART_STATE_FILE = CACHE_DIR / "restart_state.json"

# Required dependencies: (pip_package_spec, import_module_name, dist_metadata_name, critical)
REQUIRED_DEPENDENCIES: List[Tuple[str, str, str, bool]] = [
    ("python-dotenv>=1.0.1", "dotenv", "python-dotenv", True),
    ("kurigram==2.1.35", "pyrogram", "kurigram", True),
    ("TgCrypto>=1.2.5", "tgcrypto", "TgCrypto", True),
    ("py-tgcalls==2.2.11", "pytgcalls", "py-tgcalls", True),
    ("ntgcalls>=1.3.0", "ntgcalls", "ntgcalls", True),
    ("yt-dlp>=2025.1.1", "yt_dlp", "yt-dlp", True),
    ("py-yt-search>=0.2", "py_yt", "py-yt-search", True),
    ("motor>=3.3.0", "motor", "motor", True),
    ("pymongo>=4.6.0", "pymongo", "pymongo", True),
    ("dnspython>=2.6.0", "dns", "dnspython", True),
    ("mongomock>=4.1.2", "mongomock", "mongomock", False),
    ("certifi>=2024.2.2", "certifi", "certifi", True),
    ("aiohttp>=3.9.0", "aiohttp", "aiohttp", True),
    ("aiofiles>=23.2.1", "aiofiles", "aiofiles", True),
    ("aiosqlite>=0.20.0", "aiosqlite", "aiosqlite", True),
    ("Pillow>=10.2.0", "PIL", "pillow", True),
    ("psutil>=5.9.8", "psutil", "psutil", True),
    ("requests>=2.31.0", "requests", "requests", True),
    ("urllib3>=2.2.0", "urllib3", "urllib3", True),
    ("beautifulsoup4>=4.12.3", "bs4", "beautifulsoup4", True),
    ("PyYAML>=6.0.1", "yaml", "PyYAML", True),
    ("GitPython>=3.1.40", "git", "GitPython", False),
    ("gpytranslate>=1.5.1", "gpytranslate", "gpytranslate", False),
    ("heroku3>=5.2.1", "heroku3", "heroku3", False),
    ("speedtest-cli>=2.1.3", "speedtest", "speedtest-cli", False),
    ("spotipy>=2.23.0", "spotipy", "spotipy", False),
    ("Unidecode>=1.3.8", "unidecode", "Unidecode", False),
]


def ensure_venv_interpreter() -> None:
    """Re-exec into /app/applet/.venv/bin/python if invoked via system python3."""
    if VENV_PYTHON.exists():
        try:
            current_prefix = Path(sys.prefix).resolve()
            target_prefix = (PROJECT_ROOT / ".venv").resolve()
            if current_prefix != target_prefix:
                os.execv(str(VENV_PYTHON), [str(VENV_PYTHON), *sys.argv])
        except Exception:
            pass


def _get_package_version(dist_name: str, import_name: str) -> str:
    for candidate in (dist_name, import_name, "pyrogram", "kurigram"):
        try:
            return importlib.metadata.version(candidate)
        except Exception:
            continue
    try:
        mod = importlib.import_module(import_name)
        return str(getattr(mod, "__version__", "installed"))
    except Exception:
        return "unknown"


def verify_and_heal_dependencies(auto_install: bool = True) -> Dict[str, any]:
    """Verify all required packages, auto-install any missing ones, and log a health report."""
    missing_specs: List[str] = []
    report_rows: List[Dict[str, str]] = []

    for pip_spec, import_name, dist_name, is_critical in REQUIRED_DEPENDENCIES:
        try:
            importlib.import_module(import_name)
            ver = _get_package_version(dist_name, import_name)
            report_rows.append(
                {
                    "package": dist_name,
                    "module": import_name,
                    "version": ver,
                    "status": "OK",
                    "critical": is_critical,
                }
            )
        except Exception:
            missing_specs.append(pip_spec)
            report_rows.append(
                {
                    "package": dist_name,
                    "module": import_name,
                    "version": "-",
                    "status": "MISSING",
                    "critical": is_critical,
                }
            )

    healed_packages: List[str] = []
    if missing_specs and auto_install:
        print(
            f"[Self-Healing Engine] Missing dependencies detected ({len(missing_specs)}): "
            f"{', '.join(missing_specs)}. Installing automatically..."
        )
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-q", *missing_specs],
                cwd=str(PROJECT_ROOT),
                timeout=180,
            )
            importlib.invalidate_caches()
            for row in report_rows:
                if row["status"] == "MISSING":
                    try:
                        importlib.import_module(row["module"])
                        row["version"] = _get_package_version(row["package"], row["module"])
                        row["status"] = "HEALED"
                        healed_packages.append(row["package"])
                    except Exception:
                        row["status"] = "FAILED"
        except Exception as exc:
            print(f"[Self-Healing Engine] Auto-install error: {exc}")

    # Verify modern Pyrogram/Kurigram peer ID range support (-1004323863622 etc.)
    try:
        import pyrogram.utils as pyro_utils

        if getattr(pyro_utils, "MIN_CHANNEL_ID", 0) > -1009999999999:
            pyro_utils.MIN_CHANNEL_ID = -100999999999999
    except Exception:
        pass

    ok_count = sum(1 for r in report_rows if r["status"] in ("OK", "HEALED"))
    total_count = len(report_rows)
    failed_critical = [
        r["package"] for r in report_rows if r["status"] not in ("OK", "HEALED") and r["critical"]
    ]

    print("╔══════════════════════════════════════════════════════════════════╗")
    print(f"║ 🛡️  DEPENDENCY HEALTH REPORT ({ok_count}/{total_count} Verified | Python {sys.version.split()[0]}) ║")
    print("╠══════════════════════════════════════════════════════════════════╣")
    for r in report_rows:
        badge = "✅" if r["status"] in ("OK", "HEALED") else "❌"
        print(f"║ {badge} {r['package']:<20} ({r['module']:<13}) v{r['version']:<14} [{r['status']}]")
    print("╚══════════════════════════════════════════════════════════════════╝")

    return {
        "ok": len(failed_critical) == 0,
        "verified": ok_count,
        "total": total_count,
        "healed": healed_packages,
        "failed_critical": failed_critical,
        "rows": report_rows,
    }


_LOCK_FD: Optional[int] = None


def _is_pid_running_bot(pid: int) -> bool:
    if pid <= 0 or pid == os.getpid():
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        cmdline_path = Path(f"/proc/{pid}/cmdline")
        if cmdline_path.exists():
            cmd = cmdline_path.read_text(encoding="utf-8", errors="ignore")
            return "bot.py" in cmd or "KrutikMusic" in cmd
    except Exception:
        pass
    return True


def acquire_single_instance_lock() -> bool:
    """Acquire an OS-level flock + PID lock file so duplicate bot processes cannot run concurrently."""
    global _LOCK_FD
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    my_pid = os.getpid()

    if PID_LOCK_FILE.exists():
        try:
            data = json.loads(PID_LOCK_FILE.read_text(encoding="utf-8"))
            old_pid = int(data.get("pid", 0))
            if _is_pid_running_bot(old_pid):
                print(
                    f"[Self-Healing Engine] ⚠️ Another bot instance is already running (PID {old_pid}). "
                    f"Terminating stale process {old_pid} before starting PID {my_pid}..."
                )
                try:
                    os.kill(old_pid, 15)  # SIGTERM
                    for _ in range(25):
                        if not _is_pid_running_bot(old_pid):
                            break
                        time.sleep(0.15)
                    if _is_pid_running_bot(old_pid):
                        os.kill(old_pid, 9)  # SIGKILL
                        time.sleep(0.25)
                except Exception:
                    pass
        except Exception:
            pass

    # Also enforce kernel-level exclusive file lock (released automatically by OS on process exit)
    try:
        import fcntl

        lock_file_path = CACHE_DIR / "krutik_bot.lock"
        fd = os.open(str(lock_file_path), os.O_CREAT | os.O_RDWR, 0o644)
        locked = False
        for _ in range(20):
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
                break
            except BlockingIOError:
                time.sleep(0.15)
        if locked:
            _LOCK_FD = fd
            try:
                os.ftruncate(fd, 0)
                os.write(fd, f"{my_pid}\n".encode("utf-8"))
            except Exception:
                pass
        else:
            os.close(fd)
    except Exception:
        pass

    try:
        PID_LOCK_FILE.write_text(
            json.dumps({"pid": my_pid, "started_at": int(time.time())}),
            encoding="utf-8",
        )
    except Exception:
        pass
    return True


def release_single_instance_lock() -> None:
    """Remove PID lock file and release kernel flock if owned by the current process."""
    global _LOCK_FD
    if _LOCK_FD is not None:
        try:
            import fcntl

            fcntl.flock(_LOCK_FD, fcntl.LOCK_UN)
        except Exception:
            pass
        try:
            os.close(_LOCK_FD)
        except Exception:
            pass
        _LOCK_FD = None
    try:
        if PID_LOCK_FILE.exists():
            data = json.loads(PID_LOCK_FILE.read_text(encoding="utf-8"))
            if int(data.get("pid", 0)) == os.getpid():
                PID_LOCK_FILE.unlink(missing_ok=True)
    except Exception:
        pass



def record_restart_event(reason: str) -> float:
    """Record restart reason and compute controlled backoff delay to prevent rapid restart loops."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    now = time.time()
    history: List[Dict[str, any]] = []
    if RESTART_STATE_FILE.exists():
        try:
            raw = json.loads(RESTART_STATE_FILE.read_text(encoding="utf-8"))
            history = [e for e in raw.get("events", []) if now - float(e.get("ts", 0)) < 300]
        except Exception:
            history = []

    history.append({"ts": round(now, 2), "pid": os.getpid(), "reason": reason})
    recent_count = len(history)
    # Controlled exponential backoff: 0s on first start, then 3s, 6s, 12s, 25s, max 45s
    backoff = 0.0 if recent_count <= 1 else min(45.0, 3.0 * (2 ** (recent_count - 2)))

    try:
        RESTART_STATE_FILE.write_text(
            json.dumps(
                {
                    "last_reason": reason,
                    "recent_restarts_5m": recent_count,
                    "recommended_backoff_s": backoff,
                    "events": history[-15:],
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception:
        pass
    return backoff


def heal_sqlite_sessions() -> None:
    """Idempotently ensure Pyrogram/Kurigram .session SQLite files have VERSION=7 schema without losing auth_key."""
    import sqlite3

    prod_dcs = {
        1: "149.154.175.53",
        2: "149.154.167.51",
        3: "149.154.175.100",
        4: "149.154.167.91",
        5: "91.108.56.130",
        203: "91.105.192.100",
    }

    for sess_file in PROJECT_ROOT.glob("*.session"):
        if not sess_file.is_file() or sess_file.stat().st_size < 1024:
            continue
        try:
            conn = sqlite3.connect(str(sess_file), timeout=5.0)
            with conn:
                uname_cols = {r[1] for r in conn.execute("PRAGMA table_info(usernames)").fetchall()}
                if uname_cols and "username" not in uname_cols:
                    conn.execute("DROP TABLE usernames;")
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS usernames (id INTEGER, username TEXT, FOREIGN KEY (id) REFERENCES peers(id));"
                )
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS update_state (id INTEGER PRIMARY KEY, pts INTEGER, qts INTEGER, date INTEGER, seq INTEGER);"
                )
                conn.execute("CREATE INDEX IF NOT EXISTS idx_usernames_id ON usernames (id);")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_usernames_username ON usernames (username);")

                sess_cols = {r[1] for r in conn.execute("PRAGMA table_info(sessions)").fetchall()}
                if "server_address" not in sess_cols:
                    conn.execute("ALTER TABLE sessions ADD server_address TEXT;")
                if "port" not in sess_cols:
                    conn.execute("ALTER TABLE sessions ADD port INTEGER;")

                row = conn.execute("SELECT dc_id, server_address, port FROM sessions LIMIT 1").fetchone()
                if row:
                    dc_id, srv, prt = row
                    addr = prod_dcs.get(int(dc_id or 2), "149.154.167.51")
                    if not srv:
                        conn.execute("UPDATE sessions SET server_address = ?;", (addr,))
                    if not prt:
                        conn.execute("UPDATE sessions SET port = 443;")

                peer_cols = {r[1] for r in conn.execute("PRAGMA table_info(peers)").fetchall()}
                if "username" in peer_cols:
                    rows = conn.execute("SELECT id, username FROM peers WHERE username IS NOT NULL").fetchall()
                    for pid, uname in rows:
                        exists = conn.execute(
                            "SELECT 1 FROM usernames WHERE id = ? AND username = ?", (pid, uname)
                        ).fetchone()
                        if not exists:
                            conn.execute("INSERT INTO usernames (id, username) VALUES (?, ?)", (pid, uname))

                try:
                    import pyrogram.storage.sqlite_storage as _sq
                    target_ver = getattr(_sq.SQLiteStorage, "VERSION", 7)
                except Exception:
                    target_ver = 7
                conn.execute("UPDATE version SET number = ?;", (target_ver,))
            conn.close()
        except Exception as exc:
            print(f"[Self-Healing Engine] Session schema check warning for {sess_file.name}: {exc}")


def verify_environment_dirs() -> None:
    """Ensure required runtime directories and SQLite session schemas are healthy."""
    for folder in ("cache", "downloads", "playback", "KrutikMusic/assets/KRUTIK"):
        (PROJECT_ROOT / folder).mkdir(parents=True, exist_ok=True)
    heal_sqlite_sessions()
    try:
        if RESTART_STATE_FILE.exists():
            raw = json.loads(RESTART_STATE_FILE.read_text(encoding="utf-8"))
            if raw.get("recommended_backoff_s", 0) > 6:
                RESTART_STATE_FILE.unlink(missing_ok=True)
    except Exception:
        pass


async def heartbeat_and_self_heal_loop() -> None:
    """Periodic background health monitor: updates heartbeat.json and heals transient issues."""
    logger = logging.getLogger("KrutikMusic.SelfHealing")
    started_at = time.time()

    while True:
        try:
            import psutil
            from KrutikMusic import app, userbot
            from KrutikMusic.core.call import KRUTIK
            from KrutikMusic.core.mongo import mongodb
            from KrutikMusic.core.userbot import assistants
            from KrutikMusic.utils.cookie_handler import get_valid_cookie_path

            proc = psutil.Process(os.getpid())
            mem_mb = round(proc.memory_info().rss / (1024 * 1024), 2)
            cpu_pct = round(proc.cpu_percent(interval=None), 1)

            # 1. Verify MongoDB connectivity & auto-reconnect if needed
            mongo_ok = False
            try:
                ping_res = await asyncio.wait_for(mongodb.command("ping"), timeout=5.0)
                mongo_ok = bool(ping_res and ping_res.get("ok"))
            except Exception as db_exc:
                logger.warning(f"⚠️ [Self-Healing] MongoDB ping failed ({db_exc}); triggering reconnect check...")
                if hasattr(mongodb, "ensure_connected"):
                    mongo_ok = await mongodb.ensure_connected()

            # 2. Verify YouTube Cookie file readiness
            cookie_path = get_valid_cookie_path()

            # 3. Verify Bot & Assistant MTProto connectivity and PyTgCalls status
            uptime_s = int(time.time() - started_at)
            if uptime_s > 30 and not getattr(app, "is_connected", False):
                logger.warning("⚠️ [Self-Healing] Main Bot client disconnected; attempting reconnect...")
                try:
                    await app.start()
                except Exception as bot_exc:
                    logger.warning(f"⚠️ [Self-Healing] Main Bot reconnect failed: {bot_exc}")

            if uptime_s > 30 and not assistants:
                logger.warning("⚠️ [Self-Healing] No active Assistants; attempting recovery...")
                try:
                    await userbot.start()
                except Exception as ast_exc:
                    logger.warning(f"⚠️ [Self-Healing] Assistant reconnect failed: {ast_exc}")

            online_assistants = [i for i in range(1, 6) if KRUTIK.is_assistant_online(i)]
            if assistants and not online_assistants:
                logger.warning("⚠️ [Self-Healing] Assistant connected but PyTgCalls offline; attempting recovery...")
                try:
                    await KRUTIK.start()
                    online_assistants = [i for i in range(1, 6) if KRUTIK.is_assistant_online(i)]
                except Exception as vc_exc:
                    logger.warning(f"⚠️ [Self-Healing] PyTgCalls recovery failed: {vc_exc}")

            status_payload = {
                "timestamp": int(time.time()),
                "pid": os.getpid(),
                "uptime_seconds": uptime_s,
                "memory_mb": mem_mb,
                "cpu_percent": cpu_pct,
                "bot_connected": bool(getattr(app, "is_connected", False)),
                "bot_username": getattr(app, "username", None),
                "active_assistants": list(assistants),
                "pytgcalls_online_assistants": online_assistants,
                "voice_chat_ready": KRUTIK.is_ready,
                "active_voice_chats_count": len(KRUTIK.active_calls),
                "active_voice_chats": list(KRUTIK.active_calls),
                "mongodb_healthy": mongo_ok,
                "cookies_ready": bool(cookie_path),
            }

            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            tmp_file = CACHE_DIR / "heartbeat.json.tmp"
            tmp_file.write_text(json.dumps(status_payload, indent=2), encoding="utf-8")
            os.replace(str(tmp_file), str(HEARTBEAT_FILE))
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.debug(f"Heartbeat monitor warning: {exc}")

        await asyncio.sleep(30)

