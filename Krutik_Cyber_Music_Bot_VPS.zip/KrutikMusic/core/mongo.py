# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
import asyncio
import json
import os
import certifi
from typing import Any, Dict, List, Optional
from config import MONGO_DB_URI
from ..logging import LOGGER

LOGGER(__name__).info("Initializing Database connection...")

LOCAL_STORE_PATH = os.path.join(os.getcwd(), "local_mongo_store.json")

class AsyncCursor:
    def __init__(self, cursor):
        self._cursor = cursor
        self._iter = iter(cursor)

    def __aiter__(self):
        self._iter = iter(self._cursor)
        return self

    async def __anext__(self):
        if self._iter is None:
            self._iter = iter(self._cursor)
        try:
            return next(self._iter)
        except StopIteration:
            raise StopAsyncIteration

    async def to_list(self, length=None):
        docs = list(self._cursor)
        if length is not None:
            return docs[:length]
        return docs


class LocalAsyncCollection:
    def __init__(self, coll, save_callback):
        self._coll = coll
        self._save = save_callback

    async def find_one(self, *args, **kwargs):
        return self._coll.find_one(*args, **kwargs)

    def find(self, *args, **kwargs):
        return AsyncCursor(self._coll.find(*args, **kwargs))

    def _normalize_update(self, update):
        if isinstance(update, dict) and not any(str(k).startswith("$") for k in update.keys()):
            return {"$set": update}
        return update

    async def update_one(self, filter_doc, update, *args, **kwargs):
        norm_update = self._normalize_update(update)
        res = self._coll.update_one(filter_doc, norm_update, *args, **kwargs)
        self._save()
        return res

    async def update_many(self, filter_doc, update, *args, **kwargs):
        norm_update = self._normalize_update(update)
        res = self._coll.update_many(filter_doc, norm_update, *args, **kwargs)
        self._save()
        return res

    async def insert_one(self, *args, **kwargs):
        res = self._coll.insert_one(*args, **kwargs)
        self._save()
        return res

    async def delete_one(self, *args, **kwargs):
        res = self._coll.delete_one(*args, **kwargs)
        self._save()
        return res

    async def delete_many(self, *args, **kwargs):
        res = self._coll.delete_many(*args, **kwargs)
        self._save()
        return res

    async def count_documents(self, *args, **kwargs):
        return self._coll.count_documents(*args, **kwargs)


BACKUP_DIR = os.path.join(os.getcwd(), "backups")


class LocalAsyncDatabase:
    def __init__(self):
        import mongomock
        self._client = mongomock.MongoClient()
        self._db = self._client.KrutikMusic
        os.makedirs(BACKUP_DIR, exist_ok=True)
        self._load()

    def _load(self):
        loaded = False
        if os.path.exists(LOCAL_STORE_PATH):
            try:
                with open(LOCAL_STORE_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for coll_name, docs in data.items():
                        if docs:
                            self._db[coll_name].insert_many(docs)
                LOGGER("KrutikMusic.core.mongo").info(
                    f"Loaded local persistent database from {LOCAL_STORE_PATH}"
                )
                loaded = True
            except Exception as e:
                LOGGER("KrutikMusic.core.mongo").warning(
                    f"Corrupted local store at {LOCAL_STORE_PATH} ({e}). Attempting backup recovery..."
                )

        if not loaded:
            # Automatic recovery from latest valid backup
            recovered = self._recover_from_latest_backup()
            if not recovered:
                LOGGER("KrutikMusic.core.mongo").info(
                    "Initialized fresh local database instance (no prior backup found)."
                )

    def _recover_from_latest_backup(self) -> bool:
        if not os.path.exists(BACKUP_DIR):
            return False
        try:
            backup_files = sorted(
                [f for f in os.listdir(BACKUP_DIR) if f.startswith("backup_") and f.endswith(".json")],
                reverse=True
            )
            for b_file in backup_files:
                b_path = os.path.join(BACKUP_DIR, b_file)
                try:
                    with open(b_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        for coll_name, docs in data.items():
                            if docs:
                                self._db[coll_name].insert_many(docs)
                    # Restore local store
                    self._save()
                    LOGGER("KrutikMusic.core.mongo").info(
                        f"✅ Successfully recovered database from backup: {b_file}"
                    )
                    return True
                except Exception:
                    continue
        except Exception as exc:
            LOGGER("KrutikMusic.core.mongo").warning(f"Backup recovery scan failed: {exc}")
        return False

    def _save(self):
        try:
            data = {}
            for coll_name in self._db.list_collection_names():
                coll_docs = list(self._db[coll_name].find())
                cleaned = []
                for d in coll_docs:
                    c = dict(d)
                    if "_id" in c:
                        c["_id"] = str(c["_id"])
                    cleaned.append(c)
                data[coll_name] = cleaned

            tmp_path = LOCAL_STORE_PATH + ".tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp_path, LOCAL_STORE_PATH)
        except Exception as e:
            LOGGER("KrutikMusic.core.mongo").error(f"Failed to persist local DB: {e}")

    def create_backup(self, reason: str = "manual") -> Optional[str]:
        """Creates a timestamped snapshot of the local database and rotates old backups."""
        import datetime
        os.makedirs(BACKUP_DIR, exist_ok=True)
        try:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(BACKUP_DIR, f"backup_{ts}.json")
            data = {}
            for coll_name in self._db.list_collection_names():
                coll_docs = list(self._db[coll_name].find())
                cleaned = []
                for d in coll_docs:
                    c = dict(d)
                    if "_id" in c:
                        c["_id"] = str(c["_id"])
                    cleaned.append(c)
                data[coll_name] = cleaned

            with open(backup_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            LOGGER("KrutikMusic.core.mongo").info(
                f"Created database snapshot at {backup_file} (reason: {reason})"
            )

            # Rotate: Keep last 10 backups
            all_backups = sorted(
                [f for f in os.listdir(BACKUP_DIR) if f.startswith("backup_") and f.endswith(".json")]
            )
            while len(all_backups) > 10:
                old = os.path.join(BACKUP_DIR, all_backups.pop(0))
                try:
                    os.remove(old)
                except Exception:
                    pass

            return backup_file
        except Exception as exc:
            LOGGER("KrutikMusic.core.mongo").warning(f"Failed to create database backup: {exc}")
            return None

    def __getattr__(self, name: str):
        return LocalAsyncCollection(self._db[name], self._save)

    def __getitem__(self, name: str):
        return LocalAsyncCollection(self._db[name], self._save)

    async def command(self, cmd: str, *args, **kwargs):
        if cmd == "dbstats":
            collections = self._db.list_collection_names()
            total_objs = sum(self._db[c].count_documents({}) for c in collections)
            sz = os.path.getsize(LOCAL_STORE_PATH) if os.path.exists(LOCAL_STORE_PATH) else 1024
            return {
                "ok": 1,
                "objects": total_objs or 10,
                "collections": len(collections) or 1,
                "dataSize": sz,
                "storageSize": sz,
            }
        if cmd == "ping":
            return {"ok": 1.0}
        return {"ok": 1}


mongodb = None

# We use a wrapper to handle the lazy connection behavior of Motor
class MongoWrapper:
    def __init__(self):
        self._db = None
        self._client = None
        self._init_task = None

    async def _initialize(self):
        global MONGO_DB_URI
        from config import USE_LOCAL_DB
        use_local = USE_LOCAL_DB or os.environ.get("USE_LOCAL_DB", "").lower() in ("1", "true", "yes")

        if not use_local and MONGO_DB_URI and (MONGO_DB_URI.startswith("mongodb://") or MONGO_DB_URI.startswith("mongodb+srv://")):
            from motor.motor_asyncio import AsyncIOMotorClient
            LOGGER("KrutikMusic.core.mongo").info("Connecting to MongoDB Atlas...")
            try:
                client = AsyncIOMotorClient(
                    MONGO_DB_URI,
                    serverSelectionTimeoutMS=2500,
                    tlsCAFile=certifi.where(),
                    connectTimeoutMS=3000,
                    socketTimeoutMS=3000,
                    maxPoolSize=20,
                    retryWrites=True,
                    retryReads=True,
                )
                await client.admin.command("ping")
                self._client = client
                self._db = client.KrutikMusic
                LOGGER("KrutikMusic.core.mongo").info("Connected to MongoDB Atlas successfully.")
                return
            except Exception as e:
                LOGGER("KrutikMusic.core.mongo").warning(
                    f"MongoDB Atlas connection skipped ({type(e).__name__}). Using local persistent database."
                )

        self._db = LocalAsyncDatabase()
        LOGGER("KrutikMusic.core.mongo").info("Local persistent database active (LocalAsyncDatabase).")

    async def ensure_connected(self) -> bool:
        try:
            db = await self._get_db()
            res = await db.command("ping")
            return bool(res and res.get("ok"))
        except Exception:
            self._db = None
            self._init_task = None
            try:
                db = await self._get_db()
                res = await db.command("ping")
                return bool(res and res.get("ok"))
            except Exception:
                return False

    async def _get_db(self):
        if self._db is None:
            if self._init_task is None or self._init_task.done():
                self._init_task = asyncio.create_task(self._initialize())
            await self._init_task
        return self._db

    def __getattr__(self, name):
        # We return a proxy that awaits initialization on first use
        class Proxy:
            def __init__(self, wrapper, attr):
                self._wrapper = wrapper
                self._attr = attr
            
            async def _get_coll(self):
                db = await self._wrapper._get_db()
                return getattr(db, self._attr)

            async def find_one(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.find_one(*args, **kwargs)

            def find(self, *args, **kwargs):
                # For find() which returns a cursor, we need a special proxy
                class CursorProxy:
                    def __init__(self, wrapper, attr, args, kwargs):
                        self._wrapper = wrapper
                        self._attr = attr
                        self._args = args
                        self._kwargs = kwargs
                        self._cursor = None

                    async def _get_cursor(self):
                        if self._cursor is None:
                            coll = await self._wrapper._get_db()
                            self._cursor = getattr(coll, self._attr).find(*self._args, **self._kwargs)
                        return self._cursor

                    def __aiter__(self):
                        return self

                    async def __anext__(self):
                        cursor = await self._get_cursor()
                        return await cursor.__anext__()

                    async def to_list(self, length=None):
                        cursor = await self._get_cursor()
                        return await cursor.to_list(length)

                return CursorProxy(self._wrapper, self._attr, args, kwargs)

            async def update_one(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.update_one(*args, **kwargs)

            async def update_many(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.update_many(*args, **kwargs)

            async def insert_one(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.insert_one(*args, **kwargs)

            async def delete_one(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.delete_one(*args, **kwargs)

            async def delete_many(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.delete_many(*args, **kwargs)

            async def count_documents(self, *args, **kwargs):
                coll = await self._get_coll()
                return await coll.count_documents(*args, **kwargs)
        return Proxy(self, name)

    def __getitem__(self, name):
        return self.__getattr__(name)

    async def command(self, *args, **kwargs):
        db = await self._get_db()
        return await db.command(*args, **kwargs)

    async def create_backup(self, reason: str = "manual"):
        db = await self._get_db()
        if hasattr(db, "create_backup"):
            return db.create_backup(reason=reason)
        return None

mongodb = MongoWrapper()



