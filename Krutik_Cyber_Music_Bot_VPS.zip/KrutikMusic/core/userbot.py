# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

from pyrogram import Client, errors
import asyncio
import time

import config

from ..logging import LOGGER

assistants = []
assistantids = []

GROUPS_TO_JOIN = []


# Initialize userbots
class Userbot:
    def __init__(self):
        self.one = None
        self.two = None
        self.three = None
        self.four = None
        self.five = None
        self.logger_accessible = False

        seen_strings = set()

        def _unique_session(s: str) -> str:
            val = (s or "").strip()
            if not val or val in seen_strings:
                return ""
            seen_strings.add(val)
            return val

        s1 = _unique_session(config.STRING1)
        s2 = _unique_session(config.STRING2)
        s3 = _unique_session(config.STRING3)
        s4 = _unique_session(config.STRING4)
        s5 = _unique_session(config.STRING5)

        # Prefer persistent krutik_assistant.session on disk when available so we reuse the
        # existing MTProto session without re-importing or duplicating connections.
        # IMPORTANT: no_updates=False is required by PyTgCalls so @client.on_raw_update(group=-9999)
        # receives UpdateGroupCall, UpdateGroupCallParticipants, and UpdateGroupCallConnection events.
        if config.HAS_ASSISTANT_FILE:
            self.one = Client(
                "krutik_assistant",
                config.API_ID,
                config.API_HASH,
                no_updates=False,
                in_memory=False,
                workers=2,
                sleep_threshold=60,
            )
        elif s1:
            self.one = Client(
                "KrutikAssis1",
                config.API_ID,
                config.API_HASH,
                session_string=str(s1),
                no_updates=False,
                in_memory=True,
                workers=2,
                sleep_threshold=60,
            )
        if s2:
            self.two = Client(
                "KrutikAssis2",
                config.API_ID,
                config.API_HASH,
                session_string=str(s2),
                no_updates=False,
                in_memory=True,
                workers=2,
                sleep_threshold=60,
            )
        if s3:
            self.three = Client(
                "KrutikAssis3",
                config.API_ID,
                config.API_HASH,
                session_string=str(s3),
                no_updates=False,
                in_memory=True,
                workers=2,
                sleep_threshold=60,
            )
        if s4:
            self.four = Client(
                "KrutikAssis4",
                config.API_ID,
                config.API_HASH,
                session_string=str(s4),
                no_updates=False,
                in_memory=True,
                workers=2,
                sleep_threshold=60,
            )
        if s5:
            self.five = Client(
                "KrutikAssis5",
                config.API_ID,
                config.API_HASH,
                session_string=str(s5),
                no_updates=False,
                in_memory=True,
                workers=2,
                sleep_threshold=60,
            )

    def get_client(self, index: int):
        return {
            1: self.one,
            2: self.two,
            3: self.three,
            4: self.four,
            5: self.five,
        }.get(int(index))

    def is_client_connected(self, index: int) -> bool:
        client = self.get_client(index)
        return bool(
            client is not None
            and int(index) in assistants
            and getattr(client, "is_connected", False)
            and getattr(client, "id", None)
        )

    async def start_assistant(self, client: Client, index: int):
        if client is None:
            return

        running_loop = asyncio.get_running_loop()
        client.loop = running_loop
        if hasattr(client, "dispatcher") and client.dispatcher is not None:
            client.dispatcher.loop = running_loop

        max_retries = 2
        attempt = 0
        while True:
            try:
                await client.start()
                break
            except errors.FloodWait as e:
                wait_s = int(getattr(e, "value", getattr(e, "x", 30)))
                attempt += 1
                retry_at = time.strftime("%H:%M:%S", time.localtime(time.time() + wait_s))
                LOGGER(__name__).warning(
                    f"⚠️ FloodWait triggered by Assistant {index} Login: "
                    f"retry_after={wait_s}s (will retry at {retry_at}, attempt {attempt}/{max_retries})."
                )
                if attempt >= max_retries:
                    LOGGER(__name__).error(
                        f"❌ Skipping Assistant {index} after {max_retries} FloodWait retries."
                    )
                    return
                await asyncio.sleep(wait_s + 1)
            except Exception as e:
                LOGGER(__name__).error(f"❌ Failed to start Assistant {index}: {e}")
                return

        if not getattr(client, "is_connected", False):
            LOGGER(__name__).error(f"❌ Assistant {index} start() returned but client.is_connected is False.")
            return

        # Validate authenticated session identity
        me = client.me or await client.get_me()
        if not me or not getattr(me, "id", None):
            LOGGER(__name__).error(f"❌ Assistant {index} failed session validation (self.me is None).")
            await client.stop()
            return

        if me.id in assistantids:
            LOGGER(__name__).warning(
                f"⚠️ Assistant {index} shares duplicate account ID {me.id}; stopping duplicate client."
            )
            await client.stop()
            return

        client.id = me.id
        client.name = f"{me.first_name or ''} {me.last_name or ''}".strip() or me.first_name or f"Assistant {index}"
        client.username = me.username
        client.mention = me.mention
        client.logger_accessible = False

        for group in GROUPS_TO_JOIN:
            try:
                await client.join_chat(group)
            except errors.FloodWait as e:
                wait_s = int(getattr(e, "value", getattr(e, "x", 30)))
                LOGGER(__name__).warning(
                    f"⚠️ Assistant {index} FloodWait while joining {group}: retry_after={wait_s}s."
                )
                await asyncio.sleep(wait_s + 1)
            except Exception:
                pass

        # Mark assistant active only after connection and identity validation succeed
        assistants.append(index)
        assistantids.append(me.id)

        LOGGER(__name__).info(
            f"Assistant Connected: {client.name} (@{client.username}) [ID: {client.id}]"
        )
        LOGGER(__name__).info(f"Assistant {index} Started as {client.name} (@{client.username})")

        if config.LOGGER_ID:
            try:
                await client.send_message(
                    config.LOGGER_ID, f"Krutik's Assistant {index} Started"
                )
                self.logger_accessible = True
                client.logger_accessible = True
                LOGGER(__name__).info(
                    f"✅ Assistant {index} verified access to LOGGER_ID ({config.LOGGER_ID})."
                )
                # If the main bot could not access LOGGER_ID because it wasn't added/promoted yet,
                # try adding or promoting the bot via the assistant, or route LOGGER_ID via Assistant.
                try:
                    from KrutikMusic import app
                    from pyrogram.types import ChatPrivileges

                    if not getattr(app, "logger_accessible", False) and getattr(app, "username", None):
                        promoted_or_added = False
                        try:
                            await client.add_chat_members(config.LOGGER_ID, app.username)
                            promoted_or_added = True
                        except Exception:
                            pass
                        if not promoted_or_added:
                            try:
                                await client.promote_chat_member(
                                    config.LOGGER_ID,
                                    app.username,
                                    privileges=ChatPrivileges(
                                        can_manage_chat=True,
                                        can_post_messages=True,
                                        can_edit_messages=True,
                                        can_delete_messages=True,
                                        can_invite_users=True,
                                        can_manage_video_chats=True,
                                    ),
                                )
                                promoted_or_added = True
                            except Exception:
                                pass
                        if promoted_or_added:
                            try:
                                await app.send_message(
                                    config.LOGGER_ID,
                                    (
                                        f"<u><b>» {app.mention} ʙᴏᴛ sᴛᴀʀᴛᴇᴅ :</b></u>\n\n"
                                        f"ɪᴅ : <code>{app.id}</code>\n"
                                        f"ɴᴀᴍᴇ : {app.name}\n"
                                        f"ᴜsᴇʀɴᴀᴍᴇ : @{app.username}"
                                    ),
                                )
                                app.logger_accessible = True
                                LOGGER(__name__).info(
                                    f"✅ Added @{app.username} to LOGGER_ID ({config.LOGGER_ID}) via Assistant {index}."
                                )
                            except Exception:
                                pass

                        if not getattr(app, "logger_accessible", False):
                            app.logger_via_assistant = True
                            await client.send_message(
                                config.LOGGER_ID,
                                (
                                    f"<u><b>» {app.mention} ʙᴏᴛ sᴛᴀʀᴛᴇᴅ (via Assistant {index}) :</b></u>\n\n"
                                    f"ɪᴅ : <code>{app.id}</code>\n"
                                    f"ɴᴀᴍᴇ : {app.name}\n"
                                    f"ᴜsᴇʀɴᴀᴍᴇ : @{app.username}"
                                ),
                            )
                            LOGGER(__name__).info(
                                f"✅ LOGGER_ID ({config.LOGGER_ID}) active via Assistant {index} relay."
                            )
                except Exception:
                    pass
            except errors.FloodWait as e:
                wait_s = int(getattr(e, "value", getattr(e, "x", 30)))
                LOGGER(__name__).warning(
                    f"⚠️ Assistant {index} FloodWait sending to LOGGER_ID: retry_after={wait_s}s (skipping)."
                )
            except Exception as exc:
                LOGGER(__name__).warning(
                    f"⚠️ Assistant {index} cannot access LOGGER_ID ({config.LOGGER_ID}): {exc} – continuing."
                )

    async def start(self):
        LOGGER(__name__).info("Starting Krutik's Assistants...")
        assistants.clear()
        assistantids.clear()
        for idx, client in enumerate([self.one, self.two, self.three, self.four, self.five], start=1):
            if client:
                await self.start_assistant(client, idx)
        LOGGER(__name__).info(
            f"All Assistants startup process finished ({len(assistants)} active: {assistants})."
        )

    async def stop(self):
        LOGGER(__name__).info("Stopping Assistants...")
        try:
            if self.one:
                await self.one.stop()
            if self.two:
                await self.two.stop()
            if self.three:
                await self.three.stop()
            if self.four:
                await self.four.stop()
            if self.five:
                await self.five.stop()
        except Exception as e:
            LOGGER(__name__).error(f"Error while stopping assistants: {e}")

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
