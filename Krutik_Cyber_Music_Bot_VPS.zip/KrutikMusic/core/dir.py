# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import os
from ..logging import LOGGER

BASE_DIR = os.getcwd()
DOWNLOAD_DIR = os.path.join(BASE_DIR, "downloads")
COUPLE_DIR = os.path.join(BASE_DIR, "couples")
CACHE_DIR = os.path.join(BASE_DIR, "cache")

def dirr():
    for file in os.listdir():
        if file.lower().endswith((".jpg", ".jpeg", ".png")):
            os.remove(file)

    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)
    os.makedirs(COUPLE_DIR, exist_ok=True)

    LOGGER(__name__).info("Directories Updated.")


def purge_temporary_media(max_age_seconds: int = 300) -> int:
    """Purge temporary downloaded audio/video chunks and thumbnails older than max_age_seconds."""
    import time
    now = time.time()
    purged = 0
    for folder in (DOWNLOAD_DIR, CACHE_DIR):
        if not os.path.exists(folder):
            continue
        for root, _, files in os.walk(folder):
            for fname in files:
                fpath = os.path.join(root, fname)
                # Keep persistent locks, states, sessions, cookies, and db files
                if fname.endswith((".json", ".pid", ".session", ".session-journal", ".txt", ".db")):
                    continue
                try:
                    mtime = os.path.getmtime(fpath)
                    if now - mtime > max_age_seconds:
                        os.remove(fpath)
                        purged += 1
                except Exception:
                    pass
    return purged

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
