# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import hashlib
import json
import os
import sqlite3
import sys
import time
from pyrogram import Client, errors
from pyrogram.enums import ChatMemberStatus
from pyrogram.types import BotCommand

import config
from ..logging import LOGGER

BOT_SESSION_NAME = "krutik_music_bot"
BOT_SESSION_FILE = f"{BOT_SESSION_NAME}.session"
COMMANDS_CACHE_FILE = os.path.join("cache", "bot_commands_state.json")


def _resolve_bot_session_name(bot_token: str) -> str:
    """Return the persistent Pyrogram session name matching the configured BOT_TOKEN.

    Reusing the existing authorized SQLite session file avoids calling
    auth.ImportBotAuthorization on every restart, which is the primary cause
    of Telegram FloodWait during bot startup. Never deletes existing sessions.
    """
    if not bot_token or ":" not in bot_token:
        return BOT_SESSION_NAME
    try:
        expected_bot_id = int(bot_token.split(":", 1)[0])
    except ValueError:
        return BOT_SESSION_NAME

    if os.path.exists(BOT_SESSION_FILE):
        try:
            conn = sqlite3.connect(BOT_SESSION_FILE)
            cur = conn.cursor()
            cur.execute("SELECT user_id, length(auth_key) FROM sessions LIMIT 1")
            row = cur.fetchone()
            conn.close()
            if row:
                stored_user_id, auth_key_len = row
                if auth_key_len and (not stored_user_id or int(stored_user_id) == expected_bot_id):
                    return BOT_SESSION_NAME
                return f"{BOT_SESSION_NAME}_{expected_bot_id}"
        except Exception as exc:
            LOGGER(__name__).warning(f"Could not inspect {BOT_SESSION_FILE} ({exc}); reusing default session.")
            return BOT_SESSION_NAME

    return BOT_SESSION_NAME


class KRUTIK(Client):
    def __init__(self):
        # Safe defaults before start() completes so plugins importing app attributes never fail
        self.id = int(config.BOT_TOKEN.split(":", 1)[0]) if config.BOT_TOKEN and ":" in config.BOT_TOKEN else 0
        self.username = config.BOT_USERNAME or "KRUTIK_YT_MUSIC_PLAYER_bot"
        self.name = config.BOT_NAME or "KRUTIK CYBER MUSIC"
        self.mention = f"[{self.name}](tg://user?id={self.id})" if self.id else self.name
        self.logger_accessible = False
        self.logger_via_assistant = False

        session_name = _resolve_bot_session_name(config.BOT_TOKEN)

        # Optimized workers & concurrency for 10–12+ simultaneous group voice chats
        cpu_n = os.cpu_count() or 2
        opt_workers = min(24, max(16, cpu_n * 4))
        super().__init__(
            name=session_name,
            api_id=config.API_ID,
            api_hash=config.API_HASH,
            bot_token=config.BOT_TOKEN,
            in_memory=False,
            workers=opt_workers,
            max_concurrent_transmissions=10,
            sleep_threshold=60,
        )
        LOGGER(__name__).info(
            f"Bot client initialized (session={session_name}.session, workers={opt_workers})."
        )

    async def start(self):
        LOGGER(__name__).info("Starting Bot client...")
        running_loop = asyncio.get_running_loop()
        self.loop = running_loop
        if hasattr(self, "dispatcher") and self.dispatcher is not None:
            self.dispatcher.loop = running_loop
        max_retries = 3
        attempt = 0
        while True:
            try:
                await super().start()
                break
            except errors.FloodWait as e:
                wait_s = int(getattr(e, "value", getattr(e, "x", 30)))
                attempt += 1
                retry_at = time.strftime("%H:%M:%S", time.localtime(time.time() + wait_s))
                LOGGER(__name__).warning(
                    f"⚠️ Telegram FloodWait triggered by Bot Client Login (auth.ImportBotAuthorization): "
                    f"retry_after={wait_s}s (will retry at {retry_at}, attempt {attempt}/{max_retries})."
                )
                if attempt >= max_retries:
                    raise RuntimeError(
                        f"Bot login aborted after {max_retries} FloodWait retries (last retry_after={wait_s}s)."
                    ) from e
                await asyncio.sleep(wait_s + 1)
            except Exception as e:
                LOGGER(__name__).error(f"❌ Failed to start Bot client: {e}")
                raise e

        # super().start() populates self.me in Pyrogram without an extra get_me() RPC call
        me = self.me or await self.get_me()
        self.username, self.id = me.username, me.id
        self.name = f"{me.first_name} {me.last_name or ''}".strip()
        self.mention = me.mention

        LOGGER(__name__).info(f"Bot Connected: {self.name} (@{self.username}) [ID: {self.id}]")

        # Run command menu sync and log group notification asynchronously so they never block
        # startup or incoming message handlers if a rate limit occurs.
        asyncio.create_task(self._post_start_tasks())
        LOGGER(__name__).info("✅ Music Bot client is online and ready to process updates.")

    async def _post_start_tasks(self):
        commands = [
            BotCommand("start", "⚡ ꜱᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ"),
            BotCommand("help", "📖 ɢᴇᴛ ʜᴇʟᴘ ᴍᴇɴᴜ"),
            BotCommand("play", "🎵 ᴘʟᴀʏ ᴀ sᴏɴɢ ɪɴ ᴠᴄ"),
            BotCommand("vplay", "🎬 ᴘʟᴀʏ ᴠɪᴅᴇᴏ ɪɴ ᴠᴄ"),
            BotCommand("stop", "⏹ sᴛᴏᴘ sᴛʀᴇᴀᴍɪɴɢ"),
            BotCommand("pause", "⏸ ᴘᴀᴜsᴇ ᴛʜᴇ sᴛʀᴇᴀᴍ"),
            BotCommand("resume", "▶ ʀᴇsᴜᴍᴇ ᴛʜᴇ sᴛʀᴇᴀᴍ"),
            BotCommand("skip", "⏭ sᴋɪᴘ ᴛᴏ ɴᴇxᴛ sᴏɴɢ"),
            BotCommand("queue", "📜 sʜᴏᴡ ǫᴜᴇᴜᴇ ʟɪsᴛ"),
            BotCommand("loop", "🔄 ʟᴏᴏᴘ ᴄᴜʀʀᴇɴᴛ sᴏɴɢ"),
            BotCommand("shuffle", "🔀 sʜᴜғғʟᴇ ᴛʜᴇ ǫᴜᴇᴜᴇ"),
            BotCommand("seek", "⏩ sᴇᴇᴋ ɪɴ ᴄᴜʀʀᴇɴᴛ sᴏɴɢ"),
            BotCommand("speed", "🎚 ᴄʜᴀɴɢᴇ ᴘʟᴀʏʙᴀᴄᴋ sᴘᴇᴇᴅ"),
            BotCommand("song", "📥 ᴅᴏᴡɴʟᴏᴀᴅ sᴏɴɢ"),
            BotCommand("lock", "🔒 ʟᴏᴄᴋ ᴀ ᴄᴏɴᴛᴇɴᴛ ᴛʏᴘᴇ"),
            BotCommand("unlock", "🔓 ᴜɴʟᴏᴄᴋ ᴀ ᴄᴏɴᴛᴇɴᴛ ᴛʏᴘᴇ"),
            BotCommand("vclogger", "📢 ᴠᴄ ʟᴏɢɢᴇʀ ᴏɴ/ᴏғғ"),
        ]

        # Compute deterministic hash so we don't call bots.SetBotCommands on every restart
        cmd_payload = json.dumps(
            [{"c": c.command, "d": c.description} for c in commands],
            ensure_ascii=False,
            sort_keys=True,
        )
        cmd_hash = hashlib.sha256(f"{self.id}:{cmd_payload}".encode("utf-8")).hexdigest()

        already_registered = False
        try:
            if os.path.exists(COMMANDS_CACHE_FILE):
                with open(COMMANDS_CACHE_FILE, "r", encoding="utf-8") as f:
                    cached = json.load(f)
                if cached.get("bot_id") == self.id and cached.get("hash") == cmd_hash:
                    already_registered = True
        except Exception:
            pass

        if already_registered:
            LOGGER(__name__).info("Bot commands menu already up-to-date (skipping duplicate set_bot_commands API call).")
        else:
            try:
                await self.set_bot_commands(commands)
                os.makedirs(os.path.dirname(COMMANDS_CACHE_FILE), exist_ok=True)
                with open(COMMANDS_CACHE_FILE, "w", encoding="utf-8") as f:
                    json.dump({"bot_id": self.id, "hash": cmd_hash, "updated_at": int(time.time())}, f)
                LOGGER(__name__).info("Bot commands menu registered successfully.")
            except errors.FloodWait as e:
                wait_s = int(getattr(e, "value", getattr(e, "x", 30)))
                retry_at = time.strftime("%H:%M:%S", time.localtime(time.time() + wait_s))
                LOGGER(__name__).warning(
                    f"⚠️ FloodWait triggered by set_bot_commands (bots.SetBotCommands): "
                    f"retry_after={wait_s}s (will retry in background at {retry_at})."
                )
                await asyncio.sleep(wait_s + 1)
                try:
                    await self.set_bot_commands(commands)
                    os.makedirs(os.path.dirname(COMMANDS_CACHE_FILE), exist_ok=True)
                    with open(COMMANDS_CACHE_FILE, "w", encoding="utf-8") as f:
                        json.dump({"bot_id": self.id, "hash": cmd_hash, "updated_at": int(time.time())}, f)
                    LOGGER(__name__).info("Bot commands menu registered after FloodWait retry.")
                except Exception as retry_exc:
                    LOGGER(__name__).warning(f"Could not set bot commands after retry: {retry_exc}")
            except Exception as e:
                LOGGER(__name__).warning(f"Could not set bot commands: {e}")

        if config.LOGGER_ID:
            startup_text = (
                f"<u><b>» {self.mention} ʙᴏᴛ sᴛᴀʀᴛᴇᴅ :</b></u>\n\n"
                f"ɪᴅ : <code>{self.id}</code>\n"
                f"ɴᴀᴍᴇ : {self.name}\n"
                f"ᴜsᴇʀɴᴀᴍᴇ : @{self.username}"
            )
            try:
                await self.send_message(config.LOGGER_ID, startup_text)
                self.logger_accessible = True
                LOGGER(__name__).info(f"✅ Main Bot verified direct access to LOGGER_ID ({config.LOGGER_ID}).")
            except errors.FloodWait as e:
                wait_s = int(getattr(e, "value", getattr(e, "x", 30)))
                retry_at = time.strftime("%H:%M:%S", time.localtime(time.time() + wait_s))
                LOGGER(__name__).warning(
                    f"⚠️ FloodWait triggered by send_message(LOGGER_ID): "
                    f"retry_after={wait_s}s (skipping retry until {retry_at})."
                )
            except (errors.ChannelInvalid, errors.PeerIdInvalid, errors.ChannelPrivate) as exc:
                LOGGER(__name__).info(
                    f"ℹ️ Main Bot is not yet a direct admin in LOGGER_ID ({config.LOGGER_ID}) [{type(exc).__name__}]; "
                    f"Assistant 1 will verify LOGGER_ID and route logs automatically."
                )
            except Exception as exc:
                LOGGER(__name__).warning(f"⚠️ Bot could not send startup message to LOGGER_ID ({config.LOGGER_ID}): {exc}")

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
