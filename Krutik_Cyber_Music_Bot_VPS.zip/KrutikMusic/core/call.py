# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import logging
import os
import re
import sys
import time
import traceback
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set, Tuple, Union

from ntgcalls import TelegramServerError
from pyrogram import Client
import pyrogram.errors

if not hasattr(pyrogram.errors, "GroupcallForbidden"):
    _found = False
    for _sub in ("bad_request_400", "forbidden_403"):
        try:
            import importlib
            _mod = importlib.import_module(f"pyrogram.errors.exceptions.{_sub}")
            if hasattr(_mod, "GroupcallForbidden"):
                setattr(pyrogram.errors, "GroupcallForbidden", getattr(_mod, "GroupcallForbidden"))
                _found = True
                break
        except Exception:
            pass
    if not _found:
        class GroupcallForbidden(pyrogram.errors.RPCError):
            """The group call is forbidden."""
            ID = "GROUPCALL_FORBIDDEN"
        setattr(pyrogram.errors, "GroupcallForbidden", GroupcallForbidden)

if not hasattr(pyrogram.errors, "GroupcallInvalid"):
    _found = False
    # Check for GroupCallInvalid (case mismatch common in some Pyrogram versions)
    if hasattr(pyrogram.errors, "GroupCallInvalid"):
        setattr(pyrogram.errors, "GroupcallInvalid", getattr(pyrogram.errors, "GroupCallInvalid"))
        _found = True
    else:
        for _sub in ("bad_request_400", "forbidden_403"):
            try:
                import importlib
                _mod = importlib.import_module(f"pyrogram.errors.exceptions.{_sub}")
                if hasattr(_mod, "GroupcallInvalid"):
                    setattr(pyrogram.errors, "GroupcallInvalid", getattr(_mod, "GroupcallInvalid"))
                    _found = True
                    break
                elif hasattr(_mod, "GroupCallInvalid"):
                    setattr(pyrogram.errors, "GroupcallInvalid", getattr(_mod, "GroupcallInvalid"))
                    _found = True
                    break
            except Exception:
                pass
    if not _found:
        class GroupcallInvalid(pyrogram.errors.RPCError):
            """The group call is invalid."""
            ID = "GROUPCALL_INVALID"
        setattr(pyrogram.errors, "GroupcallInvalid", GroupcallInvalid)

# Patching raw functions and types for PyTgCalls compatibility with Kurigram/Pyrogram
import inspect
import pyrogram.raw.functions.phone as phone
import pyrogram.raw.types as types

def _patch_module(module, names):
    for old in names:
        if not hasattr(module, old):
            class Dummy:
                def __init__(self, *args, **kwargs):
                    for k, v in kwargs.items():
                        setattr(self, k, v)
                @staticmethod
                def read(b, *args):
                    return Dummy()
                def write(self, *args):
                    return b""
            Dummy.__name__ = old
            setattr(module, old, Dummy)

_patch_module(phone, [
    "CreateConferenceCall", 
    "InviteConferenceCallParticipant", 
    "SendConferenceCallBroadcast", 
    "GetGroupCallChainBlocks"
])
_patch_module(types, [
    "MessageActionConferenceCall", 
    "PhoneCallDiscardReasonMigrateConferenceCall", 
    "InputGroupCallInviteMessage",
    "InputGroupCallSlug",
    "UpdateGroupCallChainBlocks"
])

# Ensure phone.JoinGroupCall accepts extra conference-call kwargs (block, public_key) passed by PyTgCalls
if hasattr(phone, "JoinGroupCall"):
    _orig_jgc_init = phone.JoinGroupCall.__init__
    _jgc_params = set(inspect.signature(_orig_jgc_init).parameters.keys()) - {"self"}
    if "block" not in _jgc_params:
        def _compat_jgc_init(self, *args, **kwargs):
            filtered_kwargs = {k: v for k, v in kwargs.items() if k in _jgc_params}
            return _orig_jgc_init(self, *args, **filtered_kwargs)
        phone.JoinGroupCall.__init__ = _compat_jgc_init

from pyrogram.errors import FloodWait, ChatAdminRequired
from pytgcalls import PyTgCalls
from pytgcalls.exceptions import NoActiveGroupCall
from pytgcalls.types import AudioQuality, ChatUpdate, MediaStream, StreamEnded, Update, VideoQuality

import config
from strings import get_string
from KrutikMusic import LOGGER, YouTube, app
from KrutikMusic.misc import db
from KrutikMusic.utils.stream.autoplay import is_autoplay_on
from KrutikMusic.utils.database import (
    add_active_chat,
    add_active_video_chat,
    get_lang,
    get_loop,
    group_assistant,
    is_autoend,
    music_on,
    remove_active_chat,
    remove_active_video_chat,
    set_loop,
)
from KrutikMusic.utils.exceptions import AssistantErr
from KrutikMusic.utils.formatters import check_duration, seconds_to_min, speed_converter
from KrutikMusic.utils.inline.play import colored_stream_markup, colored_stream_markup_timer
from KrutikMusic.utils.colored_buttons import buttons_to_inline_markup, smart_send_photo
from KrutikMusic.utils.stream.autoclear import auto_clean

logger = logging.getLogger(__name__)
from KrutikMusic.utils.thumbnails import get_thumb, get_thumb_url
from KrutikMusic.utils.errors import capture_internal_err, send_large_error
from KrutikMusic.utils.pastebin import KRUTIKBIN
from KrutikMusic.platforms.Youtube import STREAM_HEADERS, mask_stream_url

autoend = {}
counter = {}


def is_stream_url_expired(url: str) -> bool:
    """Check if a signed googlevideo / manifest stream URL has expired or is nearing expiry."""
    if not url or not isinstance(url, str) or not url.startswith("http"):
        return False
    match = re.search(r"expire[=/](\d+)", url)
    if match:
        try:
            expire_ts = int(match.group(1))
            return time.time() >= (expire_ts - 60)
        except Exception:
            pass
    return False


def dynamic_media_stream(
    path: str,
    video: bool = False,
    ffmpeg_params: str = None,
    headers: dict = None,
) -> MediaStream:
    is_video = bool(video)
    if headers is None and isinstance(path, str) and path.startswith("http"):
        headers = STREAM_HEADERS
    return MediaStream(
        audio_path=path,
        media_path=path,
        audio_parameters=AudioQuality.STUDIO,
        video_parameters=VideoQuality.HD_720p if is_video else VideoQuality.SD_360p,
        audio_flags=MediaStream.Flags.REQUIRED,
        video_flags=(MediaStream.Flags.REQUIRED if is_video else MediaStream.Flags.IGNORE),
        ffmpeg_parameters=ffmpeg_params,
        headers=headers,
    )

async def _colored_send_photo(original_chat_id, photo, caption, buttons, db_ref, chat_id, markup_type):
    """Send photo with colored buttons via smart wrapper (auto fallback)."""
    run = await smart_send_photo(
        chat_id=original_chat_id,
        photo=photo,
        caption=caption,
        reply_markup=buttons,
    )
    playlist = db.get(chat_id)
    if playlist and len(playlist) > 0:
        playlist[0]["mystic"] = run
        playlist[0]["markup"] = markup_type
        playlist[0]["base_caption"] = caption
    return run


async def _clear_(chat_id: int) -> None:
    popped = db.pop(chat_id, None)
    if popped:
        await auto_clean(popped)
    db[chat_id] = []
    await remove_active_video_chat(chat_id)
    await remove_active_chat(chat_id)
    await set_loop(chat_id, 0)

class Call:
    def __init__(self):
        from KrutikMusic import userbot
        self.one = PyTgCalls(userbot.one) if userbot.one else None
        self.two = PyTgCalls(userbot.two) if userbot.two else None
        self.three = PyTgCalls(userbot.three) if userbot.three else None
        self.four = PyTgCalls(userbot.four) if userbot.four else None
        self.five = PyTgCalls(userbot.five) if userbot.five else None

        self.active_calls: set[int] = set()
        self._online_assistants: set[int] = set()
        self._chat_locks: dict[int, asyncio.Lock] = {}

    def get_chat_lock(self, chat_id: int) -> asyncio.Lock:
        cid = int(chat_id)
        lock = self._chat_locks.get(cid)
        if lock is None:
            lock = asyncio.Lock()
            self._chat_locks[cid] = lock
        return lock

    def get_call_client(self, index: int):
        return {
            1: self.one,
            2: self.two,
            3: self.three,
            4: self.four,
            5: self.five,
        }.get(int(index))

    def is_assistant_online(self, index: int) -> bool:
        """Return True only when Assistant `index` is authenticated, connected to Telegram, and PyTgCalls is running."""
        from KrutikMusic.core.userbot import assistants
        idx = int(index)
        if idx not in assistants or idx not in self._online_assistants:
            return False
        client = self.get_call_client(idx)
        if client is None:
            return False
        # py-tgcalls 2.2.x stores running state in `_is_running` (not `is_running`)
        pytg_running = bool(
            getattr(client, "_is_running", False)
            or getattr(client, "is_running", False)
        )
        if not pytg_running:
            return False
        mtproto = getattr(client, "mtproto_client", None) or getattr(client, "_mtproto", None)
        if mtproto is None or not bool(getattr(mtproto, "is_connected", False)):
            return False
        return True

    @property
    def is_ready(self) -> bool:
        """Returns True if at least one assistant client is genuinely connected to Telegram and running PyTgCalls."""
        return any(self.is_assistant_online(i) for i in range(1, 6))

    async def stop(self) -> None:
        """Gracefully leave active calls and reset PyTgCalls online state."""
        for chat_id in list(self.active_calls):
            for idx in range(1, 6):
                client = self.get_call_client(idx)
                if client and getattr(client, "_is_running", False):
                    try:
                        await client.leave_call(chat_id)
                    except Exception:
                        pass
        self.active_calls.clear()
        self._online_assistants.clear()


    @capture_internal_err
    async def pause_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.pause(chat_id)

    @capture_internal_err
    async def resume_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.resume(chat_id)

    @capture_internal_err
    async def mute_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.mute(chat_id)

    @capture_internal_err
    async def unmute_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.unmute(chat_id)

    @capture_internal_err
    async def stop_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await _clear_(chat_id)
        if chat_id not in self.active_calls:
            return
        try:
            await assistant.leave_call(chat_id)
            LOGGER(__name__).info(f"⏹ Left voice chat in {chat_id} (stop_stream).")
        except Exception as e:
            LOGGER(__name__).debug(f"leave_call during stop_stream in {chat_id}: {e}")
        finally:
            self.active_calls.discard(chat_id)


    @capture_internal_err
    async def force_stop_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        try:
            check = db.get(chat_id)
            if check:
                check.pop(0)
        except (IndexError, KeyError):
            pass
        await remove_active_video_chat(chat_id)
        await remove_active_chat(chat_id)
        await _clear_(chat_id)
        if chat_id not in self.active_calls:
            return
        try:
            await assistant.leave_call(chat_id)
            LOGGER(__name__).info(f"⏹ Left voice chat in {chat_id} (force_stop_stream).")
        except Exception as e:
            LOGGER(__name__).debug(f"leave_call during force_stop_stream in {chat_id}: {e}")
        finally:
            self.active_calls.discard(chat_id)


    @capture_internal_err
    async def skip_stream(
        self,
        chat_id: int,
        link: str,
        video: Union[bool, str] = None,
        image: Union[bool, str] = None,
        videoid: Optional[str] = None,
    ) -> None:
        assistant = await group_assistant(self, chat_id)
        is_video = bool(video)
        if is_stream_url_expired(link) and videoid:
            LOGGER("KrutikMusic").info(f"🔄 Stream URL expired during skip for {videoid} — refreshing...")
            fresh_url, _ = await YouTube.download(videoid, mystic=None, video=is_video)
            if fresh_url:
                link = fresh_url
        if not await self.verify_stream(link, video=is_video):
            if videoid and isinstance(link, str) and link.startswith("http"):
                fresh_url, _ = await YouTube.download(videoid, mystic=None, video=is_video)
                if fresh_url and await self.verify_stream(fresh_url, video=is_video):
                    link = fresh_url
        stream = dynamic_media_stream(path=link, video=is_video)
        await assistant.play(chat_id, stream)
        if is_video:
            await add_active_video_chat(chat_id)
        else:
            await remove_active_video_chat(chat_id)
        LOGGER(__name__).info(
            f"⏭ Skipped to new stream in {chat_id} (video={is_video}, source={mask_stream_url(link)})"
        )

    @capture_internal_err
    async def vc_users(self, chat_id: int) -> list:
        assistant = await group_assistant(self, chat_id)
        participants = await assistant.get_participants(chat_id)
        return [
            p.user_id
            for p in (participants or [])
            if not getattr(p, "muted", getattr(p, "is_muted", False))
        ]

    @capture_internal_err
    async def seek_stream(self, chat_id: int, file_path: str, to_seek: str, duration: str, mode: str) -> None:
        assistant = await group_assistant(self, chat_id)
        ffmpeg_params = f"-ss {to_seek} -to {duration}"
        is_video = mode == "video"
        stream = dynamic_media_stream(path=file_path, video=is_video, ffmpeg_params=ffmpeg_params)
        await assistant.play(chat_id, stream)

    @capture_internal_err
    async def speedup_stream(self, chat_id: int, file_path: str, speed: float, playing: list) -> None:
        if not isinstance(playing, list) or not playing or not isinstance(playing[0], dict):
            raise AssistantErr("Invalid stream info for speedup.")

        assistant = await group_assistant(self, chat_id)
        base = os.path.basename(file_path)
        chatdir = os.path.join("playback", str(speed))
        os.makedirs(chatdir, exist_ok=True)
        out = os.path.join(chatdir, base)

        if not os.path.exists(out):
            vs = str(2.0 / float(speed))
            cmd = f'ffmpeg -i "{file_path}" -filter:v setpts={vs}*PTS -filter:a atempo={speed} "{out}"'
            proc = await asyncio.create_subprocess_shell(cmd, stdin=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()

        dur = int(await asyncio.get_event_loop().run_in_executor(None, check_duration, out))
        played, con_seconds = speed_converter(playing[0]["played"], speed)
        duration_min = seconds_to_min(dur)
        is_video = playing[0]["streamtype"] == "video"
        ffmpeg_params = f"-ss {played} -to {duration_min}"
        stream = dynamic_media_stream(path=out, video=is_video, ffmpeg_params=ffmpeg_params)

        if chat_id in db and db[chat_id] and db[chat_id][0].get("file") == file_path:
            await assistant.play(chat_id, stream)
        else:
            raise AssistantErr("Stream mismatch during speedup.")

        db[chat_id][0].update({
            "played": con_seconds,
            "dur": duration_min,
            "seconds": dur,
            "speed_path": out,
            "speed": speed,
            "old_dur": db[chat_id][0].get("dur"),
            "old_second": db[chat_id][0].get("seconds"),
        })


    @capture_internal_err
    async def stream_call(self, link: str) -> None:
        assistant = await group_assistant(self, config.LOGGER_ID)
        try:
            await assistant.play(config.LOGGER_ID, MediaStream(link))
            await asyncio.sleep(8)
        finally:
            try:
                await assistant.leave_call(config.LOGGER_ID)
            except:
                pass

    @capture_internal_err
    async def join_call(
        self,
        chat_id: int,
        original_chat_id: int,
        link: str,
        video: Union[bool, str] = None,
        image: Union[bool, str] = None,
        videoid: Optional[str] = None,
    ) -> None:
        assistant = await group_assistant(self, chat_id)
        lang = await get_lang(chat_id)
        _ = get_string(lang)
        is_video = bool(video)

        # 1. Automatic refresh for expired or near-expiry streaming URLs
        if is_stream_url_expired(link) and videoid:
            LOGGER("KrutikMusic").info(f"🔄 Stream URL expired for {videoid} — refreshing before join (video={is_video})...")
            fresh_url, _ = await YouTube.download(videoid, mystic=None, video=is_video)
            if fresh_url:
                link = fresh_url

        # 2. Strict readability verification with HTTP headers and video-stream check
        if not await self.verify_stream(link, video=is_video):
            # If verification failed, attempt one fresh re-extraction before aborting
            if videoid:
                LOGGER("KrutikMusic").info(
                    f"🔄 Stream verification retry: re-extracting stream for {videoid} (video={is_video})..."
                )
                fresh_url, _ = await YouTube.download(videoid, mystic=None, video=is_video)
                if fresh_url and await self.verify_stream(fresh_url, video=is_video):
                    link = fresh_url

            if not await self.verify_stream(link, video=is_video):
                masked = mask_stream_url(link)
                LOGGER("KrutikMusic").error(
                    f"❌ Stream verification failed in {chat_id} (video={is_video}) for source: {masked}"
                )
                self.active_calls.discard(chat_id)
                await remove_active_chat(chat_id)
                await remove_active_video_chat(chat_id)
                raise AssistantErr("❌ ᴛʜᴇ sᴛʀᴇᴀᴍ ɪs ᴇɪᴛʜᴇʀ ɪɴᴠᴀʟɪᴅ ᴏʀ ᴜɴʀᴇᴀᴅᴀʙʟᴇ.")

        stream = dynamic_media_stream(path=link, video=is_video)

        mtproto = getattr(assistant, "mtproto_client", None)
        ast_label = f"{getattr(mtproto, 'name', 'Assistant')} (@{getattr(mtproto, 'username', None)}) [ID: {getattr(mtproto, 'id', '?')}]"
        LOGGER("KrutikMusic").info(
            f"🔊 Joining voice chat in {chat_id} using {ast_label} (video={is_video}, source={mask_stream_url(link)})..."
        )
        try:
            await assistant.play(chat_id, stream)
            LOGGER("KrutikMusic").info(
                f"▶️ Playback started in {chat_id} via {ast_label} (video={is_video}, source={mask_stream_url(link)})"
            )
        except (NoActiveGroupCall, ChatAdminRequired) as e:
            self.active_calls.discard(chat_id)
            await remove_active_chat(chat_id)
            await remove_active_video_chat(chat_id)
            LOGGER("KrutikMusic").warning(
                f"⚠️ Voice chat not active or admin required in {chat_id} ({type(e).__name__}: {e})"
            )
            raise AssistantErr(_["call_8"])
        except TelegramServerError as e:
            self.active_calls.discard(chat_id)
            await remove_active_chat(chat_id)
            await remove_active_video_chat(chat_id)
            LOGGER("KrutikMusic").error(f"❌ TelegramServerError during join_call in {chat_id}: {e}")
            raise AssistantErr(_["call_10"])
        except Exception as e:
            self.active_calls.discard(chat_id)
            await remove_active_chat(chat_id)
            await remove_active_video_chat(chat_id)
            LOGGER("KrutikMusic").error(
                f"❌ Unable to join group call in {chat_id} via {ast_label}: {type(e).__name__}: {e}\n{traceback.format_exc()}"
            )
            raise AssistantErr(
                f"ᴜɴᴀʙʟᴇ ᴛᴏ ᴊᴏɪɴ ᴛʜᴇ ɢʀᴏᴜᴘ ᴄᴀʟʟ.\nRᴇᴀsᴏɴ: {e}"
            )
        self.active_calls.add(chat_id)
        await add_active_chat(chat_id)
        await music_on(chat_id)
        if is_video:
            await add_active_video_chat(chat_id)
        else:
            await remove_active_video_chat(chat_id)

        if await is_autoend():
            counter[chat_id] = {}
            try:
                participants = await assistant.get_participants(chat_id)
                users = len(participants) if participants else 0
                if users == 1:
                    autoend[chat_id] = datetime.now() + timedelta(minutes=1)
            except Exception as e:
                LOGGER("KrutikMusic").debug(f"Could not fetch participant count for autoend in {chat_id}: {e}")


    @capture_internal_err
    async def play(self, client, chat_id: int) -> None:
        check = db.get(chat_id)
        popped = None
        loop = await get_loop(chat_id)
        try:
            # Check if check exists and has items before accessing
            if not check or not isinstance(check, list):
                return
            if loop == 0:
                if len(check) == 0:
                    return
                popped = check.pop(0)
            else:
                loop = loop - 1
                await set_loop(chat_id, loop)
            await auto_clean(popped)
            if not check or not isinstance(check, list) or len(check) == 0:
                # Store popped data BEFORE _clear_() because _clear_() wipes db[chat_id]
                last_title = popped.get("title", "") if popped else ""
                last_vidid = popped.get("vidid", "") if popped else ""
                last_chat_id = popped.get("chat_id", chat_id) if popped else chat_id
                last_video = (popped.get("streamtype") == "video") if popped else False

            await _clear_(chat_id)

            autoplay_started = False
            queue_remaining = check and isinstance(check, list) and len(check) > 0

            if not queue_remaining:
                if last_title and await is_autoplay_on(chat_id):
                    try:
                        from KrutikMusic.utils.stream.autoplay import auto_play_next
                        from KrutikMusic.utils.database import is_active_chat as _is_chat_active

                        autoplay_started = await auto_play_next(
                            chat_id,
                            last_chat_id,
                            last_title,
                            last_vidid,
                            video=last_video,
                        )

                        if autoplay_started and not await _is_chat_active(chat_id):
                            autoplay_started = False

                    except Exception:
                        autoplay_started = False

                # Queue khaali + autoplay ON nahi → tab hi VC leave
                if not autoplay_started and not await is_autoplay_on(chat_id):
                    if chat_id in self.active_calls:
                        try:
                            await client.leave_call(chat_id)
                            LOGGER(__name__).info(f"⏹ Queue finished in {chat_id}; assistant left voice chat.")
                        except NoActiveGroupCall:
                            pass
                        except Exception:
                            pass
                        finally:
                            self.active_calls.discard(chat_id)
                return
        except:
            try:
                await _clear_(chat_id)
                return await client.leave_call(chat_id)
            except:
                return
        else:
            if not check or not isinstance(check, list) or len(check) == 0:
                return
            queued = check[0].get("file")
            if not queued:
                return
            db[chat_id] = check + (db.get(chat_id) or [])
            language = await get_lang(chat_id)
            _ = get_string(language)
            title = (check[0].get("title", "")).title()
            user = check[0].get("by", "")
            original_chat_id = check[0].get("chat_id", chat_id)
            streamtype = check[0].get("streamtype", "")
            videoid = check[0].get("vidid", "")
            if db.get(chat_id) and len(db[chat_id]) > 0:
                db[chat_id][0]["played"] = 0

            exis = check[0].get("old_dur") if check and len(check) > 0 else None
            if exis and db.get(chat_id) and len(db[chat_id]) > 0:
                db[chat_id][0]["dur"] = exis
                db[chat_id][0]["seconds"] = check[0].get("old_second") if check and len(check) > 0 else 0
                db[chat_id][0]["speed_path"] = None
                db[chat_id][0]["speed"] = 1.0

            video = True if str(streamtype) == "video" else False
            ap_status = await is_autoplay_on(chat_id)
            if video:
                await add_active_video_chat(chat_id)
            else:
                await remove_active_video_chat(chat_id)

            if "live_" in queued:
                n, link = await YouTube.video(videoid, True)
                if n == 0:
                    return await app.send_message(original_chat_id, text=_["call_6"])

                if not await self.verify_stream(link, video=video):
                    return await app.send_message(original_chat_id, text=_["call_6"])

                stream = dynamic_media_stream(path=link, video=video)
                try:
                    await client.play(chat_id, stream)
                    LOGGER("KrutikMusic").info(
                        f"▶️ Live stream started in {chat_id}: {videoid} (video={video}, source={mask_stream_url(link)})"
                    )
                except Exception as e:
                    LOGGER("KrutikMusic").error(f"❌ Playback failed in {chat_id}: {e}")
                    return await app.send_message(original_chat_id, text=_["call_6"])

                img = await get_thumb_url(videoid)
                button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                await _colored_send_photo(original_chat_id, img, _["stream_1"].format(
                        f"https://t.me/{app.username}?start=info_{videoid}",
                        title[:23],
                        check[0]["dur"],
                        user,
                    ), button, None, chat_id, "tg")

            elif "vid_" in queued:
                mystic = await app.send_message(original_chat_id, _["call_7"])
                
                max_retries = 3
                download_success = False
                file_path = None
                direct = False

                for attempt in range(max_retries):
                    try:
                        file_path, direct = await YouTube.download(
                            videoid,
                            mystic,
                            videoid=True,
                            video=video,
                        )
                        if file_path:
                            download_success = True
                            break
                    except:
                        if attempt < max_retries - 1:
                            continue
                        else:
                            return await mystic.edit_text(
                                _["call_6"], disable_web_page_preview=True
                            )

                if not download_success or not file_path:
                    return await mystic.edit_text(
                        _["call_6"], disable_web_page_preview=True
                    )

                if not await self.verify_stream(file_path, video=video):
                    return await app.send_message(original_chat_id, text=_["call_6"])

                stream = dynamic_media_stream(path=file_path, video=video)
                try:
                    await client.play(chat_id, stream)
                    LOGGER("KrutikMusic").info(
                        f"▶️ Queued YouTube playback started in {chat_id}: {videoid} (video={video}, source={mask_stream_url(file_path)})"
                    )
                except Exception as e:
                    LOGGER("KrutikMusic").error(f"❌ Video playback failed in {chat_id}: {e}")
                    return await app.send_message(original_chat_id, text=_["call_6"])

                img = await get_thumb_url(videoid)
                button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                await mystic.delete()
                await _colored_send_photo(original_chat_id, img, _["stream_1"].format(
                        f"https://t.me/{app.username}?start=info_{videoid}",
                        title[:23],
                        check[0]["dur"],
                        user,
                    ), button, None, chat_id, "stream")

            elif "index_" in queued:
                if not await self.verify_stream(videoid, video=video):
                    return await app.send_message(original_chat_id, text=_["call_6"])

                stream = dynamic_media_stream(path=videoid, video=video)
                try:
                    await client.play(chat_id, stream)
                    LOGGER("KrutikMusic").info(f"▶️ Index stream started in {chat_id} (video={video})")
                except Exception as e:
                    LOGGER("KrutikMusic").error(f"❌ Index stream failed in {chat_id}: {e}")
                    return await app.send_message(original_chat_id, text=_["call_6"])

                button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                await _colored_send_photo(original_chat_id, config.STREAM_IMG_URL, _["stream_2"].format(user), button, None, chat_id, "tg")

            else:
                if isinstance(queued, str) and queued.startswith("http") and is_stream_url_expired(queued):
                    if videoid:
                        LOGGER("KrutikMusic").info(f"🔄 Queued stream URL expired for {videoid} — refreshing (video={video})...")
                        refreshed, _ = await YouTube.download(videoid, mystic=None, video=video)
                        if refreshed:
                            queued = refreshed
                            if db.get(chat_id) and len(db[chat_id]) > 0:
                                db[chat_id][0]["file"] = refreshed

                if not await self.verify_stream(queued, video=video):
                    if videoid and isinstance(queued, str) and queued.startswith("http"):
                        LOGGER("KrutikMusic").info(f"🔄 Queued stream verification retry: re-extracting for {videoid} (video={video})...")
                        refreshed, _ = await YouTube.download(videoid, mystic=None, video=video)
                        if refreshed and await self.verify_stream(refreshed, video=video):
                            queued = refreshed
                            if db.get(chat_id) and len(db[chat_id]) > 0:
                                db[chat_id][0]["file"] = refreshed

                if not await self.verify_stream(queued, video=video):
                    return await app.send_message(original_chat_id, text=_["call_6"])

                stream = dynamic_media_stream(path=queued, video=video)
                try:
                    await client.play(chat_id, stream)
                    LOGGER("KrutikMusic").info(
                        f"▶️ Queued track started in {chat_id} (video={video}, source={mask_stream_url(queued)})"
                    )
                except Exception as e:
                    LOGGER("KrutikMusic").error(f"❌ Queued track failed in {chat_id}: {e}")
                    return await app.send_message(original_chat_id, text=_["call_6"])

                if videoid == "telegram":
                    button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                    photo = config.TELEGRAM_AUDIO_URL if str(streamtype) == "audio" else config.TELEGRAM_VIDEO_URL
                    await _colored_send_photo(original_chat_id, photo, _["stream_1"].format(
                            config.SUPPORT_CHAT, title[:23], check[0]["dur"], user,
                        ), button, None, chat_id, "tg")

                elif videoid == "soundcloud":
                    button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                    await _colored_send_photo(original_chat_id, config.SOUNCLOUD_IMG_URL, _["stream_1"].format(
                            config.SUPPORT_CHAT, title[:23], check[0]["dur"], user,
                        ), button, None, chat_id, "tg")

                else:
                    img = await get_thumb_url(videoid)
                    button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                    caption = _["stream_1"].format(
                        f"https://t.me/{app.username}?start=info_{videoid}",
                        title[:23], check[0]["dur"], user,
                    )
                    try:
                        run = await smart_send_photo(
                            chat_id=original_chat_id,
                            photo=img,
                            caption=caption,
                            reply_markup=button,
                        )
                    except FloodWait as e:
                        LOGGER(__name__).warning(f"FloodWait: Sleeping for {e.value}")
                        await asyncio.sleep(e.value)
                        run = await smart_send_photo(
                            chat_id=original_chat_id,
                            photo=img,
                            caption=caption,
                            reply_markup=button,
                        )
                    playlist = db.get(chat_id)
                    if playlist and isinstance(playlist, list) and len(playlist) > 0:
                        playlist[0]["mystic"] = run
                        playlist[0]["markup"] = "stream"
                        playlist[0]["base_caption"] = caption


    async def start(self) -> None:
        from KrutikMusic.core.userbot import assistants
        LOGGER(__name__).info("Starting PyTgCalls Clients...")
        self._online_assistants.clear()
        running_loop = asyncio.get_running_loop()

        for idx in range(1, 6):
            if idx not in assistants:
                continue
            client = self.get_call_client(idx)
            if client is None:
                continue
            # Ensure PyTgCalls dispatches ntgcalls callbacks and _wait_connect futures on the active loop
            client.loop = running_loop
            try:
                if not getattr(client, "_is_running", False):
                    await client.start()
                mtproto = getattr(client, "mtproto_client", None) or getattr(client, "_mtproto", None)
                if mtproto and getattr(mtproto, "is_connected", False) and getattr(client, "_is_running", False):
                    self._online_assistants.add(idx)
                    LOGGER(__name__).info(
                        f"✅ PyTgCalls client {idx} online (assistant_id={getattr(client, '_my_id', getattr(mtproto, 'id', '?'))})."
                    )
                else:
                    LOGGER(__name__).error(
                        f"❌ PyTgCalls client {idx} started but underlying assistant is not connected."
                    )
            except Exception as e:
                LOGGER(__name__).error(
                    f"❌ Failed to start PyTgCalls client {idx}: {type(e).__name__}: {e}\n{traceback.format_exc()}"
                )

        LOGGER(__name__).info(
            f"All PyTgCalls Clients started (online_assistants={sorted(self._online_assistants)}, is_ready={self.is_ready})."
        )

    @capture_internal_err
    async def ping(self) -> str:
        pings = []
        for idx in range(1, 6):
            if self.is_assistant_online(idx):
                client = self.get_call_client(idx)
                if client and getattr(client, "ping", None) is not None:
                    pings.append(client.ping)
        return str(round(sum(pings) / len(pings), 3)) if pings else "0.0"

    @capture_internal_err
    async def decorators(self) -> None:
        active_call_clients = [
            self.get_call_client(idx)
            for idx in range(1, 6)
            if self.get_call_client(idx) is not None
        ]

        CRITICAL = (
            ChatUpdate.Status.KICKED
            | ChatUpdate.Status.LEFT_GROUP
            | ChatUpdate.Status.CLOSED_VOICE_CHAT
            | ChatUpdate.Status.DISCARDED_CALL
            | ChatUpdate.Status.BUSY_CALL
        )

        async def unified_update_handler(client, update: Update) -> None:
            try:
                if isinstance(update, ChatUpdate):
                    status = update.status
                    if (status & ChatUpdate.Status.LEFT_CALL) or (status & CRITICAL):
                        LOGGER(__name__).info(
                            f"📴 Voice chat status update in {update.chat_id}: {status} — stopping stream."
                        )
                        await self.stop_stream(update.chat_id)
                        return

                elif isinstance(update, StreamEnded):
                    LOGGER(__name__).info(
                        f"⏹ StreamEnded in {update.chat_id} (type={getattr(update, 'stream_type', '?')}) — advancing queue."
                    )
                    assistant = await group_assistant(self, update.chat_id)
                    await self.play(assistant, update.chat_id)

            except Exception:
                import sys, traceback
                exc_type, exc_obj, exc_tb = sys.exc_info()
                err_msg = str(exc_obj)[:200]
                full_trace = "".join(traceback.format_exception(exc_type, exc_obj, exc_tb))
                LOGGER(__name__).error(
                    f"🚨 Stream update error in {getattr(update, 'chat_id', '?')}: {exc_type.__name__}: {err_msg}\n{full_trace}"
                )
                if getattr(app, "logger_accessible", False):
                    caption = (
                        f"🚨 <b>Stream Error</b>\n"
                        f"📍 <b>Type:</b> <code>{exc_type.__name__}</code>\n"
                        f"💬 <b>Error:</b> <code>{err_msg}</code>\n"
                        f"📌 <b>Chat:</b> <code>{getattr(update, 'chat_id', '?')}</code>"
                    )
                    try:
                        paste_url = await KRUTIKBIN(full_trace)
                        if paste_url:
                            caption += f"\n🔗 <b>Log:</b> {paste_url}"
                    except Exception:
                        pass
                    try:
                        await app.send_message(config.LOGGER_ID, caption)
                    except Exception:
                        pass

        for assistant in active_call_clients:
            assistant.on_update()(unified_update_handler)


    @capture_internal_err
    async def verify_stream(self, url: str, headers: dict = None, video: bool = False) -> bool:
        """Verify if the stream URL or local file is valid, readable by FFmpeg, and contains required audio/video streams."""
        if not url:
            return False
        is_http = isinstance(url, str) and url.startswith("http")
        if not is_http and not os.path.exists(str(url)):
            return False

        if headers is None and is_http:
            headers = STREAM_HEADERS

        try:
            header_args = []
            if is_http and headers:
                header_str = "".join(f"{k}: {v}\r\n" for k, v in headers.items())
                header_args = ["-headers", header_str]

            cmd = [
                "ffprobe",
                "-v", "error",
                *header_args,
                "-i", str(url),
                "-show_entries", "stream=codec_type,codec_name,width,height",
                "-of", "csv=p=0",
            ]
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=12)
            out_text = stdout.decode(errors="ignore").strip()
            has_audio = "audio" in out_text
            has_video = "video" in out_text
            masked = mask_stream_url(str(url))

            if video:
                if has_video and has_audio:
                    streams_compact = "; ".join(dict.fromkeys(l.strip() for l in out_text.splitlines() if l.strip()))
                    logger.info(
                        f"✅ Video+Audio stream verified (video={video}, has_video={has_video}, has_audio={has_audio}, streams=[{streams_compact}], source={masked})"
                    )
                    return True
                logger.warning(
                    f"⚠️ Video stream verification rejected source (video={video}, has_video={has_video}, has_audio={has_audio}, source={masked})"
                )
                return False

            if has_audio or has_video:
                streams_compact = "; ".join(dict.fromkeys(l.strip() for l in out_text.splitlines() if l.strip()))
                logger.info(
                    f"✅ Audio stream verified (video={video}, has_audio={has_audio}, streams=[{streams_compact}], source={masked})"
                )
                return True

            # Secondary fallback check for audio-only: inspect format duration
            cmd_fb = [
                "ffprobe",
                "-v", "error",
                *header_args,
                "-i", str(url),
                "-show_entries", "format=duration",
                "-of", "csv=p=0",
            ]
            proc_fb = await asyncio.create_subprocess_exec(
                *cmd_fb,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_fb, _ = await asyncio.wait_for(proc_fb.communicate(), timeout=8)
            if stdout_fb.strip():
                logger.info(f"✅ Audio stream verified via format duration (video={video}, source={masked})")
                return True

            err_msg = stderr.decode(errors="ignore") if stderr else "Empty output"
            logger.warning(f"⚠️ Stream verification failed for {masked}: {err_msg[:100]}")
            return False
        except Exception as e:
            logger.warning(f"⚠️ Stream verification error for {mask_stream_url(str(url))}: {e}")
            return False

KRUTIK = Call()

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
