# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import contextlib
import functools
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import aiofiles
import aiohttp
import yt_dlp
from py_yt import VideosSearch
from pyrogram.enums import MessageEntityType
from pyrogram.types import Message

from config import FALLBACK_API_URL, KRUTIK_API_KEY, PRIMARY_API_URL
from KrutikMusic import LOGGER
from KrutikMusic.core.dir import CACHE_DIR
from KrutikMusic.utils.cookie_handler import COOKIE_PATH, get_valid_cookie_path
from KrutikMusic.utils.database import is_on_off
from KrutikMusic.utils.downloader import (
    YouTubeAuthError,
    YouTubeUnavailableError,
    _ytdlp_base_opts,
    download_audio_concurrent,
    file_exists,
    is_youtube_auth_error,
    is_youtube_unavailable_error,
    yt_dlp_download,
)
from KrutikMusic.utils.errors import capture_internal_err
from KrutikMusic.utils.formatters import time_to_seconds
from KrutikMusic.utils.tuning import (
    YOUTUBE_META_MAX,
    YOUTUBE_META_TTL,
    YTDLP_TIMEOUT,
)

_module_logger = LOGGER(__name__)

STREAM_HEADERS: Dict[str, str] = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-us,en;q=0.5",
    "Sec-Fetch-Mode": "navigate",
}


def mask_stream_url(url: str) -> str:
    """Mask sensitive tokens and signatures from signed googlevideo / manifest URLs for logs."""
    if not url or not isinstance(url, str):
        return ""
    if not url.startswith("http"):
        return url
    if "googlevideo.com" in url or "youtube.com" in url:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        host = parsed.netloc or "googlevideo.com"
        if "/api/manifest/hls_playlist/" in parsed.path or "/sig/" in parsed.path:
            return f"{parsed.scheme}://{host}/api/manifest/hls_playlist/[signed-manifest-masked]/index.m3u8"
        base = f"{parsed.scheme}://{host}{parsed.path}"
        return f"{base}?[signed-token-masked]"
    return url[:50] + "..." if len(url) > 50 else url


_cache: Dict[str, Tuple[float, List[Dict]]] = {}
_cache_lock = asyncio.Lock()
_formats_cache: Dict[str, Tuple[float, List[Dict], str]] = {}
_formats_lock = asyncio.Lock()

# ============ API CONFIGURATION ============
PRIMARY_API_LOADED = False
FALLBACK_API_LOADED = False


# ============ DECORATORS ============
def backoff_on_429(max_retries: int = 3, base_delay: float = 2.0):
    """Decorator for exponential backoff on HTTP 429 (Too Many Requests)."""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    err_str = str(e).lower()
                    if "429" in err_str or "too many requests" in err_str:
                        retries += 1
                        if retries >= max_retries:
                            _module_logger.warning(f"❌ Max retries reached for 429 error in {func.__name__}")
                            raise e
                        delay = base_delay * (2 ** (retries - 1))
                        _module_logger.warning(
                            f"⚠️ Rate limited (429). Retrying {func.__name__} in {delay}s... (Attempt {retries}/{max_retries})"
                        )
                        await asyncio.sleep(delay)
                    else:
                        raise e
            return await func(*args, **kwargs)
        return wrapper
    return decorator


# ============ RATE LIMITING (Optimized for 10–12+ Simultaneous Groups) ============
_request_timestamps: List[float] = []
_RATE_LIMIT_WINDOW = 60
_MAX_REQUESTS_PER_WINDOW = 60
_rate_limit_lock = asyncio.Lock()


async def _check_rate_limit_async():
    global _request_timestamps
    async with _rate_limit_lock:
        now = time.time()
        _request_timestamps = [ts for ts in _request_timestamps if now - ts < _RATE_LIMIT_WINDOW]
        if len(_request_timestamps) >= _MAX_REQUESTS_PER_WINDOW:
            sleep_time = max(0.1, min(3.0, _RATE_LIMIT_WINDOW - (now - _request_timestamps[0])))
            await asyncio.sleep(sleep_time)
            _request_timestamps = [ts for ts in _request_timestamps if time.time() - ts < _RATE_LIMIT_WINDOW]
        _request_timestamps.append(time.time())


# ── Persistent HTTP session ───────────────────────────────────────────────────
_yt_session: Optional[aiohttp.ClientSession] = None
_yt_session_lock = asyncio.Lock()


async def _get_yt_session() -> aiohttp.ClientSession:
    global _yt_session
    if _yt_session and not _yt_session.closed:
        return _yt_session
    async with _yt_session_lock:
        if _yt_session and not _yt_session.closed:
            return _yt_session
        connector = aiohttp.TCPConnector(limit=64, ttl_dns_cache=300, enable_cleanup_closed=True)
        timeout = aiohttp.ClientTimeout(total=180, sock_connect=10, sock_read=45)
        _yt_session = aiohttp.ClientSession(connector=connector, timeout=timeout)
        return _yt_session


async def close_yt_session() -> None:
    global _yt_session
    async with _yt_session_lock:
        if _yt_session and not _yt_session.closed:
            await _yt_session.close()
            await asyncio.sleep(0.1)
        _yt_session = None


async def load_apis():
    global PRIMARY_API_LOADED, FALLBACK_API_LOADED
    logger = LOGGER("KrutikMusic.platforms.Youtube.py")

    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3)) as probe_session:
            if PRIMARY_API_URL:
                try:
                    start_t = time.time()
                    async with probe_session.get(f"{PRIMARY_API_URL}/") as response:
                        latency = round((time.time() - start_t) * 1000)
                        if response.status == 200:
                            PRIMARY_API_LOADED = True
                            logger.info(f"✅ PRIMARY API Online [{latency}ms]")
                except Exception:
                    pass

            if FALLBACK_API_URL:
                try:
                    async with probe_session.get(f"{FALLBACK_API_URL}/") as response:
                        if response.status == 200:
                            FALLBACK_API_LOADED = True
                            logger.info("✅ FALLBACK API Online")
                except Exception:
                    pass
    except Exception:
        pass

    return PRIMARY_API_LOADED, FALLBACK_API_LOADED


# Initialize APIs non-blockingly when an event loop is running
try:
    _running_loop = asyncio.get_running_loop()
    _running_loop.create_task(load_apis())
except RuntimeError:
    pass


def _cookiefile_path() -> Optional[str]:
    return get_valid_cookie_path()


def _cookies_args() -> List[str]:
    p = _cookiefile_path()
    if p:
        return ["--cookies", p]
    browser = os.environ.get("BROWSER_COOKIES", "").strip().lower()
    if browser in ["firefox", "chrome", "safari", "opera", "edge", "brave", "vivaldi"]:
        return ["--cookies-from-browser", browser]
    return []


def _ytdlp_common_args() -> List[str]:
    """Unified yt-dlp CLI arguments with validated cookies, Node JS runtime, and EJS solver."""
    return [
        *(_cookies_args()),
        "--js-runtimes",
        "node",
        "--remote-components",
        "ejs:github",
        "--cache-dir",
        str(Path(CACHE_DIR).resolve()),
        "--no-warnings",
        "--geo-bypass",
        "--force-ipv4",
    ]


async def _exec_proc(*args: str) -> Tuple[bytes, bytes]:
    if args and args[0] == "yt-dlp":
        args = (sys.executable, "-m", "yt_dlp", *args[1:])
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        return await asyncio.wait_for(proc.communicate(), timeout=YTDLP_TIMEOUT)
    except asyncio.TimeoutError:
        with contextlib.suppress(Exception):
            proc.kill()
        return b"", b"timeout"


# ============ API 1: PRIMARY KRUTIK API (DIRECT DOWNLOAD) ============
@backoff_on_429()
async def download_song_primary_api(link: str) -> Optional[str]:
    if not PRIMARY_API_URL or not KRUTIK_API_KEY:
        return None
    video_id = link.split("v=")[-1].split("&")[0] if "v=" in link else link.split("/")[-1].split("?")[0]
    if not video_id or len(video_id) < 3:
        return None

    cached = file_exists(video_id)
    if cached:
        return cached

    os.makedirs("downloads", exist_ok=True)
    file_path = os.path.join("downloads", f"{video_id}.mp3")

    try:
        session = await _get_yt_session()
        params = {"url": video_id, "type": "audio", "api_key": KRUTIK_API_KEY}
        async with session.get(
            f"{PRIMARY_API_URL}/download",
            params=params,
            timeout=aiohttp.ClientTimeout(total=60),
        ) as response:
            if response.status == 429:
                raise Exception("429 Too Many Requests")
            if response.status != 200:
                return None
            content_type = (response.headers.get("Content-Type") or "").lower()
            if "text/html" in content_type or "application/json" in content_type:
                return None
            async with aiofiles.open(file_path, "wb") as f:
                async for chunk in response.content.iter_chunked(1 << 20):
                    await f.write(chunk)

        if os.path.exists(file_path) and os.path.getsize(file_path) > 10240:
            return file_path
        with contextlib.suppress(Exception):
            if os.path.exists(file_path):
                os.remove(file_path)
        return None
    except Exception as e:
        if "429" in str(e):
            raise e
        return None


@backoff_on_429()
async def download_video_primary_api(link: str) -> Optional[str]:
    if not PRIMARY_API_URL or not KRUTIK_API_KEY:
        return None
    video_id = link.split("v=")[-1].split("&")[0] if "v=" in link else link.split("/")[-1].split("?")[0]
    if not video_id or len(video_id) < 3:
        return None

    os.makedirs("downloads", exist_ok=True)
    file_path = os.path.join("downloads", f"{video_id}.mp4")

    if os.path.exists(file_path) and os.path.getsize(file_path) > 10240:
        return file_path

    try:
        session = await _get_yt_session()
        params = {"url": video_id, "type": "video", "api_key": KRUTIK_API_KEY}
        async with session.get(
            f"{PRIMARY_API_URL}/download",
            params=params,
            timeout=aiohttp.ClientTimeout(total=90),
        ) as response:
            if response.status == 429:
                raise Exception("429 Too Many Requests")
            if response.status != 200:
                return None
            content_type = (response.headers.get("Content-Type") or "").lower()
            if "text/html" in content_type or "application/json" in content_type:
                return None
            async with aiofiles.open(file_path, "wb") as f:
                async for chunk in response.content.iter_chunked(1 << 20):
                    await f.write(chunk)

        if os.path.exists(file_path) and os.path.getsize(file_path) > 10240:
            return file_path
        with contextlib.suppress(Exception):
            if os.path.exists(file_path):
                os.remove(file_path)
        return None
    except Exception as e:
        if "429" in str(e):
            raise e
        return None


# ============ YT-DLP CLI EXTRACTION & DOWNLOAD ============
@backoff_on_429()
async def download_video_ytdlp(link: str, title: Optional[str] = None) -> Optional[str]:
    video_id = link.split("v=")[-1].split("&")[0] if "v=" in link else link.split("/")[-1].split("?")[0]
    if not video_id or len(video_id) < 3:
        return None

    file_path = os.path.join("downloads", f"{video_id}.mp4")
    if os.path.exists(file_path) and os.path.getsize(file_path) > 10240:
        return file_path

    res = await yt_dlp_download(link, type="video", title=title)
    if res and os.path.exists(res) and os.path.getsize(res) > 10240:
        return res

    await _check_rate_limit_async()
    try:
        ytdlp_opts = [
            "yt-dlp",
            *(_ytdlp_common_args()),
            "-f",
            "best[height<=?720][width<=?1280]/best",
            "-o",
            file_path,
            link,
        ]
        _, stderr = await _exec_proc(*ytdlp_opts)
        err_str = stderr.decode(errors="ignore")
        if is_youtube_auth_error(err_str):
            _module_logger.warning(f"🔐 YouTube authentication error while downloading video {video_id}.")
            return None
        if "429" in err_str.lower():
            raise Exception("429 Too Many Requests")
        if os.path.exists(file_path) and os.path.getsize(file_path) > 10240:
            return file_path
        return None
    except Exception as e:
        if "429" in str(e):
            raise e
        return None


@backoff_on_429()
async def download_audio_ytdlp(link: str, title: Optional[str] = None) -> Optional[str]:
    video_id = link.split("v=")[-1].split("&")[0] if "v=" in link else link.split("/")[-1].split("?")[0]
    if not video_id or len(video_id) < 3:
        return None

    cached = file_exists(video_id)
    if cached:
        return cached

    res = await yt_dlp_download(link, type="audio", title=title)
    if res and os.path.exists(res) and os.path.getsize(res) > 10240:
        return res

    os.makedirs("downloads", exist_ok=True)
    file_path = os.path.join("downloads", f"{video_id}.webm")
    await _check_rate_limit_async()

    try:
        ytdlp_opts = [
            "yt-dlp",
            *(_ytdlp_common_args()),
            "-f",
            "bestaudio[ext=webm]/bestaudio/best",
            "-o",
            file_path,
            link,
        ]
        _, stderr = await _exec_proc(*ytdlp_opts)
        err_str = stderr.decode(errors="ignore")
        if is_youtube_auth_error(err_str):
            _module_logger.warning(f"🔐 YouTube authentication error while downloading audio {video_id}.")
            return None
        if "429" in err_str.lower():
            raise Exception("429 Too Many Requests")

        if os.path.exists(file_path) and os.path.getsize(file_path) > 10240:
            return file_path
        return file_exists(video_id)
    except Exception as e:
        if "429" in str(e):
            raise e
        return None


# ============ MAIN DOWNLOAD FUNCTIONS ============
async def download_audio(link: str, title: Optional[str] = None) -> Optional[str]:
    result = await download_song_primary_api(link)
    if result:
        return result
    return await download_audio_ytdlp(link, title=title)


async def download_video(link: str, title: Optional[str] = None) -> Optional[str]:
    result = await download_video_primary_api(link)
    if result:
        return result
    return await download_video_ytdlp(link, title=title)


# ============ YOUTUBE SEARCH MULTI ============
@capture_internal_err
async def youtube_search_multi(query: str, limit: int = 8) -> List[Dict]:
    """Fetch multiple YouTube results for a query (used by autoplay)."""
    try:
        data = await VideosSearch(query, limit=limit).next()
        return data.get("result", [])
    except Exception:
        return []


# ============ CACHED YOUTUBE SEARCH ============
@capture_internal_err
async def cached_youtube_search(query: str) -> List[Dict]:
    key = f"q:{query}"
    now = time.time()
    async with _cache_lock:
        if key in _cache:
            ts, val = _cache[key]
            if now - ts < YOUTUBE_META_TTL:
                return val
            _cache.pop(key, None)
    try:
        data = await VideosSearch(query, limit=1).next()
        result = data.get("result", [])
    except Exception:
        result = []
    if result:
        async with _cache_lock:
            if len(_cache) > YOUTUBE_META_MAX:
                _cache.clear()
            _cache[key] = (now, result)
    return result


async def _fetch_oembed_metadata(video_url: str, vid_id: str) -> Optional[Dict]:
    """Fallback metadata via YouTube oEmbed API independent of yt-dlp."""
    try:
        session = await _get_yt_session()
        async with session.get(
            "https://www.youtube.com/oembed",
            params={"url": video_url, "format": "json"},
            timeout=aiohttp.ClientTimeout(total=8),
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                return {
                    "id": vid_id,
                    "title": data.get("title", "YouTube Track"),
                    "duration": "3:30",
                    "thumbnail": data.get("thumbnail_url") or f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg",
                    "link": video_url,
                }
    except Exception:
        pass
    return None


class YouTubeAPI:
    def __init__(self) -> None:
        self.base_url = "https://www.youtube.com/watch?v="
        self.playlist_url = "https://youtube.com/playlist?list="
        self._url_pattern = re.compile(r"(?:youtube\.com|music\.youtube\.com|youtu\.be)")
        self._yt_strict_regex = re.compile(
            r"(https?://)?(www\.|music\.)?(youtube\.com|youtu\.be)/(watch\?v=|playlist\?list=|shorts/|live/)?([a-zA-Z0-9_-]{11,})"
        )

    def _prepare_link(self, link: str, videoid: Union[str, bool, None] = None) -> str:
        link = str(link or "").strip()
        if videoid:
            if isinstance(videoid, str) and videoid.strip():
                link = self.base_url + videoid.strip()
            elif isinstance(videoid, bool) and link and not link.startswith("http"):
                link = self.base_url + link
        if "music.youtube.com" in link:
            link = link.replace("music.youtube.com", "www.youtube.com")
        if "youtu.be" in link:
            link = self.base_url + link.split("/")[-1].split("?")[0]
        elif "youtube.com/shorts/" in link or "youtube.com/live/" in link:
            link = self.base_url + link.split("/")[-1].split("?")[0]
        return link.split("&")[0]

    @capture_internal_err
    async def url(self, message: Message) -> Optional[str]:
        urls = []
        msgs = [message] + ([message.reply_to_message] if message.reply_to_message else [])
        for msg in msgs:
            text = msg.text or msg.caption or ""
            entities = msg.entities or msg.caption_entities or []
            for ent in entities:
                extracted = None
                if ent.type == MessageEntityType.URL:
                    extracted = text[ent.offset : ent.offset + ent.length]
                elif ent.type == MessageEntityType.TEXT_LINK:
                    extracted = ent.url
                if extracted and self._url_pattern.search(extracted):
                    match = self._yt_strict_regex.search(extracted)
                    if match:
                        urls.append(match.group(0))
            if not urls:
                matches = self._yt_strict_regex.finditer(text)
                for m in matches:
                    urls.append(m.group(0))
        if not urls:
            return None
        seen = set()
        unique_urls = [x for x in urls if not (x in seen or seen.add(x))]
        return unique_urls[0]

    @capture_internal_err
    async def exists(self, link: str, videoid: Union[str, bool, None] = None) -> bool:
        return bool(self._url_pattern.search(self._prepare_link(link, videoid)))

    @capture_internal_err
    async def details(
        self, link: str, videoid: Union[str, bool, None] = None
    ) -> Tuple[str, Optional[str], int, str, str]:
        q = self._prepare_link(link, videoid)
        vid_id = q.split("v=")[-1].split("&")[0] if "v=" in q else ""
        info = await cached_youtube_search(q)
        if info:
            matched = next((x for x in info if vid_id and x.get("id") == vid_id), None)
            if matched:
                r = matched
                dt = r.get("duration")
                ds = int(time_to_seconds(dt)) if dt else 0
                thumb = (r.get("thumbnail") or r.get("thumbnails", [{}])[0].get("url", "")).split("?")[0]
                return r.get("title", ""), dt, ds, thumb, r.get("id", "")
            if not vid_id:
                r = info[0]
                dt = r.get("duration")
                ds = int(time_to_seconds(dt)) if dt else 0
                thumb = (r.get("thumbnail") or r.get("thumbnails", [{}])[0].get("url", "")).split("?")[0]
                return r.get("title", ""), dt, ds, thumb, r.get("id", "")

        if vid_id:
            oembed = await _fetch_oembed_metadata(q, vid_id)
            if oembed:
                fallback_dt = (info[0].get("duration") if info else None) or oembed["duration"]
                return (
                    oembed["title"],
                    fallback_dt,
                    int(time_to_seconds(fallback_dt)) if fallback_dt else 210,
                    oembed["thumbnail"],
                    vid_id,
                )

        if info:
            r = info[0]
            dt = r.get("duration")
            ds = int(time_to_seconds(dt)) if dt else 0
            thumb = (r.get("thumbnail") or r.get("thumbnails", [{}])[0].get("url", "")).split("?")[0]
            return r.get("title", ""), dt, ds, thumb, vid_id or r.get("id", "")

        raise ValueError("Video not found")

    @capture_internal_err
    async def title(self, link: str, videoid: Union[str, bool, None] = None) -> str:
        t, _, _, _, _ = await self.details(link, videoid)
        return t

    @capture_internal_err
    async def duration(self, link: str, videoid: Union[str, bool, None] = None) -> Optional[str]:
        _, dt, _, _, _ = await self.details(link, videoid)
        return dt

    @capture_internal_err
    async def thumbnail(self, link: str, videoid: Union[str, bool, None] = None) -> str:
        q = self._prepare_link(link, videoid)
        try:
            _, _, _, thumb, _ = await self.details(link, videoid)
            if thumb:
                return thumb
        except Exception:
            pass
        vid_id = q.split("v=")[-1].split("&")[0] if "v=" in q else q
        return f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg"

    @capture_internal_err
    async def video(self, link: str, videoid: Union[str, bool, None] = None) -> Tuple[int, str]:
        link = self._prepare_link(link, videoid)
        vid = link.split("v=")[-1].split("&")[0] if "v=" in link else link.split("/")[-1].split("?")[0]
        await _check_rate_limit_async()
        format_spec = (
            "best[protocol^=m3u8][height<=?720][vcodec!=none][acodec!=none]/"
            "best[protocol^=m3u8][vcodec!=none][acodec!=none]/"
            "18/"
            "best[ext=mp4][height<=?720][vcodec!=none][acodec!=none]/"
            "best[height<=?720][vcodec!=none][acodec!=none]/"
            "best[vcodec!=none]"
        )
        args = [
            "yt-dlp",
            *(_ytdlp_common_args()),
            "--print",
            "META:%(format_id)s|%(ext)s|%(protocol)s|%(vcodec)s|%(acodec)s|%(height)s",
            "--print",
            "URL:%(url)s",
            "-f",
            format_spec,
            link,
        ]
        stdout, stderr = await _exec_proc(*args)
        if stdout:
            meta_str = ""
            stream_url = ""
            for raw_line in stdout.decode(errors="ignore").splitlines():
                line = raw_line.strip()
                if line.startswith("META:"):
                    meta_str = line[5:]
                elif line.startswith("URL:") and line[4:].startswith("http"):
                    stream_url = line[4:].strip()
                elif line.startswith("http") and not stream_url:
                    stream_url = line
            if stream_url.startswith("http"):
                parts = (meta_str.split("|") + ["?", "?", "?", "?", "?", "?"])[:6]
                fmt_id, ext, proto, vcodec, acodec, height = parts
                _module_logger.info(
                    f"⚡ Direct VIDEO stream extracted in YouTube.video() for {vid} "
                    f"(format_id={fmt_id}, ext={ext}, protocol={proto}, vcodec={vcodec}, acodec={acodec}, height={height}, source={mask_stream_url(stream_url)})."
                )
                return (1, stream_url)
        try:
            downloaded = await download_video(link)
            if downloaded:
                return (1, downloaded)
        except Exception:
            pass
        err_msg = stderr.decode(errors="ignore") if stderr else "Failed to get stream"
        if is_youtube_auth_error(err_msg):
            _module_logger.warning("🔐 YouTube authentication error in YouTube.video() direct URL extraction.")
        return (0, err_msg)

    @capture_internal_err
    async def playlist(
        self, link: str, limit: int, user_id, videoid: Union[str, bool, None] = None
    ) -> List[str]:
        if videoid:
            link = self.playlist_url + str(videoid)
        link = link.split("&")[0]
        await _check_rate_limit_async()
        stdout, _ = await _exec_proc(
            "yt-dlp",
            *(_ytdlp_common_args()),
            "-i",
            "--get-id",
            "--flat-playlist",
            "--playlist-end",
            str(limit),
            link,
        )
        res = stdout.decode(errors="ignore") if stdout else ""
        return [k.strip() for k in res.split("\n") if k.strip()]

    @capture_internal_err
    async def track(self, link: str, videoid: Union[str, bool, None] = None) -> Tuple[Dict, str]:
        prepared = self._prepare_link(link, videoid)
        vid_candidate = prepared.split("v=")[-1].split("&")[0] if "v=" in prepared else ""
        info = None
        res = []
        try:
            res = await cached_youtube_search(prepared)
            if res:
                if vid_candidate and len(vid_candidate) == 11:
                    info = next((x for x in res if x.get("id") == vid_candidate), None)
                else:
                    info = res[0]
        except Exception:
            info = None

        if not info and vid_candidate and len(vid_candidate) == 11:
            info = await _fetch_oembed_metadata(prepared, vid_candidate)
            if info and res and res[0].get("duration"):
                info["duration"] = res[0]["duration"]

        if not info:
            await _check_rate_limit_async()
            stdout, stderr = await _exec_proc("yt-dlp", *(_ytdlp_common_args()), "--dump-json", prepared)
            if not stdout:
                err_txt = stderr.decode(errors="ignore") if stderr else "Not found"
                if is_youtube_auth_error(err_txt):
                    raise YouTubeAuthError("YouTube authentication required for track metadata.")
                raise ValueError("Track not found")
            info = json.loads(stdout.decode(errors="ignore").splitlines()[0])

        thumb = (info.get("thumbnail") or info.get("thumbnails", [{}])[0].get("url", "")).split("?")[0]
        vid_id = info.get("id") or vid_candidate or ""
        resolved_link = (
            info.get("link")
            or info.get("webpage_url")
            or (f"{self.base_url}{vid_id}" if vid_id else prepared)
        )
        duration_val = info.get("duration")
        if isinstance(duration_val, (int, float)):
            mins, secs = divmod(int(duration_val), 60)
            duration_val = f"{mins}:{secs:02d}"
        details = {
            "title": info.get("title", ""),
            "link": resolved_link,
            "vidid": vid_id,
            "duration_min": duration_val,
            "thumb": thumb,
        }
        return details, vid_id

    @capture_internal_err
    async def formats(self, link: str, videoid: Union[str, bool, None] = None) -> Tuple[List[Dict], str]:
        link = self._prepare_link(link, videoid)
        now = time.time()
        async with _formats_lock:
            if link in _formats_cache:
                ts, fmts, l = _formats_cache[link]
                if now - ts < YOUTUBE_META_TTL:
                    return fmts, l

        def _extract_formats():
            opts = _ytdlp_base_opts()
            with yt_dlp.YoutubeDL(opts) as ydl:
                r = ydl.extract_info(link, download=False)
                formats_available = []
                for fmt in r.get("formats", []):
                    if "dash" in str(fmt.get("format", "")).lower():
                        continue
                    if not fmt.get("filesize") and not fmt.get("filesize_approx"):
                        continue
                    formats_available.append(
                        {
                            "format": fmt.get("format"),
                            "filesize": fmt.get("filesize") or fmt.get("filesize_approx"),
                            "format_id": fmt.get("format_id"),
                            "ext": fmt.get("ext"),
                            "format_note": fmt.get("format_note"),
                            "yturl": link,
                        }
                    )
                return formats_available

        loop = asyncio.get_running_loop()
        formats_available = await loop.run_in_executor(None, _extract_formats)
        async with _formats_lock:
            _formats_cache[link] = (now, formats_available, link)
        return formats_available, link

    @capture_internal_err
    async def slider(
        self,
        link: str,
        query_type: int,
        videoid: Union[str, bool, None] = None,
    ) -> Tuple[str, Optional[str], str, str]:
        q = self._prepare_link(link, videoid)
        results = await youtube_search_multi(q, limit=10)
        if not results:
            raise ValueError("No results found for slider")
        idx = min(max(0, query_type), len(results) - 1)
        r = results[idx]
        title = r.get("title", "")
        duration_min = r.get("duration")
        thumbnail = (r.get("thumbnail") or r.get("thumbnails", [{}])[0].get("url", "")).split("?")[0]
        vidid = r.get("id", "")
        return title, duration_min, thumbnail, vidid

    @capture_internal_err
    async def download(
        self,
        link: str,
        mystic,
        *,
        video: Union[bool, str, None] = None,
        videoid: Union[str, bool, None] = None,
        songaudio: Union[bool, str, None] = None,
        songvideo: Union[bool, str, None] = None,
        format_id: Union[bool, str, None] = None,
        title: Union[bool, str, None] = None,
    ) -> Union[Tuple[str, Optional[bool]], Tuple[None, None]]:
        link = self._prepare_link(link, videoid)
        vid = link.split("v=")[-1].split("&")[0] if "v=" in link else link.split("/")[-1].split("?")[0]
        is_video = bool(video)

        if songvideo and format_id and title:
            res = await yt_dlp_download(link, type="song_video", format_id=str(format_id), title=str(title))
            return (res, True) if res else (None, None)

        if songaudio and format_id and title:
            res = await yt_dlp_download(link, type="song_audio", format_id=str(format_id), title=str(title))
            return (res, True) if res else (None, None)

        search_title = title if isinstance(title, str) and title.strip() else None
        if not search_title:
            with contextlib.suppress(Exception):
                res = await cached_youtube_search(link)
                if res:
                    search_title = res[0].get("title")

        # 1. STREAM-BASED PLAYBACK FIRST: Extract direct audio/video streaming URL (zero disk downloads)
        await _check_rate_limit_async()
        format_spec = (
            "best[protocol^=m3u8][acodec!=none]/bestaudio[protocol^=m3u8][acodec!=none]/18/best"
            if not is_video
            else (
                "best[protocol^=m3u8][height<=?720][vcodec!=none][acodec!=none]/"
                "best[protocol^=m3u8][vcodec!=none][acodec!=none]/"
                "18/"
                "best[ext=mp4][height<=?720][vcodec!=none][acodec!=none]/"
                "best[height<=?720][vcodec!=none][acodec!=none]/"
                "best[vcodec!=none]"
            )
        )
        _module_logger.info(
            f"🔍 Extracting YouTube direct stream for {vid} (video={is_video}, selector={format_spec.split('/')[0]})..."
        )
        stdout, stderr = await _exec_proc(
            "yt-dlp",
            *(_ytdlp_common_args()),
            "--print",
            "META:%(format_id)s|%(ext)s|%(protocol)s|%(vcodec)s|%(acodec)s|%(height)s",
            "--print",
            "URL:%(url)s",
            "-f",
            format_spec,
            link,
        )
        if stdout:
            meta_str = ""
            stream_url = ""
            for raw_line in stdout.decode(errors="ignore").splitlines():
                line = raw_line.strip()
                if line.startswith("META:"):
                    meta_str = line[5:]
                elif line.startswith("URL:") and line[4:].startswith("http"):
                    stream_url = line[4:].strip()
                elif line.startswith("http") and not stream_url:
                    stream_url = line
            if stream_url.startswith("http"):
                parts = (meta_str.split("|") + ["?", "?", "?", "?", "?", "?"])[:6]
                fmt_id, ext, proto, vcodec, acodec, height = parts
                if is_video and vcodec in ("none", "None", ""):
                    _module_logger.warning(
                        f"⚠️ Selected format {fmt_id} for {vid} has no video stream (vcodec={vcodec}); falling back."
                    )
                else:
                    _module_logger.info(
                        f"⚡ Direct {'VIDEO' if is_video else 'AUDIO'} streaming URL extracted for {vid} "
                        f"(zero disk download | video={is_video} | format_id={fmt_id} | ext={ext} | protocol={proto} "
                        f"| vcodec={vcodec} | acodec={acodec} | height={height} | source={mask_stream_url(stream_url)})."
                    )
                    return stream_url, False

        # 2. Cached file check (strictly matches .mp4 when is_video=True)
        cached = file_exists(vid, video=is_video)
        if cached:
            _module_logger.info(f"📦 Using cached local {'video' if is_video else 'audio'} file for {vid}: {cached}")
            return cached, True

        # 3. Fallback to download only if direct stream extraction returned nothing
        if is_video:
            video_res = await download_video(link, title=search_title)
            if video_res and os.path.exists(video_res) and os.path.getsize(video_res) > 10240:
                return video_res, True
        else:
            audio_res = await download_audio_concurrent(link, title=search_title)
            if audio_res and os.path.exists(audio_res) and os.path.getsize(audio_res) > 10240:
                return audio_res, True

            audio_res = await download_audio(link, title=search_title)
            if audio_res and os.path.exists(audio_res) and os.path.getsize(audio_res) > 10240:
                return audio_res, True

        err_text = stderr.decode(errors="ignore") if stderr else ""
        if is_youtube_auth_error(err_text):
            raise YouTubeAuthError(f"YouTube authentication failed for {vid}")
        if is_youtube_unavailable_error(err_text):
            raise YouTubeUnavailableError(f"YouTube video unavailable: {vid}")

        return None, None


YouTube = YouTubeAPI()

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
