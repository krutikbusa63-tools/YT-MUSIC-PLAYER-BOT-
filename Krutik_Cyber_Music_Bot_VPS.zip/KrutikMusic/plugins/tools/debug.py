from pyrogram import filters
from KrutikMusic import app
from KrutikMusic.logging import LOGGER


@app.on_message(filters.all, group=-99)
async def debug_log_incoming_message(client, message):
    user_id = message.from_user.id if message.from_user else "unknown"
    chat_id = message.chat.id if message.chat else "unknown"
    chat_type = message.chat.type.name if message.chat and message.chat.type else "unknown"
    text = (message.text or message.caption or "<media/service>").replace("\n", " ")[:120]
    LOGGER("KrutikMusic.updates").info(
        f"📩 Incoming message | chat={chat_id} ({chat_type}) | user={user_id} | text={text}"
    )


@app.on_callback_query(group=-99)
async def debug_log_incoming_callback(client, callback_query):
    user_id = callback_query.from_user.id if callback_query.from_user else "unknown"
    chat_id = (
        callback_query.message.chat.id
        if callback_query.message and callback_query.message.chat
        else "unknown"
    )
    data = (callback_query.data or "")[:80]
    LOGGER("KrutikMusic.updates").info(
        f"🔘 Incoming callback | chat={chat_id} | user={user_id} | data={data}"
    )
