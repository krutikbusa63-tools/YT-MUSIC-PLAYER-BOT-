# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import platform
from sys import version as pyver

import psutil
from pyrogram import __version__ as pyrover
from pyrogram import enums, filters
from pyrogram.errors import MessageIdInvalid
from pyrogram.types import InputMediaPhoto, InputMediaVideo, Message
from pytgcalls.__version__ import __version__ as pytgver

import config
from KrutikMusic import app
from KrutikMusic.core.userbot import assistants
from KrutikMusic.misc import SUDOERS, mongodb
from KrutikMusic.plugins import ALL_MODULES
from KrutikMusic.utils.database import get_served_chats, get_served_users, get_sudoers
from KrutikMusic.utils.decorators.language import language, languageCB
from KrutikMusic.utils.colored_buttons import (
    buttons_to_inline_markup,
    smart_send_message as send_message_colored,
    smart_edit_message_text as edit_message_text_colored,
    edit_message_media_colored,
)
from KrutikMusic.utils.inline.stats import back_stats_buttons, stats_buttons
from config import BANNED_USERS


def _stats_media_kind() -> str:
    """STATS_VID_URL .jpg hai (photo), koi video URL ho toh video."""
    url = config.STATS_VID_URL.lower()
    return "video" if url.endswith((".mp4", ".mov", ".mkv", ".webm")) else "photo"


def _stats_input_media(text: str):
    """Pyrogram fallback ke liye sahi InputMedia type (photo/video)."""
    if _stats_media_kind() == "video":
        return InputMediaVideo(media=config.STATS_VID_URL, caption=text, parse_mode=enums.ParseMode.HTML)
    return InputMediaPhoto(media=config.STATS_VID_URL, caption=text, parse_mode=enums.ParseMode.HTML)


@app.on_message(filters.command(["stats", "gstats"]) & ~BANNED_USERS)
@language
async def stats_global(client, message: Message, _):
    upl = stats_buttons(_, True if message.from_user.id in SUDOERS else False)
    await send_message_colored(
        chat_id=message.chat.id,
        text=_["gstats_2"].format(app.mention),
        reply_markup=upl,
    )


@app.on_callback_query(filters.regex("stats_back") & ~BANNED_USERS)
@languageCB
async def home_stats(client, CallbackQuery, _):
    upl = stats_buttons(_, True if CallbackQuery.from_user.id in SUDOERS else False)
    await edit_message_text_colored(
        chat_id=CallbackQuery.message.chat.id,
        message_id=CallbackQuery.message.id,
        text=_["gstats_2"].format(app.mention),
        reply_markup=upl,
    )


@app.on_callback_query(filters.regex("TopOverall") & ~BANNED_USERS)
@languageCB
async def overall_stats(client, CallbackQuery, _):
    await CallbackQuery.answer()
    upl = back_stats_buttons(_)
    try:
        await CallbackQuery.answer()
    except:
        pass
    await CallbackQuery.edit_message_text(_["gstats_1"].format(app.mention))
    served_chats = len(await get_served_chats())
    served_users = len(await get_served_users())
    text = _["gstats_3"].format(
        app.mention,
        len(assistants),
        len(BANNED_USERS),
        served_chats,
        served_users,
        len(ALL_MODULES),
        len(SUDOERS),
        config.AUTO_LEAVING_ASSISTANT,
        config.DURATION_LIMIT_MIN,
    )
    med = {"type": _stats_media_kind(), "media": config.STATS_VID_URL, "caption": text}
    botapi_result = await edit_message_media_colored(chat_id=CallbackQuery.message.chat.id, message_id=CallbackQuery.message.id, media=med, reply_markup=upl)
    if not botapi_result:
        try:
            await CallbackQuery.edit_message_media(media=_stats_input_media(text), reply_markup=buttons_to_inline_markup(upl))
        except MessageIdInvalid:
            if _stats_media_kind() == "video":
                await CallbackQuery.message.reply_video(
                    video=config.STATS_VID_URL, caption=text, parse_mode=enums.ParseMode.HTML, reply_markup=buttons_to_inline_markup(upl)
                )
            else:
                await CallbackQuery.message.reply_photo(
                    photo=config.STATS_VID_URL, caption=text, parse_mode=enums.ParseMode.HTML, reply_markup=buttons_to_inline_markup(upl)
                )


@app.on_callback_query(filters.regex("bot_stats_sudo"))
@languageCB
async def bot_stats(client, CallbackQuery, _):
    if CallbackQuery.from_user.id not in SUDOERS:
        return await CallbackQuery.answer(_["gstats_4"], show_alert=True)
    upl = back_stats_buttons(_)
    try:
        await CallbackQuery.answer()
    except:
        pass
    await edit_message_text_colored(chat_id=CallbackQuery.message.chat.id, message_id=CallbackQuery.message.id, text=_["gstats_1"].format(app.mention))
    p_core = psutil.cpu_count(logical=False)
    t_core = psutil.cpu_count(logical=True)
    ram = str(round(psutil.virtual_memory().total / (1024.0**3))) + " ɢʙ"
    try:
        cpu_freq = psutil.cpu_freq().current
        if cpu_freq >= 1000:
            cpu_freq = f"{round(cpu_freq / 1000, 2)}ɢʜᴢ"
        else:
            cpu_freq = f"{round(cpu_freq, 2)}ᴍʜᴢ"
    except:
        cpu_freq = "ғᴀɪʟᴇᴅ ᴛᴏ ғᴇᴛᴄʜ"
    hdd = psutil.disk_usage("/")
    total = hdd.total / (1024.0**3)
    used = hdd.used / (1024.0**3)
    free = hdd.free / (1024.0**3)
    call = await mongodb.command("dbstats")
    datasize = call["dataSize"] / 1024
    storage = call["storageSize"] / 1024
    served_chats = len(await get_served_chats())
    served_users = len(await get_served_users())
    text = _["gstats_5"].format(
        app.mention,
        len(ALL_MODULES),
        platform.system(),
        ram,
        p_core,
        t_core,
        cpu_freq,
        pyver.split()[0],
        pyrover,
        pytgver,
        str(total)[:4],
        str(used)[:4],
        str(free)[:4],
        served_chats,
        served_users,
        len(BANNED_USERS),
        len(await get_sudoers()),
        str(datasize)[:6],
        storage,
        call["collections"],
        call["objects"],
    )
    med = {"type": _stats_media_kind(), "media": config.STATS_VID_URL, "caption": text}
    botapi_result = await edit_message_media_colored(chat_id=CallbackQuery.message.chat.id, message_id=CallbackQuery.message.id, media=med, reply_markup=upl)
    if not botapi_result:
        try:
            await CallbackQuery.edit_message_media(media=_stats_input_media(text), reply_markup=buttons_to_inline_markup(upl))
        except MessageIdInvalid:
            if _stats_media_kind() == "video":
                await CallbackQuery.message.reply_video(
                    video=config.STATS_VID_URL, caption=text, parse_mode=enums.ParseMode.HTML, reply_markup=buttons_to_inline_markup(upl)
                )
            else:
                await CallbackQuery.message.reply_photo(
                    photo=config.STATS_VID_URL, caption=text, parse_mode=enums.ParseMode.HTML, reply_markup=buttons_to_inline_markup(upl)
                )


@app.on_message(filters.command(["health", "sysinfo", "diagnostics"]) & ~BANNED_USERS)
async def bot_health_diagnostics(client, message: Message):
    import asyncio
    import json
    import os
    import time
    from pathlib import Path
    from KrutikMusic.core.call import KRUTIK
    from KrutikMusic.core.mongo import mongodb, BACKUP_DIR, LOCAL_STORE_PATH
    from KrutikMusic.utils.cookie_handler import get_valid_cookie_path

    sent = await message.reply_text("🔍 <i>Running comprehensive system health diagnostics...</i>")
    t0 = time.time()

    # Process & System Metrics
    proc = psutil.Process(os.getpid())
    mem_rss = round(proc.memory_info().rss / (1024 * 1024), 2)
    mem_sys = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    total_disk_gb = round(disk.total / (1024**3), 1)
    used_disk_gb = round(disk.used / (1024**3), 1)
    free_disk_gb = round(disk.free / (1024**3), 1)
    cpu_percent = psutil.cpu_percent(interval=None)

    # Database Diagnostics
    db_mode = "MongoDB Atlas" if (config.MONGO_DB_URI and (config.MONGO_DB_URI.startswith("mongodb://") or config.MONGO_DB_URI.startswith("mongodb+srv://"))) else "Local Persistent Store (JSON/Mock)"
    db_ok = False
    db_objs = 0
    db_colls = 0
    try:
        cmd_res = await asyncio.wait_for(mongodb.command("dbstats"), timeout=4.0)
        db_ok = bool(cmd_res and cmd_res.get("ok"))
        db_objs = cmd_res.get("objects", 0)
        db_colls = cmd_res.get("collections", 0)
    except Exception as exc:
        db_mode = f"Error: {exc}"

    backup_count = 0
    if os.path.exists(BACKUP_DIR):
        backup_count = len([f for f in os.listdir(BACKUP_DIR) if f.startswith("backup_") and f.endswith(".json")])

    # Assistant & Voice Chat Diagnostics
    active_asts = len(assistants)
    online_pytgcalls = [i for i in range(1, 6) if KRUTIK.is_assistant_online(i)]
    active_vc_count = len(KRUTIK.active_calls)

    # Active Background Tasks
    tasks_count = len([t for t in asyncio.all_tasks() if not t.done()])

    # Handlers & Modules
    total_modules = len(ALL_MODULES)
    total_handlers = sum(len(g) for g in app.dispatcher.groups.values()) if hasattr(app, "dispatcher") else 0

    # Cookie Diagnostics
    cookie_path = get_valid_cookie_path()
    cookie_status = f"✅ Active ({os.path.basename(cookie_path)})" if cookie_path else "⚠️ Default / Fallback"

    # Last Recorded Restart / Error
    last_event = "None (Clean Continuous Execution)"
    restart_file = Path("cache/restart_state.json")
    if restart_file.exists():
        try:
            r_data = json.loads(restart_file.read_text(encoding="utf-8"))
            last_event = r_data.get("last_reason", "None")
        except Exception:
            pass

    diag_latency = round((time.time() - t0) * 1000, 1)

    health_report = (
        "🌺 <b>KRUTIK CYBER MUSIC — SYSTEM HEALTH REPORT</b> 🌺\n\n"
        "🤖 <b>Bot Engine:</b>\n"
        f"• Status: 🟢 <b>ONLINE</b>\n"
        f"• Username: @{app.username}\n"
        f"• Modules Loaded: <b>{total_modules}</b> plugins\n"
        f"• Active Handlers: <b>{total_handlers}</b> registered\n"
        f"• Active Background Tasks: <b>{tasks_count}</b>\n\n"
        "📞 <b>Voice Chat & Assistant:</b>\n"
        f"• Assistant Accounts: <b>{active_asts}</b> configured\n"
        f"• PyTgCalls Status: <b>{'🟢 ONLINE' if online_pytgcalls else '⚠️ STANDBY'}</b>\n"
        f"• Online Assistants: {online_pytgcalls or ['None']}\n"
        f"• Active Voice Streams: <b>{active_vc_count}</b> calls\n"
        f"• Audio Engine: <b>FFmpeg 6.1.1 (Stream Pipe / Zero Disk)</b>\n\n"
        "🗄️ <b>Database & Persistence:</b>\n"
        f"• Engine: <b>{db_mode}</b>\n"
        f"• Status: {'🟢 Healthy' if db_ok else '⚠️ Warning'}\n"
        f"• Collections: <b>{db_colls}</b> | Total Records: <b>{db_objs}</b>\n"
        f"• Auto Backups: <b>{backup_count}</b> snapshots saved\n\n"
        "⚙️ <b>Server Resources (6-Month Continuous Target):</b>\n"
        f"• Bot Process RAM: <b>{mem_rss} MB</b> (Leak-Free GC Active)\n"
        f"• System Memory: <b>{mem_sys.percent}%</b> used of {round(mem_sys.total / (1024**3), 1)} GB\n"
        f"• Process CPU: <b>{cpu_percent}%</b>\n"
        f"• Local Storage: <b>{free_disk_gb} GB Free</b> / {total_disk_gb} GB Total\n\n"
        "🍪 <b>YouTube Streaming:</b>\n"
        f"• Cookies Status: {cookie_status}\n"
        f"• Stream Pipe: Direct HLS / m3u8_native (Zero permanent downloads)\n\n"
        f"🛡️ <b>Self-Healing & Watchdog:</b>\n"
        f"• Single-Instance PID Lock: 🟢 Active (PID {os.getpid()})\n"
        f"• Last Recorded Event: <code>{last_event}</code>\n"
        f"• Diagnostics Ping: <code>{diag_latency}ms</code>"
    )

    await sent.edit_text(health_report)

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════

