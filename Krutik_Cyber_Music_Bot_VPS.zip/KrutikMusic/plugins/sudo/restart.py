# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import os
import shutil
import socket
import sys
from datetime import datetime

import urllib3
from git import Repo
from git.exc import GitCommandError, InvalidGitRepositoryError
from pyrogram import filters

import config
from KrutikMusic import app
from KrutikMusic.misc import HAPP, SUDOERS, XCB
from KrutikMusic.utils.database import (
    get_active_chats,
    remove_active_chat,
    remove_active_video_chat,
)
from KrutikMusic.utils.decorators.language import language
from KrutikMusic.utils.pastebin import KRUTIKBIN

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

async def is_heroku():
    return "heroku" in socket.getfqdn()

def cleanup_storage():
    folders_to_remove = ["downloads", "raw_files", "cache"]
    for folder in folders_to_remove:
        try:
            shutil.rmtree(folder)
        except FileNotFoundError:
            pass
        except Exception as e:
            print(f"[CLEANUP] Failed to delete {folder}: {e}")

    for root, dirs, files in os.walk("."):
        for d in dirs:
            if d == "__pycache__":
                try:
                    shutil.rmtree(os.path.join(root, d))
                except:
                    pass


@app.on_message(filters.command(["getlog", "logs", "getlogs"]) & SUDOERS)
@language
async def log_(client, message, _):
    try:
        await message.reply_document(document="log.txt")
    except:
        await message.reply_text(_["server_1"])


@app.on_message(filters.command(["update", "gitpull"]) & SUDOERS)
@language
async def update_(client, message, _):
    if await is_heroku():
        if HAPP is None:
            return await message.reply_text(_["server_2"])

    response = await message.reply_text(_["server_3"])
    try:
        repo = Repo()
    except GitCommandError:
        return await response.edit(_["server_4"])
    except InvalidGitRepositoryError:
        return await response.edit(_["server_5"])

    # Ensure we're fetching from correct remote URL
    try:
        if config.GIT_TOKEN:
            GIT_USERNAME = config.UPSTREAM_REPO.split("com/")[1].split("/")[0]
            TEMP_REPO = config.UPSTREAM_REPO.split("https://")[1]
            UPSTREAM_URL = f"https://{GIT_USERNAME}:{config.GIT_TOKEN}@{TEMP_REPO}"
        else:
            UPSTREAM_URL = config.UPSTREAM_REPO
        if "origin" in repo.remotes:
            origin = repo.remote("origin")
            current_url = list(origin.urls)[0]
            if current_url != UPSTREAM_URL:
                origin.set_url(UPSTREAM_URL)
        else:
            repo.create_remote("origin", UPSTREAM_URL)
    except Exception:
        pass

    try:
        repo.remotes.origin.fetch(config.UPSTREAM_BRANCH)
    except GitCommandError as e:
        # Retry once with force flag
        try:
            repo.git.fetch("origin", config.UPSTREAM_BRANCH, "--force")
        except Exception:
            return await response.edit(
                f"<b>❌ ғᴇᴛᴄʜ ғᴀɪʟᴇᴅ!</b>\n\n<code>{e}</code>"
            )
    await asyncio.sleep(2)

    verification = ""
    REPO_ = repo.remotes.origin.url.split(".git")[0]
    for checks in repo.iter_commits(f"HEAD..origin/{config.UPSTREAM_BRANCH}"):
        verification = str(checks.count())

    if verification == "":
        return await response.edit(_["server_6"])

    updates = ""
    ordinal = lambda format: "%d%s" % (
        format,
        "tsnrhtdd"[(format // 10 % 10 != 1) * (format % 10 < 4) * format % 10 :: 4],
    )
    for info in repo.iter_commits(f"HEAD..origin/{config.UPSTREAM_BRANCH}"):
        updates += (
            f"<b>\u2793 #{info.count()}: <a href={REPO_}/commit/{info}>{info.summary}</a> ʙʏ -> {info.author}</b>\n"
            f"\t\t\t\t<b>\u279e ᴄᴏᴍᴍɪᴛᴇᴅ ᴏɴ :</b> {ordinal(int(datetime.fromtimestamp(info.committed_date).strftime('%d')))} "
            f"{datetime.fromtimestamp(info.committed_date).strftime('%b')}, {datetime.fromtimestamp(info.committed_date).strftime('%Y')}\n\n"
        )

    _update_response_ = (
        "<b>ᴀ ɴᴇᴡ ᴜᴩᴅᴀᴛᴇ ɪs ᴀᴠᴀɪʟᴀʙʟᴇ ғᴏʀ ᴛʜᴇ ʙᴏᴛ !</b>\n\n"
        "\u2793 ᴩᴜsʜɪɴɢ ᴜᴩᴅᴀᴛᴇs ɴᴏᴡ\n\n"
        "<b><u>ᴜᴩᴅᴀᴛᴇs:</u></b>\n\n"
    )
    _final_updates_ = _update_response_ + updates

    if len(_final_updates_) > 4096:
        url = await KRUTIKBIN(updates)
        nrs = await response.edit(
            f"<b>ᴀ ɴᴇᴡ ᴜᴩᴅᴀᴛᴇ ɪs ᴀᴠᴀɪʟᴀʙʟᴇ ғᴏʀ ᴛʜᴇ ʙᴏᴛ !</b>\n\n"
            f"\u2793 ᴩᴜsʜɪɴɢ ᴜᴩᴅᴀᴛᴇs ɴᴏᴡ\n\n"
            f"<u><b>ᴜᴩᴅᴀᴛᴇs :</b></u>\n\n<a href={url}>ᴄʜᴇᴄᴋ ᴜᴩᴅᴀᴛᴇs</a>"
        )
    else:
        nrs = await response.edit(_final_updates_, disable_web_page_preview=True)

    # Remove stale lock file if exists (prevents git failures after crash)
    lock_path = os.path.join(repo.git_dir, "index.lock")
    if os.path.exists(lock_path):
        try:
            os.remove(lock_path)
        except Exception:
            pass

    # Force update files from upstream
    try:
        repo.git.stash()
    except Exception:
        pass

    try:
        repo.git.reset("--hard", f"origin/{config.UPSTREAM_BRANCH}")
    except Exception as e:
        return await response.edit(
            f"<b>❌ ᴜᴩᴅᴀᴛᴇ ғᴀɪʟᴇᴅ!</b>\n\n<code>{e}</code>"
        )

    # Verify HEAD matches origin after reset
    try:
        local_head = repo.head.commit.hexsha
        origin_head = repo.remotes.origin.refs[config.UPSTREAM_BRANCH].commit.hexsha
        if local_head != origin_head:
            return await response.edit(
                "<b>❌ ᴜᴩᴅᴀᴛᴇ ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ ғᴀɪʟᴇᴅ!</b>\n\n"
                "<code>HEAD does not match origin after reset. Check git permissions.</code>"
            )
    except Exception:
        pass

    # Install any new requirements after update
    if os.path.exists("requirements.txt"):
        os.system("pip3 install --no-cache-dir -r requirements.txt")

    try:
        served_chats = await get_active_chats()
        for x in served_chats:
            try:
                await app.send_message(chat_id=int(x), text=_["server_8"].format(app.mention))
                await remove_active_chat(x)
                await remove_active_video_chat(x)
            except:
                pass
        await response.edit(f"{nrs.text}\n\n{_['server_7']}")
    except:
        pass

    cleanup_storage()

    if await is_heroku():
        try:
            os.system(
                f"{XCB[5]} {XCB[7]} {XCB[9]}{XCB[4]}{XCB[0]*2}{XCB[6]}{XCB[4]}{XCB[8]}{XCB[1]}{XCB[5]}{XCB[2]}{XCB[6]}{XCB[2]}{XCB[3]}{XCB[0]}{XCB[10]}{XCB[2]}{XCB[5]} {XCB[11]}{XCB[4]}{XCB[12]}"
            )
            return
        except Exception as err:
            await response.edit(f"{nrs.text}\n\n{_['server_9']}")
            return await app.send_message(
                chat_id=config.LOGGER_ID,
                text=_["server_10"].format(err),
            )
    else:
        os.execv(sys.executable, [sys.executable, "-m", "KrutikMusic"])


@app.on_message(filters.command(["restart"]) & SUDOERS)
async def restart_(_, message):
    response = await message.reply_text("ʀᴇsᴛᴀʀᴛɪɴɢ...")
    ac_chats = await get_active_chats()
    for x in ac_chats:
        try:
            await app.send_message(
                chat_id=int(x),
                text=f"{app.mention} ɪs ʀᴇsᴛᴀʀᴛɪɴɢ...\n\nʏᴏᴜ ᴄᴀɴ sᴛᴀʀᴛ ᴩʟᴀʏɪɴɢ ᴀɢᴀɪɴ ᴀғᴛᴇʀ 15-20 sᴇᴄᴏɴᴅs.",
            )
            await remove_active_chat(x)
            await remove_active_video_chat(x)
        except:
            pass

    cleanup_storage()

    await response.edit_text(
        "» ʀᴇsᴛᴀʀᴛ ᴘʀᴏᴄᴇss sᴛᴀʀᴛᴇᴅ, ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ғᴏʀ ғᴇᴡ sᴇᴄᴏɴᴅs ᴜɴᴛɪʟ ᴛʜᴇ ʙᴏᴛ sᴛᴀʀᴛs..."
    )

    os.execv(sys.executable, [sys.executable, "-m", "KrutikMusic"])

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
