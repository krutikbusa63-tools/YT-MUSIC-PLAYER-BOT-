# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

from pyrogram import filters

import config
from KrutikMusic import app, userbot
from KrutikMusic.core.call import KRUTIK
from KrutikMusic.core.userbot import assistants
from KrutikMusic.misc import SUDOERS
from KrutikMusic.utils.database import add_off, add_on, is_on_off
from KrutikMusic.utils.decorators.language import language


async def _build_logger_diagnostics() -> str:
    log_enabled = await is_on_off(2)
    direct_access = bool(getattr(app, "logger_accessible", False))
    via_assistant = bool(getattr(app, "logger_via_assistant", False)) or bool(getattr(userbot, "logger_accessible", False))
    if direct_access:
        bot_access = "✅ Direct (Main Bot is member/admin)"
    elif via_assistant:
        bot_access = "🔄 Active via Assistant Relay (Promote @bot in LOGGER_ID for direct bot posts)"
    else:
        bot_access = "⚠️ Not Accessible (Add bot & assistant to LOGGER_ID)"

    ast_lines = []
    for idx in range(1, 6):
        ub_client = userbot.get_client(idx) if hasattr(userbot, "get_client") else None
        if ub_client is None:
            continue
        is_conn = bool(getattr(ub_client, "is_connected", False))
        pytg_online = KRUTIK.is_assistant_online(idx)
        ast_logger = "✅" if getattr(ub_client, "logger_accessible", False) else "⚠️"
        uname = f"@{ub_client.username}" if getattr(ub_client, "username", None) else "No Username"
        uid = getattr(ub_client, "id", "?")
        status_badge = "🟢 ONLINE" if (is_conn and pytg_online) else ("🟡 MTProto Only" if is_conn else "🔴 OFFLINE")
        ast_lines.append(
            f"  • <b>Assistant {idx}:</b> {status_badge} | {uname} (<code>{uid}</code>) | Logger: {ast_logger}"
        )
    if not ast_lines:
        ast_lines.append("  • ❌ No Assistant sessions configured.")

    return (
        f"📊 <b><u>ʟᴏɢɢᴇʀ & ᴀssɪsᴛᴀɴᴛ ᴅɪᴀɢɴᴏsᴛɪᴄs</u></b>\n\n"
        f"• <b>Play Logger:</b> {'🟢 Enabled' if log_enabled else '🔴 Disabled'}\n"
        f"• <b>LOGGER_ID:</b> <code>{config.LOGGER_ID}</code>\n"
        f"• <b>Logger Delivery:</b> {bot_access}\n"
        f"• <b>Voice-Chat Engine Ready:</b> {'🟢 Yes' if KRUTIK.is_ready else '🔴 No'}\n"
        f"• <b>Active Voice Chats:</b> <code>{len(KRUTIK.active_calls)}</code>\n"
        f"• <b>Active Assistants ({len(assistants)}):</b>\n"
        + "\n".join(ast_lines)
    )


@app.on_message(filters.command(["logger"]) & SUDOERS)
@language
async def logger(client, message, _):
    usage = _["log_1"]
    if len(message.command) != 2:
        diag = await _build_logger_diagnostics()
        return await message.reply_text(f"{diag}\n\n{usage}")
    state = message.text.split(None, 1)[1].strip().lower()
    if state == "enable":
        await add_on(2)
        await message.reply_text(_["log_2"])
    elif state == "disable":
        await add_off(2)
        await message.reply_text(_["log_3"])
    else:
        diag = await _build_logger_diagnostics()
        await message.reply_text(f"{diag}\n\n{usage}")

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
