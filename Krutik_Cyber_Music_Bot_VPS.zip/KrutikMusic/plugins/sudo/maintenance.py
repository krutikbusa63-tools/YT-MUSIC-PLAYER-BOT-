from pyrogram import filters
from pyrogram.types import Message

from config import OWNER_ID
from KrutikMusic import app
from KrutikMusic.core.call import KRUTIK
from KrutikMusic.misc import SUDOERS
from KrutikMusic.utils.database import (
    get_lang,
    is_globalbot_enabled,
    is_globalplay_enabled,
    is_maintenance,
    maintenance_off,
    maintenance_on,
    set_globalbot_status,
    set_globalplay_status,
)
from strings import get_string


def _is_owner_or_sudo(user_id: int) -> bool:
    return (user_id in SUDOERS) or (OWNER_ID and user_id == int(OWNER_ID))


# ═══════════════════════════════════════════════════════════
#  PART 2: GLOBAL BOT ON/OFF CONTROL
# ═══════════════════════════════════════════════════════════

@app.on_message(filters.command(["globalbot", "botmode"]))
async def global_bot_control(client, message: Message):
    user_id = message.from_user.id if message.from_user else 0
    if not _is_owner_or_sudo(user_id):
        return await message.reply_text(
            "❌ <b>Unauthorized Access</b>\n\n"
            "Only the configured <b>Bot Owner & Sudoers</b> are authorized to modify Global Bot status."
        )

    cmd = message.command
    if len(cmd) < 2:
        # Show status & usage
        is_active = await is_globalbot_enabled()
        state_badge = "🟢 <b>ACTIVE (Online for all users)</b>" if is_active else "🔴 <b>MAINTENANCE MODE (Paused for ordinary users)</b>"
        return await message.reply_text(
            f"🤖 <b>KRUTIK CYBER MUSIC — GLOBAL BOT CONTROL</b>\n\n"
            f"• Current State: {state_badge}\n"
            f"• Process & Diagnostics: 🟢 Online (PID {client.me.id})\n\n"
            f"<b>Usage:</b>\n"
            f"• <code>/globalbot on</code> — Enable bot for all users\n"
            f"• <code>/globalbot off</code> — Enable maintenance mode (Admins only)\n"
            f"• <code>/globalbot status</code> — View current global state"
        )

    action = cmd[1].strip().lower()
    if action in ("on", "enable", "start"):
        await set_globalbot_status(True)
        return await message.reply_text(
            "🟢 <b>Global Bot Status: ACTIVE (ON)</b>\n\n"
            "Normal bot operations and command processing have been <b>RESTORED</b> for all users across all chats."
        )
    elif action in ("off", "disable", "stop"):
        await set_globalbot_status(False)
        return await message.reply_text(
            "🔴 <b>Global Bot Status: MAINTENANCE MODE (OFF)</b>\n\n"
            "Normal commands are now <b>PAUSED</b> for ordinary users.\n"
            "The bot process remains alive, and Sudoers/Owner retain full administrative access."
        )
    elif action in ("status", "check", "state"):
        is_active = await is_globalbot_enabled()
        status_text = (
            "🟢 <b>ACTIVE (ONLINE)</b>\nAll users can use bot features normally."
            if is_active
            else "🔴 <b>MAINTENANCE MODE (OFF)</b>\nNormal users receive maintenance notice. Admins retain access."
        )
        return await message.reply_text(
            f"🤖 <b>Global Bot Status:</b>\n{status_text}\n\n"
            f"• Storage: Persistent Database Active\n"
            f"• Host Uptime Monitor: 🟢 Running"
        )
    else:
        return await message.reply_text(
            "⚠️ <b>Invalid Syntax</b>\nUsage: <code>/globalbot on</code> | <code>/globalbot off</code> | <code>/globalbot status</code>"
        )


# ═══════════════════════════════════════════════════════════
#  PART 3: GLOBAL MUSIC PLAYBACK CONTROL
# ═══════════════════════════════════════════════════════════

@app.on_message(filters.command(["globalplay", "playmode_global"]))
async def global_play_control(client, message: Message):
    user_id = message.from_user.id if message.from_user else 0
    if not _is_owner_or_sudo(user_id):
        return await message.reply_text(
            "❌ <b>Unauthorized Access</b>\n\n"
            "Only the configured <b>Bot Owner & Sudoers</b> are authorized to modify Global Playback status."
        )

    cmd = message.command
    if len(cmd) < 2:
        is_play_on = await is_globalplay_enabled()
        badge = "🟢 <b>ENABLED (Active in all groups)</b>" if is_play_on else "🔴 <b>DISABLED (Streaming paused globally)</b>"
        return await message.reply_text(
            f"🎵 <b>KRUTIK CYBER MUSIC — GLOBAL PLAYBACK CONTROL</b>\n\n"
            f"• Current Playback State: {badge}\n"
            f"• Active Group Calls: <b>{len(KRUTIK.active_calls)}</b> streams\n\n"
            f"<b>Usage:</b>\n"
            f"• <code>/globalplay on</code> — Allow music playback in all groups\n"
            f"• <code>/globalplay off</code> — Stop all streams & block new /play requests\n"
            f"• <code>/globalplay status</code> — View current playback status"
        )

    action = cmd[1].strip().lower()
    if action in ("on", "enable", "start"):
        await set_globalplay_status(True)
        return await message.reply_text(
            "🔊 <b>Global Music Playback: ENABLED (ON)</b>\n\n"
            "Music streaming and voice-chat playback have been <b>RESTORED</b> in all authorized groups."
        )
    elif action in ("off", "disable", "stop"):
        await set_globalplay_status(False)
        # Safely stop active calls across all groups
        stopped_count = 0
        for chat_id in list(KRUTIK.active_calls):
            try:
                await KRUTIK.stop_stream(chat_id)
                stopped_count += 1
            except Exception:
                pass
        return await message.reply_text(
            f"🔇 <b>Global Music Playback: DISABLED (OFF)</b>\n\n"
            f"Playback has been stopped in <b>{stopped_count}</b> active voice chats.\n"
            f"New playback requests are now blocked globally. Other commands remain fully functional."
        )
    elif action in ("status", "check", "state"):
        is_play_on = await is_globalplay_enabled()
        status_text = (
            "🟢 <b>ENABLED</b> (Music streaming is active in all authorized groups)"
            if is_play_on
            else "🔴 <b>DISABLED</b> (Music streaming is currently blocked globally)"
        )
        return await message.reply_text(
            f"🎵 <b>Global Playback Status:</b>\n{status_text}\n\n"
            f"• Active Streams: <b>{len(KRUTIK.active_calls)}</b> groups\n"
            f"• Storage Mode: Stream-based (Zero permanent downloads)"
        )
    else:
        return await message.reply_text(
            "⚠️ <b>Invalid Syntax</b>\nUsage: <code>/globalplay on</code> | <code>/globalplay off</code> | <code>/globalplay status</code>"
        )


# ═══════════════════════════════════════════════════════════
#  LEGACY / MAINTENANCE COMPATIBILITY
# ═══════════════════════════════════════════════════════════

@app.on_message(filters.command(["maintenance"]) & SUDOERS)
async def maintenance(client, message: Message):
    try:
        language = await get_lang(message.chat.id)
        _ = get_string(language)
    except:
        _ = get_string("en")
    usage = _["maint_1"]
    if len(message.command) != 2:
        return await message.reply_text(usage)
    state = message.text.split(None, 1)[1].strip().lower()
    if state in ("enable", "on"):
        if await is_maintenance() is False:
            await message.reply_text(_["maint_4"])
        else:
            await maintenance_on()
            await message.reply_text(_["maint_2"].format(app.mention))
    elif state in ("disable", "off"):
        if await is_maintenance() is False:
            await maintenance_off()
            await message.reply_text(_["maint_3"].format(app.mention))
        else:
            await message.reply_text(_["maint_5"])
    else:
        await message.reply_text(usage)


# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
