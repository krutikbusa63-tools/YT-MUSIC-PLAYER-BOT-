# ═══════════════════════════════════════════════════════════
#        🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   GɪᴛHᴜʙ : github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
#   Dᴇᴠʟᴏᴘᴇʀ : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio

from KrutikMusic.misc import db
from KrutikMusic.utils.database import get_active_chats, is_music_playing


async def timer():
    while not await asyncio.sleep(1):
        try:
            active_chats = list(await get_active_chats())
        except Exception:
            continue
        for chat_id in active_chats:
            try:
                if not await is_music_playing(chat_id):
                    continue
                playing = db.get(chat_id)
                if not playing or not isinstance(playing, list) or len(playing) == 0:
                    continue
                duration = int(playing[0].get("seconds") or 0)
                if duration == 0:
                    continue
                current_played = int(playing[0].get("played") or 0)
                if current_played >= duration:
                    continue
                playing[0]["played"] = current_played + 1
            except Exception:
                continue


try:
    asyncio.get_running_loop().create_task(timer())
except RuntimeError:
    pass

# ═══════════════════════════════════════════════════════════
#         🌺 Kʀᴜᴛɪᴋ Cʏʙᴇʀ Mᴜsɪᴄ 🌺
#   github.com/KRUTIK_CYBER_DEVELOPER0/KrutikMusic
# ═══════════════════════════════════════════════════════════
