# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
#   Developer : @KRUTIK_CYBER_DEVELOPER0 | Telegram
# ═══════════════════════════════════════════════════════════

import asyncio
import gc
import importlib
import logging
import os
import time
from threading import Thread

import config


async def _gc_loop() -> None:
    """Periodic garbage collection and disk cleanup loop to keep RAM & storage footprints minimal."""
    from KrutikMusic.core.dir import purge_temporary_media
    while True:
        await asyncio.sleep(300)  # Every 5 mins
        gc.collect()
        try:
            purge_temporary_media(max_age_seconds=300)
        except Exception:
            pass



async def _cookie_refresh_loop() -> None:
    """Periodically re-fetch YouTube cookies.

    Cookies are fetched only once at startup; YouTube invalidates them over
    time, after which every download silently fails (assistant joins the VC
    but no song ever plays). Refreshing keeps the bot healthy on long uptime.
    """
    hours = float(os.environ.get("COOKIE_REFRESH_HOURS", "12"))
    while True:
        await asyncio.sleep(hours * 3600)
        try:
            await fetch_and_store_cookies()
            LOGGER("KrutikMusic").info("ʏᴏᴜᴛᴜʙᴇ ᴄᴏᴏᴋɪᴇs ʀᴇꜰʀᴇꜱʜᴇᴅ ✔")
        except Exception as e:
            LOGGER("KrutikMusic").warning(f"⚠️ ᴄᴏᴏᴋɪᴇ ʀᴇꜰʀᴇꜱʜ ꜰᴀɪʟᴇᴅ: {e}")


async def _auto_restart_loop(hours: float) -> None:
    """Optional watchdog: restart the bot process every N hours.

    Long-running bots degrade over time (stale pytgcalls calls, memory
    growth, dropped sessions). A periodic restart is the standard fix.
    Enable by setting AUTO_RESTART_HOURS in the environment (e.g. 24).
    """
    import sys

    while True:
        await asyncio.sleep(hours * 3600)
        LOGGER("KrutikMusic").info(f"🔄 ᴀᴜᴛᴏ-ʀᴇꜱᴛᴀʀᴛ ᴀꜰᴛᴇʀ {hours}h ᴏꜰ ᴜᴘᴛɪᴍᴇ...")
        try:
            os.execv(sys.executable, [sys.executable, "-m", "KrutikMusic"])
        except Exception as e:
            LOGGER("KrutikMusic").error(f"❌ ᴀᴜᴛᴏ-ʀᴇꜱᴛᴀʀᴛ ꜰᴀɪʟᴇᴅ: {e}")
            return


async def init():
    from KrutikMusic import LOGGER, app, userbot
    from KrutikMusic.core.call import KRUTIK
    from KrutikMusic.misc import sudo
    from KrutikMusic.plugins import ALL_MODULES
    from KrutikMusic.utils.database import get_banned_users, get_gbanned
    from KrutikMusic.utils.cookie_handler import fetch_and_store_cookies
    from config import BANNED_USERS
    from pyrogram import idle
    from pytgcalls.exceptions import NoActiveGroupCall
    try:
        if (
            not config.STRING1
            and not config.STRING2
            and not config.STRING3
            and not config.STRING4
            and not config.STRING5
            and not config.HAS_ASSISTANT_FILE
        ):
            LOGGER("KrutikMusic").error(
                "FATAL: Assistant session not filled.\n"
                "Please set 'STRING_SESSION' (or STRING_SESSION2..5) in your environment.\n"
                "You can generate a session string via @KrutikStringBot or use the Web Panel login."
            )
            return

        # ✅ Try to fetch cookies at startup
        try:
            await fetch_and_store_cookies()
            LOGGER("KrutikMusic").info("ʏᴏᴜᴛᴜʙᴇ ᴄᴏᴏᴋɪᴇs ʟᴏᴀᴅᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅")
        except Exception as e:
            # Handle the 'is_premium' NoneType error or any other cookie failure gracefully
            err_msg = str(e)
            if "NoneType" in err_msg and "is_premium" in err_msg:
                LOGGER("KrutikMusic").warning("⚠️ ʏᴏᴜᴛᴜʙᴇ ᴀᴄᴄᴏᴜɴᴛ ɪɴғᴏ ɴᴏᴛ ғᴏᴜɴᴅ (ɪs_ᴘʀᴇᴍɪᴜᴍ ᴇʀʀᴏʀ). ᴄᴏɴᴛɪɴᴜɪɴɢ ᴡɪᴛʜᴏᴜᴛ ᴘʀᴇᴍɪᴜᴍ ᴄᴏᴏᴋɪᴇs.")
            else:
                LOGGER("KrutikMusic").warning(f"⚠️ ᴄᴏᴏᴋɪᴇ ᴇʀʀᴏʀ: {e}")

        await sudo()

        try:
            users = await get_gbanned()
            for user_id in users:
                BANNED_USERS.add(user_id)
            users = await get_banned_users()
            for user_id in users:
                BANNED_USERS.add(user_id)
        except:
            pass

        # ── 1. Start Bot Client First (reuses krutik_music_bot.session) ──
        await app.start()

        # ── 2. Load All Plugins & Register Message/Callback Handlers ──
        LOGGER("KrutikMusic.plugins").info("ʟᴏᴀᴅɪɴɢ ᴍᴏᴅᴜʟᴇs...")
        loaded_count = 0
        for all_module in ALL_MODULES:
            try:
                importlib.import_module("KrutikMusic.plugins" + all_module)
                loaded_count += 1
            except Exception as e:
                LOGGER("KrutikMusic.plugins").error(
                    f"❌ Failed to load module {all_module}: {e}"
                )
        # Allow Pyrogram's dispatcher.add_handler background tasks to finish registering
        await asyncio.sleep(0.1)
        total_handlers = sum(len(g) for g in app.dispatcher.groups.values())
        LOGGER("KrutikMusic.plugins").info(
            f"ᴍᴏᴅᴜʟᴇs ʟᴏᴀᴅᴇᴅ ✔ ({loaded_count}/{len(ALL_MODULES)} modules, {total_handlers} handlers active)"
        )

        # ── 3. Start Assistant Clients ──
        await userbot.start()

        # ▶️ VC Logger: resume VC join/leave notifications for groups that enabled
        # it. Runs only after the assistant is up.
        try:
            from KrutikMusic.plugins.tools.vclogger import load_vc_logger_status
            asyncio.create_task(load_vc_logger_status())
        except Exception as e:
            LOGGER("KrutikMusic").warning(f"⚠️ ᴠᴄ ʟᴏɢɢᴇʀ ɪɴɪᴛ ғᴀɪʟᴇᴅ: {e}")

        # ── 4. Start PyTgCalls (Voice Chat) & Decorators ──
        await KRUTIK.start()
        await KRUTIK.decorators()

        # Long-uptime health: periodic GC, refresh YouTube cookies periodically, and Self-Healing heartbeat
        from KrutikMusic.core.self_healing import heartbeat_and_self_heal_loop
        from KrutikMusic.platforms.Youtube import load_apis

        asyncio.create_task(load_apis())
        asyncio.create_task(_gc_loop())
        asyncio.create_task(_cookie_refresh_loop())
        asyncio.create_task(heartbeat_and_self_heal_loop())

        if getattr(userbot, "logger_accessible", False):
            try:
                LOGGER("KrutikMusic").info("sᴛᴀʀᴛɪɴɢ ʟᴏɢ ɢʀᴏᴜᴘ sᴛʀᴇᴀᴍ...")
                await asyncio.wait_for(
                    KRUTIK.stream_call("https://files.catbox.moe/euj0oc.mp4"),
                    timeout=10.0,
                )
            except NoActiveGroupCall:
                LOGGER("KrutikMusic").warning(
                    "⚠️ Log group voice chat is currently inactive – continuing startup."
                )
            except asyncio.TimeoutError:
                LOGGER("KrutikMusic").warning(
                    "⚠️ Log group test stream timed out after 10s – continuing startup."
                )
            except Exception as e:
                LOGGER("KrutikMusic").warning(f"⚠️ Log stream skipped: {e}")
        else:
            LOGGER("KrutikMusic").info(
                "Skipping log group test stream (assistant not in LOGGER_ID chat)."
            )

        auto_restart_hours = float(os.environ.get("AUTO_RESTART_HOURS", "0"))
        if auto_restart_hours > 0:
            asyncio.create_task(_auto_restart_loop(auto_restart_hours))
            LOGGER("KrutikMusic").info(f"🔄 ᴀᴜᴛᴏ-ʀᴇꜱᴛᴀʀᴛ ᴇɴᴀʙʟᴇᴅ: ᴇᴠᴇʀʏ {auto_restart_hours}h")

        LOGGER("KrutikMusic").info("✅ Krutik Cyber Music Bot Started Successfully!")
        await idle()
    
    except Exception as e:
        LOGGER("KrutikMusic").error(f"FATAL ERROR DURING STARTUP: {e}")
    
    finally:
        LOGGER("KrutikMusic").info("sᴛᴏᴘᴘɪɴɢ ᴍᴜsɪᴄ ʙᴏᴛ ...")
        # ── Graceful Shutdown ──
        try:
            if KRUTIK:
                await KRUTIK.stop()
        except:
            pass
        try:
            if userbot:
                await userbot.stop()
        except:
            pass
        try:
            if app:
                await app.stop()
        except:
            pass
        
        # Close all global aiohttp sessions to prevent leaked connectors
        try:
            from KrutikMusic.platforms.Youtube import close_yt_session
            await close_yt_session()
        except:
            pass
        try:
            from KrutikMusic.utils.colored_buttons import close_session as close_btn_session
            await close_btn_session()
        except:
            pass
        try:
            from KrutikMusic.utils.downloader import close_session as close_dl_session
            await close_dl_session()
        except:
            pass
        try:
            from KrutikMusic import Carbon
            await Carbon.close()
        except:
            pass
        try:
            from KrutikMusic.utils.thumbnails import close_session as close_thumb_session
            await close_thumb_session()
        except:
            pass

        # Persist and snapshot database on shutdown
        try:
            from KrutikMusic.core.mongo import mongodb
            await mongodb.create_backup("graceful_shutdown")
        except:
            pass

        # ✅ NEW: Cancel all remaining background tasks (GC loop, refresh loop, etc.)
        # This prevents "Event loop is closed" errors while tasks are still pending.
        try:
            tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
            for task in tasks:
                task.cancel()
            
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
        except:
            pass
        
        # Give a small window for network cleanup tasks to finish before loop closes
        await asyncio.sleep(0.5)



if __name__ == "__main__":
    try:
        asyncio.get_event_loop().run_until_complete(init())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Loop exited with error: {e}")

# ═══════════════════════════════════════════════════════════
#        🌺 KRUTIK CYBER MUSIC 🌺
#   Powered by KRUTIK CYBER DEVELOPER
# ═══════════════════════════════════════════════════════════
